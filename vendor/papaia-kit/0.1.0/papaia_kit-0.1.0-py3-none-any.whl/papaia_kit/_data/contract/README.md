# Contract documents

Normative prose that accompanies the schemas in `../schemas`: field meanings,
examples and the rules a consumer or provider must follow. Where prose and schema
disagree, the schema wins and the prose is corrected.

| Document | Schemas |
|---|---|
| `platform-services.md` | `platform-services.v1`, `platform-groups.v1` |
| `catalog-reader.md` | Consumer behaviour for both files (reader of `papaia_kit.catalog`) |
| [`exposes.md`](exposes.md): manifest section `exposes:`, service accounts, backup of volumes, storage declaration, `/healthz` | `exposes.v1`, `healthz.v1` |
| [`conformance.md`](conformance.md): conformance suites `manifest`, `catalog-consumer`, `recording`, `realm`, `server`; recording format of provider suites | `recording.v1` |
| [`exchange.md`](exchange.md): token exchange client `papaia_kit.exchange`, one audience per token, chain only as declared | none |
| [`authz.md`](authz.md): server-side check chain, `azp-allowlist.json`, chain origin, revocation list | `error.v1` (rejections) |

`examples/` holds documents that validate against the schemas; the tests in
`tests/` use them as the base of every positive and negative vector. The
example manifests (`*.papaia-app.yaml`: Paperless, Flow, Studio, probe) illustrate the
`exposes:` contract and are not the modules' own manifests.
`vectors/` holds the shared test vectors every implementation of a kit
function runs unchanged (Python, TypeScript, conformance suites).

| File | Content |
|---|---|
| `errors.yaml` | Module code → error class (`schemas/error.v1.schema.json`), aliases, generic code |
| `messages/codes.{de,en}.yaml` | Display texts per code after pattern 8 and class titles |
| `messages/consequences.{de,en}.yaml` | Closed list of consequence sentences |
| `forbidden-patterns.yaml` | Patterns that never appear in text shown to people |
| `instruction-patterns.yaml` | Text shaped like an instruction to a model, rejected in manifests |
