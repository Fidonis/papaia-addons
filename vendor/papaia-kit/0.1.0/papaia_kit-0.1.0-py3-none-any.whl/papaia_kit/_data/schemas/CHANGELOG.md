# Schema changelog

Each schema carries its version in the top-level keyword `x-papaia-schema-version`
(Semantic Versioning). The major version is part of the file name
(`<name>.v<major>.schema.json`); a minor version adds optional fields, a patch
version tightens documentation or fixes a pattern without changing which
documents are valid on purpose. Newest entry first.

## erasure-epoch.v1 (unreleased)

- First version: `<backup target>/erasure-journal/epoch` with `format`
  (`papaia.erasure-epoch/1`), `generation` and the last `seq` per module and
  core source. Unknown fields are rejected.

## erasure-journal-entry.v1 (unreleased)

- New kinds `revoke` (module journals) and, for the core sources,
  `account_disable`, `account_delete`, `role_revoke`, `session_revoke`,
  `credential_reset` (`identity`) and `key_revoke` (`model-gateway`). The
  schema names the kinds allowed per journal.

## error.v1 1.0.0 (unreleased)

- The schema now carries `x-papaia-schema-version`; earlier states of the
  file had none and were never released.
- `correlation_id` follows the one correlation id rule of the kit
  (`#/$defs/correlation_id`, identical to the rule in `audit.v1`): besides 1 to
  64 characters out of `A-Z`, `a-z`, `0-9` and `-`, a value shaped like a token
  or a key with a well-known prefix is rejected, and a trailing newline no
  longer passes. `build_envelope` replaces such a value by a new UUIDv7 and
  `parse_envelope` rejects it.

## recording.v1 1.0.0 (unreleased)

- First version: recording of a provider suite (`papaia.conformance-recording/1`)
  with kit version, suite, schema version, provider catalog id and image
  digest, time of the recording and request and response pairs. Headers that
  carry credentials are rejected.

## audit.v1 1.0.0 (unreleased)

- First version of the audit event `papaia.audit/1`: submitted form
  (`#/$defs/submission`) and stored form with `source`, `seq`, `prev_hash` and
  `hash`, which only papaia-audit assigns.
- Unknown fields are rejected at every level; every string is a bounded
  identifier.
- Strings shaped like a JSON Web Token, a bearer credential, a PEM block or a
  key with a well-known prefix are rejected in every identifier field,
  including `correlation_id`, `writer`, `catalog_id`, `operation`,
  `object_ref.type` and `source`.
- Size, depth, node, integer and date checks beyond the schema are listed in
  `contract/audit.md`.
- Events of the erasure journal at module start and of the core's lifecycle
  actions: `erasure_replayed`, `post_restore_applied`,
  `lifecycle_request_rejected`, `state_epoch_behind`, `state_epoch_unverified`
  (provisionally ready, result `allowed`), `state_epoch_unknown` (nothing to
  check against or the module's applied `seq` unreadable, never ready, result
  `denied`).

## healthz.v1 1.0.0 (unreleased)

- First version: response body of `GET /healthz` of every module,
  `{"status": "ok" | "degraded" | "down"}` and nothing else.

## exposes.v1 1.0.0 (unreleased)

- First version of the manifest section `exposes:` (contract generation 7).
- Entry kinds `mcp`, `rest`, `ui`, `me`; the earlier kind `flow_provider` is
  not accepted and becomes `rest` with operations.
- Capability description per operation: effect (`read`, `write`, `send`,
  `delete`, `check`), retry class, input and output schema, highest data class,
  resource, rights check.
- `ui[]` for the module switcher and entry page, `events[]`, `downstream`,
  `standard_operations`, `roles[]`.
- `service_accounts[]` (`id` = `svc-<module>-<purpose>`, purpose, responsible
  person and deputy, roles, audiences, effects, `realm-management` roles,
  credential `private_key_jwt`).
- Entries of kind `me` accept only `person`.
- Embedded `input_schema`, `output_schema` and `payload_schema` reference
  nothing outside themselves (`$ref` and `$dynamicRef` start with `#`,
  `$schema` is the 2020-12 meta-schema) and contain no `$id`,
  `$recursiveRef` or `$recursiveAnchor` at any depth.
- Every pattern ends at the end of the input; a trailing line feed is
  rejected in Python and ECMA-262 validators alike.
- `delegation.purposes` lists ids of the fixed kit purposes `flow.run`,
  `assist.event`, `assist.room-check`, `assist.tools`; only the holder of a
  purpose (Flow for `flow.*`, the assistant for `assist.*`) may declare
  `delegation`, checked by the manifest conformance check.
- `delegation`, `models.needs`, `requires`, `volumes[].backup`, `export.exit`,
  `storage` (categories with purpose, legal basis, retention, data class and
  erasure path, `on_request`, secrets).
- Unknown fields are rejected everywhere; `trust`, `branding`, `state` and
  `public_url` are set by the core, never by a manifest.
