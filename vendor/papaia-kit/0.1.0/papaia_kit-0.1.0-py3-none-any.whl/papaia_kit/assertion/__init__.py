"""Module assertion: signing and verification of the module context assertion."""
