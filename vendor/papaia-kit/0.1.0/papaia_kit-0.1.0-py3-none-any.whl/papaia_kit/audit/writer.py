"""``AuditWriter``: outbox in the caller's transaction, ordered delivery to ``papaia-audit``.

A source writes each event with :meth:`AuditWriter.write` inside the same
database transaction as the effect it records. A delivery loop
(:meth:`AuditWriter.run`) sends the outbox in ``source_seq`` order, at most
:data:`~papaia_kit.audit.outbox.MAX_BATCH` rows per call, and deletes a row only
after ``papaia-audit`` acknowledged it with its ``seq``. Failed calls are
retried with exponential backoff; repeated rows are dropped by ``papaia-audit``
through ``source_seq``. The source keeps working while ``papaia-audit`` is
unreachable; the outbox grows (:meth:`AuditWriter.status`).

:class:`AsyncAuditWriter` is the same for asyncio applications (for example
FastAPI) with an async database driver. The rules are in ``contract/audit.md``.
"""

from __future__ import annotations

import asyncio
import logging
import random
import threading
from collections.abc import Callable, Mapping, Sequence
from contextlib import AbstractAsyncContextManager, AbstractContextManager, suppress
from dataclasses import dataclass
from typing import Any, Protocol

from papaia_kit.audit.outbox import (
    MAX_BATCH,
    AckError,
    Dialect,
    OutboxError,
    OutboxStatements,
    OutboxStatus,
    check_row,
    encode_batch,
    outbox_ddl,
    parse_ack,
    prepare_row,
)
from papaia_kit.audit.transport import AsyncIngestTransport, IngestError, IngestTransport

__all__ = [
    "AsyncAuditWriter",
    "AsyncConnection",
    "AuditWriter",
    "Backoff",
    "Connection",
    "DeliveryResult",
]

_log = logging.getLogger(__name__)


# A DB-API 2.0 connection (PEP 249), for example of sqlite3 or psycopg: the
# writer calls conn.cursor() and conn.commit() and the PEP 249 methods
# execute, fetchone, fetchall and close on what conn.cursor() returns.
Connection = Any


class AsyncConnection(Protocol):
    """The async connection of psycopg and aiosqlite: ``await conn.execute(...)``."""

    async def execute(self, sql: str, params: Sequence[Any] = ..., /) -> Any: ...
    async def commit(self) -> Any: ...


@dataclass(frozen=True)
class DeliveryResult:
    """Outcome of one delivery call.

    ``error`` is ``None`` or one of ``unreachable``, ``tls``, ``rejected``,
    ``bad_response`` (transport), ``bad_ack``, ``not_acknowledged`` (response),
    ``corrupt_row`` and ``outbox_unavailable`` (outbox).
    """

    sent: int
    acknowledged: int
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.error is None


class Backoff:
    """Exponential backoff with equal jitter: ``min(cap, base * 2**attempt)``, halved at random.

    Jitter spreads the retries of many sources after a restart of ``papaia-audit``.
    """

    def __init__(
        self, base: float = 1.0, cap: float = 60.0, rng: random.Random | None = None
    ) -> None:
        if not base > 0 or not cap >= base:
            raise ValueError("backoff needs 0 < base <= cap")
        self.base = base
        self.cap = cap
        self._rng = rng or random.Random()  # noqa: S311 - jitter, not a secret

    def delay(self, attempt: int) -> float:
        ceiling = min(self.cap, self.base * 2.0 ** min(attempt, 62))
        return ceiling / 2 + self._rng.random() * ceiling / 2


class _Core:
    """Options and the decisions shared by the sync and the async writer."""

    def __init__(
        self,
        dialect: Dialect,
        batch_size: int,
        backoff: Backoff | None,
        idle_interval: float,
    ) -> None:
        if isinstance(batch_size, bool) or not 1 <= batch_size <= MAX_BATCH:
            raise ValueError(f"batch_size must be 1 to {MAX_BATCH}")
        if not idle_interval > 0:
            raise ValueError("idle_interval must be positive")
        self.dialect = dialect
        self.sql = OutboxStatements.for_dialect(dialect)
        self.batch_size = batch_size
        self.backoff = backoff or Backoff()
        self.idle_interval = idle_interval

    def batch(self, rows: Sequence[Any]) -> tuple[list[int], bytes]:
        seqs: list[int] = []
        bodies: list[str] = []
        for source_seq, body in rows:
            check_row(source_seq, body)
            seqs.append(source_seq)
            bodies.append(body)
        return seqs, encode_batch(bodies)

    def next_wait(self, result: DeliveryResult, attempt: int) -> tuple[float, int]:
        """Seconds to wait before the next call, and the next attempt number."""
        if not result.ok:
            return self.backoff.delay(attempt), attempt + 1
        if result.sent == self.batch_size:
            return 0.0, 0
        return self.idle_interval, 0

    @staticmethod
    def failed(sent: int, error: str, note: str) -> DeliveryResult:
        # Reason codes and counts only: never an event, a response or a path.
        _log.warning("audit delivery failed: %s (%d rows, %s)", error, sent, note)
        return DeliveryResult(sent=sent, acknowledged=0, error=error)


def _next_seq(row: Any) -> int:
    if row is None:
        raise OutboxError("audit outbox is not set up; run ensure_schema() or outbox_ddl()")
    return int(row[0])


class AuditWriter:
    """Blocking writer for DB-API connections.

    ``connect`` returns a context manager yielding a connection to the source's
    database; the writer uses it for its own delivery transactions, never for
    the caller's. ``transport`` is usually an
    :class:`~papaia_kit.audit.transport.HttpsIngestTransport`.

    Run exactly one delivery loop per source. A second loop would only resend
    rows (``papaia-audit`` drops the repeats), never reorder them.
    """

    def __init__(
        self,
        connect: Callable[[], AbstractContextManager[Any]],
        transport: IngestTransport,
        *,
        dialect: Dialect = "sqlite",
        batch_size: int = MAX_BATCH,
        backoff: Backoff | None = None,
        idle_interval: float = 1.0,
    ) -> None:
        self._core = _Core(dialect, batch_size, backoff, idle_interval)
        self._connect = connect
        self._transport = transport

    def ensure_schema(self) -> None:
        """Create the outbox tables if missing (or run :func:`outbox_ddl` in a migration)."""
        with self._connect() as conn:
            cur = conn.cursor()
            try:
                for statement in outbox_ddl(self._core.dialect):
                    cur.execute(statement)
            finally:
                cur.close()
            conn.commit()

    def write(self, conn: Connection, event: Mapping[str, Any]) -> int:
        """Add ``event`` to the outbox in the caller's open transaction; return its ``source_seq``.

        The caller commits or rolls back. The event must not carry
        ``source_seq``, ``source``, ``seq``, ``prev_hash`` or ``hash``; an
        invalid event raises :class:`~papaia_kit.audit.AuditEventError` before
        anything is written.
        """
        sql = self._core.sql
        cur = conn.cursor()
        try:
            prepare_row(event, 1)  # reject before the counter row is locked
            cur.execute(sql.next_seq)
            source_seq = _next_seq(cur.fetchone())
            created_at, body = prepare_row(event, source_seq)
            cur.execute(sql.insert, (source_seq, created_at, body))
        except Exception as error:
            if _is_missing_table(error):
                raise OutboxError("audit outbox is not set up; run ensure_schema()") from None
            raise
        finally:
            cur.close()
        return source_seq

    def deliver_once(self) -> DeliveryResult:
        """Send the oldest batch and delete the acknowledged rows."""
        core = self._core
        with self._connect() as conn:
            cur = conn.cursor()
            try:
                cur.execute(core.sql.select_batch, (core.batch_size,))
                rows = cur.fetchall()
            finally:
                cur.close()
            conn.commit()
            if not rows:
                return DeliveryResult(sent=0, acknowledged=0)
            try:
                seqs, body = core.batch(rows)
            except OutboxError:
                return core.failed(len(rows), "corrupt_row", "held")
            try:
                acknowledged = parse_ack(self._transport.send(body), seqs)
            except IngestError as error:
                return core.failed(len(seqs), error.reason, _kept(error))
            except AckError:
                return core.failed(len(seqs), "bad_ack", "kept")
            if not acknowledged:
                return core.failed(len(seqs), "not_acknowledged", "kept")
            cur = conn.cursor()
            try:
                for source_seq in sorted(acknowledged):
                    cur.execute(core.sql.delete, (source_seq,))
            finally:
                cur.close()
            conn.commit()
        return DeliveryResult(sent=len(seqs), acknowledged=len(acknowledged))

    def status(self) -> OutboxStatus:
        """Depth and oldest source time of the outbox (``papaia_audit_outbox_depth``)."""
        with self._connect() as conn:
            cur = conn.cursor()
            try:
                cur.execute(self._core.sql.status)
                depth, oldest = cur.fetchone()
            finally:
                cur.close()
            conn.commit()
        return OutboxStatus(depth=int(depth), oldest_time=oldest)

    def run(self, stop: threading.Event) -> None:
        """Deliver until ``stop`` is set; meant for a dedicated thread."""
        attempt = 0
        while not stop.is_set():
            try:
                result = self.deliver_once()
            except Exception as error:  # the loop must survive a database outage
                result = self._core.failed(0, "outbox_unavailable", type(error).__name__)
            wait, attempt = self._core.next_wait(result, attempt)
            if wait:
                stop.wait(wait)


class AsyncAuditWriter:
    """:class:`AuditWriter` for asyncio applications with an async database driver.

    ``connect`` returns an async context manager yielding an
    :class:`AsyncConnection`; ``transport`` is usually a
    :class:`~papaia_kit.audit.transport.ThreadedIngestTransport` around an
    :class:`~papaia_kit.audit.transport.HttpsIngestTransport`. In FastAPI,
    start :meth:`run` as a task in the lifespan handler and set the event on
    shutdown.
    """

    def __init__(
        self,
        connect: Callable[[], AbstractAsyncContextManager[Any]],
        transport: AsyncIngestTransport,
        *,
        dialect: Dialect = "sqlite",
        batch_size: int = MAX_BATCH,
        backoff: Backoff | None = None,
        idle_interval: float = 1.0,
    ) -> None:
        self._core = _Core(dialect, batch_size, backoff, idle_interval)
        self._connect = connect
        self._transport = transport

    async def ensure_schema(self) -> None:
        async with self._connect() as conn:
            for statement in outbox_ddl(self._core.dialect):
                await conn.execute(statement)
            await conn.commit()

    async def write(self, conn: AsyncConnection, event: Mapping[str, Any]) -> int:
        """See :meth:`AuditWriter.write`."""
        sql = self._core.sql
        try:
            prepare_row(event, 1)
            cur = await conn.execute(sql.next_seq)
            source_seq = _next_seq(await cur.fetchone())
            created_at, body = prepare_row(event, source_seq)
            await conn.execute(sql.insert, (source_seq, created_at, body))
        except Exception as error:
            if _is_missing_table(error):
                raise OutboxError("audit outbox is not set up; run ensure_schema()") from None
            raise
        return source_seq

    async def deliver_once(self) -> DeliveryResult:
        core = self._core
        async with self._connect() as conn:
            cur = await conn.execute(core.sql.select_batch, (core.batch_size,))
            rows = await cur.fetchall()
            await conn.commit()
            if not rows:
                return DeliveryResult(sent=0, acknowledged=0)
            try:
                seqs, body = core.batch(rows)
            except OutboxError:
                return core.failed(len(rows), "corrupt_row", "held")
            try:
                acknowledged = parse_ack(await self._transport.send(body), seqs)
            except IngestError as error:
                return core.failed(len(seqs), error.reason, _kept(error))
            except AckError:
                return core.failed(len(seqs), "bad_ack", "kept")
            if not acknowledged:
                return core.failed(len(seqs), "not_acknowledged", "kept")
            for source_seq in sorted(acknowledged):
                await conn.execute(core.sql.delete, (source_seq,))
            await conn.commit()
        return DeliveryResult(sent=len(seqs), acknowledged=len(acknowledged))

    async def status(self) -> OutboxStatus:
        async with self._connect() as conn:
            cur = await conn.execute(self._core.sql.status)
            depth, oldest = await cur.fetchone()
            await conn.commit()
        return OutboxStatus(depth=int(depth), oldest_time=oldest)

    async def run(self, stop: asyncio.Event) -> None:
        """Deliver until ``stop`` is set."""
        attempt = 0
        while not stop.is_set():
            try:
                result = await self.deliver_once()
            except Exception as error:  # the loop must survive a database outage
                result = self._core.failed(0, "outbox_unavailable", type(error).__name__)
            wait, attempt = self._core.next_wait(result, attempt)
            if wait:
                with suppress(TimeoutError):
                    await asyncio.wait_for(stop.wait(), timeout=wait)


def _kept(error: IngestError) -> str:
    return f"kept, {error.detail}" if error.detail else "kept"


def _is_missing_table(error: Exception) -> bool:
    """True for "no such table" (sqlite) and "undefined table" (PostgreSQL, SQLSTATE 42P01).

    psycopg 3 carries the SQLSTATE as ``sqlstate``, psycopg2 as ``pgcode``.
    """
    if "42P01" in (getattr(error, "sqlstate", None), getattr(error, "pgcode", None)):
        return True
    return type(error).__name__ == "OperationalError" and "no such table" in str(error)
