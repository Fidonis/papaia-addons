"""The check chain itself (security 2.1 steps 1-7, 1.5 Nr. 4, 1.12 Nr. 3).

Every failure ends the chain with the error class of PLT-07 and never tells
whether an object exists. Every rejection hands one ``papaia.audit/1`` row with
result ``denied`` to the audit sink before ``AuthzDenied`` is raised.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any

import jwt
from jwt.exceptions import InvalidSignatureError, PyJWTError

from papaia_kit.authz._config import (
    MULTI_AUDIENCE_CLIENTS,
    IdentityKind,
    Request,
    ServerConfig,
    Trust,
    is_client_name,
)
from papaia_kit.authz._keys import ALGORITHMS, KeyProvider
from papaia_kit.authz._revocation import RevocationList, RevocationState, RevocationStatus
from papaia_kit.errors import ErrorEnvelope, build_envelope, normalize_correlation_id
from papaia_kit.names import InvalidClaims, person_id

AUDIT_FORMAT = "papaia.audit/1"
LEEWAY_SECONDS = 30
MAX_TOKEN_LENGTH = 16384
ORIGIN_HEADER = "X-Papaia-Origin-Azp"
CORRELATION_HEADER = "X-Papaia-Correlation-Id"
MISMATCH_EVENT = "origin_header_mismatch"
# Keycloak access tokens carry the claim typ=Bearer; ID, refresh and logout
# tokens carry other values (RFC 8725 3.11). The header typ, when present, must
# name a JWT or an RFC 9068 access token.
ACCESS_TOKEN_TYPE = "Bearer"  # noqa: S105 - a token type name, not a secret
_HEADER_TYPES = frozenset({"jwt", "at+jwt", "application/at+jwt"})

AuditSink = Callable[[dict[str, Any]], None]
RevocationSource = Callable[[], RevocationList | None]

_SEGMENT = re.compile(r"[A-Za-z0-9_-]+")
_BEARER = re.compile(r"[Bb]earer ([A-Za-z0-9._~+/-]+=*)")
# Character sets of papaia.audit/1; anything else is left out of the row.
_AUDIT_SUBJECT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:@|+-]{0,254}")
_TOKEN_SHAPED = re.compile(r"eyJ[A-Za-z0-9_-]*\.|[Bb]earer[ \t]|-----BEGIN")


class Reason(StrEnum):
    """Why the chain refused a token. For logs and tests; never sent to the caller."""

    MALFORMED = "malformed"
    TOKEN_TYPE = "token_type"  # noqa: S105 - a reason name, not a secret
    ALGORITHM = "algorithm"
    SIGNATURE = "signature"
    ISSUER = "issuer"
    CLAIMS = "claims"
    EXPIRED = "expired"
    NOT_YET_VALID = "not_yet_valid"
    AUDIENCE = "audience"
    MULTIPLE_AUDIENCES = "multiple_audiences"
    ALLOWLIST_EMPTY = "allowlist_empty"
    AZP_NOT_ALLOWED = "azp_not_allowed"
    SUBJECT = "subject"
    IDENTITY_KIND = "identity_kind"
    REVOKED = "revoked"
    ROLE = "role"
    EFFECT = "effect"


_UNAUTHENTICATED = ("PK-AUTH-001", None)
_FORBIDDEN = ("PK-ACCESS-001", 403)
_REVOKED = ("PK-IDENTITY-001", None)


class AuthzDenied(Exception):  # noqa: N818 - reads as "raise AuthzDenied"
    """The chain refused the request; answer with ``envelope`` and ``status``."""

    def __init__(self, reason: Reason, envelope: ErrorEnvelope, audit_row: dict[str, Any]) -> None:
        super().__init__(f"authorization denied: {reason.value}")
        self.reason = reason
        self.envelope = envelope
        self.status = envelope.status
        self.audit_row = audit_row


@dataclass(frozen=True)
class Principal:
    """Verified identity of a request. The person is taken from here only (step 9)."""

    sub: str
    person_id: str | None
    identity_kind: IdentityKind
    azp: str
    audience: str
    roles: frozenset[str]
    issued_at: int
    expires_at: int
    origin_azp: str
    origin_source: str
    origin_asserted_by: str | None
    correlation_id: str

    def audit_fields(self) -> dict[str, Any]:
        """Identity part of the server's own ``papaia.audit/1`` row for this request."""
        return {
            "correlation_id": self.correlation_id,
            "role": "server",
            "sub": self.sub,
            "identity_kind": self.identity_kind.value,
            "service_account": self.azp if self.identity_kind is IdentityKind.SERVICE else None,
            "azp": self.azp,
            "aud": self.audience,
            "origin_azp": self.origin_azp,
            "origin_source": self.origin_source,
            "origin_asserted_by": self.origin_asserted_by,
        }


def bearer_token(authorization: str | None) -> str | None:
    """The token of an ``Authorization: Bearer <token>`` header value, else None."""
    if not isinstance(authorization, str):
        return None
    match = _BEARER.fullmatch(authorization)
    return match.group(1) if match else None


def _audit_subject(value: object) -> str | None:
    if isinstance(value, str) and _AUDIT_SUBJECT.fullmatch(value):
        return None if _TOKEN_SHAPED.search(value) else value
    return None


def _audit_client(value: object) -> str | None:
    return value if isinstance(value, str) and is_client_name(value) else None


def _timestamp(now: float) -> str:
    moment = datetime.fromtimestamp(now, UTC)
    return moment.strftime("%Y-%m-%dT%H:%M:%S.") + f"{moment.microsecond // 1000:03d}Z"


def _header(token: str) -> dict[str, Any] | None:
    segments = token.split(".")
    # An empty signature is still parsed, so that 'alg: none' is reported as such.
    if len(segments) != 3 or not all(_SEGMENT.fullmatch(part) for part in segments[:2]):  # noqa: PLR2004
        return None
    if segments[2] and not _SEGMENT.fullmatch(segments[2]):
        return None
    try:
        raw = base64.urlsafe_b64decode(segments[0] + "=" * (-len(segments[0]) % 4))
        header = json.loads(raw)
    except (binascii.Error, ValueError):
        return None
    return header if isinstance(header, dict) else None


def _header_problem(header: Mapping[str, Any] | None) -> Reason | None:
    """Step 1 on the protected header, before any key is looked up."""
    if header is None or "crit" in header:
        return Reason.MALFORMED
    header_type = header.get("typ", "JWT")
    if not isinstance(header_type, str) or header_type.lower() not in _HEADER_TYPES:
        return Reason.TOKEN_TYPE
    if header.get("alg") not in ALGORITHMS:
        return Reason.ALGORITHM
    kid = header.get("kid")
    if not isinstance(kid, str) or not kid:
        return Reason.MALFORMED
    return None


def _numeric_date(claims: Mapping[str, Any], name: str, *, required: bool) -> int | None:
    value = claims.get(name)
    if value is None and not required and name not in claims:
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(name)
    return value


def _asserted_origin(value: str | None) -> str | None:
    """``origin_asserted_by``: the header value when it is a client name; else not recorded."""
    return value if value is not None and is_client_name(value) else None


def _identity_kind(claims: Mapping[str, Any], trail: _Trail) -> IdentityKind | None:
    """Identity kind of signed claims for the audit row, None when undecidable.

    Step 4 decides on the same rule; this only lets an earlier rejection name
    the kind. A service kind needs a recordable ``azp`` as its service account.
    """
    if trail.sub is None:
        return None
    try:
        person = person_id(claims)
    except (InvalidClaims, TypeError):
        return None
    if person is not None:
        return IdentityKind.PERSON
    return IdentityKind.SERVICE if trail.azp is not None else None


def _roles(claims: Mapping[str, Any]) -> frozenset[str]:
    """Module roles from the flat ``roles`` claim; ``scope`` is never read."""
    raw = claims.get("roles")
    if not isinstance(raw, list):
        return frozenset()
    return frozenset(role for role in raw if isinstance(role, str))


@dataclass
class _Trail:
    """What the chain has verified so far; feeds the audit row of a rejection."""

    sub: str | None = None
    azp: str | None = None
    aud: str | None = None
    identity_kind: IdentityKind | None = None
    origin: tuple[str, str] | None = None
    asserted: str | None = None


class CheckChain:
    """Checks a bearer token for one request, in the order of security 2.1.

    1. signature (RS256/ES256 against the realm keys), ``iss`` exact, access
       token type (``typ: Bearer``), ``exp``, ``nbf``, ``iat`` with 30 s tolerance
    2. ``aud`` is exactly the own audience; several audiences only at a
       ``trust: platform`` server and only from the chat client
    3. ``azp`` is in the allow list of the own audience (empty list: refuse all)
    4. identity kind (``person`` or ``service``) admitted by the operation
    5. revocation list: ``iat < global_since`` or a revoked ``sub``
       (skipped while no list is loaded; disabled with ``revocations=None``)
    6. one of the route's module roles in ``roles`` (unless the route is
       declared with ``no_role_required``)
    7. the effect is released for this ``azp``

    The ``scope`` claim is never read. The origin of a chain (``origin_azp``)
    comes from the configured upstream origins; the ``X-Papaia-Origin-Azp``
    header is information only, and a mismatch is recorded as the event
    ``origin_header_mismatch`` without changing the decision.

    ``audit`` receives the rows; it is the audit writer of the source, which
    adds ``source_seq`` and delivers. An exception of the sink propagates, so a
    rejection is never silently unrecorded and no access is granted.
    ``revocations`` (required) returns the current, signature-checked
    revocation list, or None while none is loaded; then step 5 is skipped. An
    exception there propagates as well. Passing ``revocations=None`` disables
    step 5 altogether; ``revocation_status()`` reports both cases for doctor.
    """

    def __init__(
        self,
        config: ServerConfig,
        keys: KeyProvider,
        *,
        audit: AuditSink,
        revocations: RevocationSource | None,
        clock: Callable[[], float] = time.time,
        lang: str = "de",
    ) -> None:
        self._config = config
        self._keys = keys
        self._audit = audit
        self._revocations = revocations
        self._clock = clock
        self._lang = lang

    def revocation_status(self) -> RevocationStatus:
        """Whether step 5 runs, and the sequence number and age of the list."""
        if self._revocations is None:
            return RevocationStatus(RevocationState.DISABLED)
        current = self._revocations()
        if current is None:
            return RevocationStatus(RevocationState.NOT_LOADED)
        return RevocationStatus(
            RevocationState.LOADED,
            seq=current.seq,
            issued_at=current.issued_at,
            age_seconds=self._clock() - current.issued_at,
        )

    def check(self, token: str, request: Request) -> Principal:
        correlation_id = normalize_correlation_id(request.correlation_id)
        now = self._clock()
        trail = _Trail()
        trail.asserted = _asserted_origin(request.origin_header)

        def deny(reason: Reason, code: tuple[str, int | None]) -> AuthzDenied:
            envelope = build_envelope(
                code[0], correlation_id=correlation_id, lang=self._lang, status=code[1]
            )
            row = self._row(now, correlation_id, request, trail, result="denied", event="operation")
            row["error_code"] = code[0]
            self._audit(row)
            return AuthzDenied(reason, envelope, row)

        claims = self._verify(token, now, trail, deny)
        config = self._config

        # Step 2: audience
        audience_problem = self._audience_problem(claims.get("aud"), trail)
        if audience_problem is not None:
            raise deny(audience_problem, _UNAUTHENTICATED)

        # Step 3: azp in the allow list of the own audience
        released = config.allowlist.clients(config.audience)
        if not released:
            raise deny(Reason.ALLOWLIST_EMPTY, _UNAUTHENTICATED)
        azp = claims.get("azp")
        if not isinstance(azp, str) or azp not in released:
            raise deny(Reason.AZP_NOT_ALLOWED, _UNAUTHENTICATED)
        # Never a chain holder: ServerConfig refuses one released without origin.
        trail.origin = config.origin_of(azp)
        mismatch = request.origin_header is not None and trail.asserted != trail.origin[0]

        # Step 4: identity kind
        try:
            person = person_id(claims)
        except (InvalidClaims, TypeError):
            raise deny(Reason.SUBJECT, _UNAUTHENTICATED) from None
        sub: str = claims["sub"]
        trail.identity_kind = IdentityKind.PERSON if person is not None else IdentityKind.SERVICE
        if trail.identity_kind not in request.identity_kinds:
            raise deny(Reason.IDENTITY_KIND, _FORBIDDEN)

        # Step 5: revocation list
        issued_at: int = claims["iat"]
        revocations = self._revocations() if self._revocations is not None else None
        if revocations is not None and revocations.revoked(sub, issued_at):
            raise deny(Reason.REVOKED, _REVOKED)

        # Step 6: module role of the route (never from 'scope')
        roles = _roles(claims)
        if request.roles and not roles & request.roles:
            raise deny(Reason.ROLE, _FORBIDDEN)

        # Step 7: effect released for this azp
        if request.effect not in released[azp]:
            raise deny(Reason.EFFECT, _FORBIDDEN)

        if mismatch:
            row = self._row(
                now, correlation_id, request, trail, result="allowed", event=MISMATCH_EVENT
            )
            self._audit(row)

        return Principal(
            sub=sub,
            person_id=person,
            identity_kind=trail.identity_kind,
            azp=azp,
            audience=config.audience,
            roles=roles,
            issued_at=issued_at,
            expires_at=claims["exp"],
            origin_azp=trail.origin[0],
            origin_source=trail.origin[1],
            origin_asserted_by=trail.asserted,
            correlation_id=correlation_id,
        )

    def _verify(
        self,
        token: object,
        now: float,
        trail: _Trail,
        deny: Callable[[Reason, tuple[str, int | None]], AuthzDenied],
    ) -> dict[str, Any]:
        """Step 1: structure, algorithm, key, signature, issuer and times."""
        if not isinstance(token, str) or len(token) > MAX_TOKEN_LENGTH:
            raise deny(Reason.MALFORMED, _UNAUTHENTICATED)
        header = _header(token)
        problem = _header_problem(header)
        if problem is not None:
            raise deny(problem, _UNAUTHENTICATED)
        assert header is not None  # noqa: S101 - checked by _header_problem
        alg, kid = header["alg"], header["kid"]
        key = self._keys.key_for(kid)
        if key is None or key.algorithm_name != alg:
            raise deny(Reason.SIGNATURE, _UNAUTHENTICATED)
        try:
            claims = jwt.decode(
                token,
                key,
                algorithms=[alg],
                options={
                    "verify_signature": True,
                    "verify_exp": False,
                    "verify_nbf": False,
                    "verify_iat": False,
                    "verify_aud": False,
                    "verify_iss": False,
                    "verify_sub": False,
                    "verify_jti": False,
                    "require": [],
                },
            )
        except InvalidSignatureError:
            raise deny(Reason.SIGNATURE, _UNAUTHENTICATED) from None
        except PyJWTError:
            raise deny(Reason.MALFORMED, _UNAUTHENTICATED) from None
        if not isinstance(claims, dict):
            raise deny(Reason.MALFORMED, _UNAUTHENTICATED)
        if claims.get("iss") != self._config.issuer:
            raise deny(Reason.ISSUER, _UNAUTHENTICATED)
        # Signed by the realm: identity fields may now go into the audit row.
        trail.sub = _audit_subject(claims.get("sub"))
        trail.azp = _audit_client(claims.get("azp"))
        trail.identity_kind = _identity_kind(claims, trail)
        if claims.get("typ") != ACCESS_TOKEN_TYPE:
            raise deny(Reason.TOKEN_TYPE, _UNAUTHENTICATED)
        try:
            expires = _numeric_date(claims, "exp", required=True)
            issued = _numeric_date(claims, "iat", required=True)
            not_before = _numeric_date(claims, "nbf", required=False)
        except ValueError:
            raise deny(Reason.CLAIMS, _UNAUTHENTICATED) from None
        assert expires is not None and issued is not None  # noqa: S101 - required above
        if expires + LEEWAY_SECONDS < now:
            raise deny(Reason.EXPIRED, _UNAUTHENTICATED)
        if issued - LEEWAY_SECONDS > now or (
            not_before is not None and not_before - LEEWAY_SECONDS > now
        ):
            raise deny(Reason.NOT_YET_VALID, _UNAUTHENTICATED)
        return claims

    def _audience_problem(self, aud: object, trail: _Trail) -> Reason | None:
        """Step 2: exactly the own audience; several only for platform trust and the chat."""
        config = self._config
        audiences = [aud] if isinstance(aud, str) else aud
        if (
            not isinstance(audiences, list)
            or not audiences
            or not all(isinstance(item, str) and item for item in audiences)
        ):
            return Reason.AUDIENCE
        if len(audiences) == 1:
            trail.aud = audiences[0] if is_client_name(audiences[0]) else None
            return None if audiences[0] == config.audience else Reason.AUDIENCE
        multi_allowed = (
            config.trust is Trust.PLATFORM
            and trail.azp in MULTI_AUDIENCE_CLIENTS
            and len(set(audiences)) == len(audiences)
        )
        if not multi_allowed:
            return Reason.MULTIPLE_AUDIENCES
        return None if config.audience in audiences else Reason.AUDIENCE

    def _row(
        self,
        now: float,
        correlation_id: str,
        request: Request,
        trail: _Trail,
        *,
        result: str,
        event: str,
    ) -> dict[str, Any]:
        kind = trail.identity_kind
        origin_azp, origin_source = trail.origin or (None, None)
        # Every identity field is present, null when the chain does not know it.
        return {
            "format": AUDIT_FORMAT,
            "time": _timestamp(now),
            "correlation_id": correlation_id,
            "writer": self._config.writer,
            "result": result,
            "event": event,
            "role": "server",
            "sub": trail.sub,
            "identity_kind": kind.value if kind is not None else None,
            "service_account": trail.azp if kind is IdentityKind.SERVICE else None,
            "azp": trail.azp,
            "aud": trail.aud,
            "origin_azp": origin_azp,
            "origin_source": origin_source,
            "origin_asserted_by": trail.asserted,
            "catalog_id": request.catalog_id,
            "operation": request.operation,
            "effect": str(request.effect),
        }
