"""Catalog reader: loads the platform catalog, validates it against its schema, computes
its hash and derives the modules visible to a set of roles.

Every module reads ``platform/services.json`` and ``platform/groups.json`` with
this package and nothing else, so behaviour on an invalid, new, changed or
vanished file is the same everywhere. See ``contract/platform-services.md``
section 4 and ``contract/catalog-reader.md``.
"""

from papaia_kit.catalog.approval import (
    REMOVED_CAUSE,
    REMOVED_ERROR_CLASS,
    REMOVED_ERROR_CODE,
    ApprovalState,
    EntryRemovedError,
    approval_state,
    require_entry,
)
from papaia_kit.catalog.canonical import canonical_json, content_hash
from papaia_kit.catalog.document import (
    GROUPS_FORMAT,
    MAX_BYTES,
    MAX_DEPTH,
    SERVICES_FORMAT,
    Catalog,
    CatalogError,
    Entry,
    Group,
    GroupList,
    State,
    Surface,
    parse_groups,
    parse_services,
)
from papaia_kit.catalog.reader import (
    INTERNAL_CHECK_ERROR,
    MAX_AGE_SECONDS,
    Changes,
    GroupsReader,
    Reader,
    ReaderStatus,
    ServicesReader,
    diff,
)
from papaia_kit.catalog.visible import LinkState, link_state, visible_modules

__all__ = [
    "GROUPS_FORMAT",
    "INTERNAL_CHECK_ERROR",
    "MAX_AGE_SECONDS",
    "MAX_BYTES",
    "MAX_DEPTH",
    "REMOVED_CAUSE",
    "REMOVED_ERROR_CLASS",
    "REMOVED_ERROR_CODE",
    "SERVICES_FORMAT",
    "ApprovalState",
    "Catalog",
    "CatalogError",
    "Changes",
    "Entry",
    "EntryRemovedError",
    "Group",
    "GroupList",
    "GroupsReader",
    "LinkState",
    "Reader",
    "ReaderStatus",
    "ServicesReader",
    "State",
    "Surface",
    "approval_state",
    "canonical_json",
    "content_hash",
    "diff",
    "link_state",
    "parse_groups",
    "parse_services",
    "require_entry",
    "visible_modules",
]
