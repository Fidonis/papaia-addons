"""Command line entry point ``papaia-kit``."""

from __future__ import annotations

import argparse
import json
import math
import os
import shlex
import subprocess
import sys
from collections.abc import Sequence
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from papaia_kit import __version__
from papaia_kit.conformance import (
    SKIPPABLE_DIRS,
    CommandDriver,
    IssuerTokens,
    KitReaderDriver,
    ManifestError,
    RealmError,
    ServerSuiteError,
    ServerTarget,
    StaticExceptionError,
    SuiteResult,
    UrllibFetch,
    audiences,
    check_manifest_files,
    check_realm,
    check_realm_export_file,
    check_recording_file,
    exchange_clients,
    junit_xml,
    load_calls,
    load_manifest,
    load_realm_export,
    load_static_exceptions,
    read_realm_admin,
    run_catalog_consumer,
    run_server_suite,
    run_static,
    select_entry,
)
from papaia_kit.conformance.result import case
from papaia_kit.conformance.server import (
    DEFAULT_FOREIGN_AUDIENCE,
    DEFAULT_FOREIGN_AZP,
    DEFAULT_SUBJECT,
)
from papaia_kit.licenses import (
    EnvironmentMismatch,
    Exceptions,
    PolicyError,
    Record,
    evaluate,
    json_records,
    load_exceptions,
    load_policy,
    npm_records,
    python_records,
    render_markdown,
)
from papaia_kit.names import InvalidName, Kind, entries, exchange_scope, validate
from papaia_kit.repo import check_commits, scan_files, valid_range

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2
# Access token of the read-only admin account for ``conformance realm --admin-url``.
ADMIN_TOKEN_ENV = "PAPAIA_KIT_ADMIN_TOKEN"  # noqa: S105 - name of a variable
MAX_ADMIN_TIMEOUT = 300.0
_MAX_TOKEN_FILE = 64 * 1024


def _license_inputs(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--policy", type=Path, help="policy file (default: the kit's policy)")
    parser.add_argument(
        "--exceptions",
        type=Path,
        help="license-exceptions.toml of the repository (default: ./license-exceptions.toml)",
    )
    parser.add_argument(
        "--python-project",
        type=Path,
        help="uv project whose environment runs this command; every package of its uv.lock "
        "must be installed there at the locked version",
    )
    parser.add_argument("--npm-lock", type=Path, action="append", default=[])
    parser.add_argument("--records", type=Path, action="append", default=[])
    parser.add_argument("--edition", help="standalone edition rule from the policy")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="papaia-kit", description=__doc__)
    parser.add_argument("--version", action="version", version=f"papaia-kit {__version__}")
    groups = parser.add_subparsers(dest="group", required=True)

    licenses = groups.add_parser("licenses", help="dependency license policy")
    lic = licenses.add_subparsers(dest="command", required=True)
    check = lic.add_parser("check", help="fail on any dependency the policy does not allow")
    _license_inputs(check)
    check.add_argument("--report", type=Path, help="write a JSON report")
    render = lic.add_parser("render", help="write THIRD_PARTY_LICENSES.md")
    _license_inputs(render)
    render.add_argument("--output", type=Path, default=Path("THIRD_PARTY_LICENSES.md"))
    render.add_argument("--check", action="store_true", help="fail if the file is not current")

    repo = groups.add_parser("repo", help="repository discipline")
    rep = repo.add_subparsers(dest="command", required=True)
    words = rep.add_parser("words", help="denied terms in tracked and new files")
    words.add_argument("--root", type=Path, default=Path())
    commits = rep.add_parser("commits", help="author, committer, sign-off and message")
    commits.add_argument("--root", type=Path, default=Path())
    commits.add_argument("--email-domain", default="fidonis.de")
    commits.add_argument("range", help="revision range, e.g. origin/main..HEAD or HEAD")

    names = groups.add_parser("names", help="naming register")
    nam = names.add_subparsers(dest="command", required=True)
    kinds = [k.value for k in Kind]
    listing = nam.add_parser("list", help="print the register as JSON")
    listing.add_argument("--kind", choices=kinds)
    check_names = nam.add_parser("check", help="fail on any name that breaks the register")
    check_names.add_argument("--kind", choices=kinds, required=True)
    check_names.add_argument("name", nargs="+")
    scope = nam.add_parser("scope", help="print the exchange scope of one audience")
    scope.add_argument("audience")

    conformance = groups.add_parser("conformance", help="conformance suites of the contract")
    suites = conformance.add_subparsers(dest="command", required=True)
    manifest = suites.add_parser(
        "manifest", help="exposes: against schema, naming register and the checks beyond it"
    )
    manifest.add_argument("manifest", type=Path, nargs="+", help="papaia-app.yaml or exposes.yaml")
    manifest.add_argument("--compose", type=Path, help="compose file of the module (one manifest)")
    manifest.add_argument(
        "--core-profile",
        action="store_true",
        help="the files are exposes.yaml of core profiles (no name, no module prefix)",
    )
    consumer = suites.add_parser(
        "catalog-consumer", help="shared catalog reader vectors against a reader"
    )
    consumer.add_argument(
        "--driver",
        help="driver command of the reader under test (line protocol); default: the kit reader",
    )
    consumer.add_argument("--timeout", type=float, default=10.0, help="seconds per driver reply")
    recording = suites.add_parser("recording", help="provider recording against format and pin")
    recording.add_argument("recording", type=Path)
    recording.add_argument("--pin", help="pinned digest sha256:<hex> of the recording")
    static = _static_parser(suites)
    realm = _realm_parser(suites)
    for suite in (manifest, consumer, recording, static, realm, _server_parser(suites)):
        suite.add_argument("--junit", type=Path, help="write the result as JUnit XML")
    return parser


def _static_parser(
    suites: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Arguments of ``conformance static``."""
    static = suites.add_parser(
        "static",
        help="server code: generated code execution, built queries and scopes, model names",
    )
    static.add_argument("path", type=Path, nargs="+", help="server source files or directories")
    static.add_argument(
        "--root", type=Path, default=Path(), help="repository root; paths are reported from it"
    )
    static.add_argument(
        "--exceptions",
        type=Path,
        help="exception list (default: static-exceptions.toml in the root, if present)",
    )
    static.add_argument(
        "--include-dir",
        action="append",
        default=[],
        choices=sorted(SKIPPABLE_DIRS),
        metavar="NAME",
        help="also read directories with this name (for example site-packages in an image)",
    )
    static.add_argument(
        "--require-approved",
        action="store_true",
        help=(
            "reject exceptions whose approved_by does not name the security officer "
            "or says pending (joint acceptance)"
        ),
    )
    return static


def _realm_parser(
    suites: argparse._SubParsersAction[argparse.ArgumentParser],
) -> argparse.ArgumentParser:
    """Arguments of ``conformance realm``."""
    realm = suites.add_parser(
        "realm", help="clients with token exchange versus audiences (separation rule)"
    )
    source = realm.add_mutually_exclusive_group(required=True)
    source.add_argument("--export", type=Path, help="realm export file (JSON)")
    source.add_argument(
        "--admin-url",
        help="base URL of the identity provider; reads the realm through the admin API",
    )
    realm.add_argument("--realm", default="papaia", help="realm name (default: papaia)")
    realm.add_argument(
        "--token-file",
        type=Path,
        help="file with the access token of a read-only admin account "
        f"(default: ${ADMIN_TOKEN_ENV})",
    )
    realm.add_argument(
        "--timeout",
        type=_admin_timeout,
        default=10.0,
        help=f"seconds per admin request (above 0, at most {MAX_ADMIN_TIMEOUT:g})",
    )
    return realm


def _server_parser(suites: Any) -> argparse.ArgumentParser:
    """Arguments of ``conformance server``; ``suites`` is the subparsers action."""
    server: argparse.ArgumentParser = suites.add_parser(
        "server", help="a running MCP server against its declaration (CI, kit test issuer)"
    )
    server.add_argument("manifest", type=Path, help="papaia-app.yaml with the declaration")
    server.add_argument("--id", help="catalog id of the mcp entry (default: the only one)")
    server.add_argument("--url", required=True, help="MCP endpoint of the running server")
    server.add_argument("--issuer", required=True, help="base URL of the kit test issuer")
    server.add_argument("--azp", required=True, help="client released for the server")
    server.add_argument(
        "--role", action="append", default=[], help="module role the tokens carry (repeatable)"
    )
    server.add_argument(
        "--trust", choices=["addon", "platform"], default="addon", help="trust in the catalog"
    )
    server.add_argument(
        "--calls", type=Path, required=True, help='JSON {"calls": {<operation>: <arguments>}}'
    )
    server.add_argument(
        "--audit-file", type=Path, required=True, help="audit rows of the server (JSON lines)"
    )
    server.add_argument("--subject", default=DEFAULT_SUBJECT, help="sub of the test person")
    server.add_argument("--foreign-azp", default=DEFAULT_FOREIGN_AZP)
    server.add_argument("--foreign-audience", default=DEFAULT_FOREIGN_AUDIENCE)
    server.add_argument("--timeout", type=_admin_timeout, default=10.0, help="seconds per request")
    server.add_argument(
        "--audit-wait",
        type=_admin_timeout,
        default=5.0,
        help="seconds to wait for the audit rows to appear",
    )
    return server


def _admin_timeout(text: str) -> float:
    """A finite number of seconds above 0 and at most ``MAX_ADMIN_TIMEOUT``."""
    try:
        value = float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"not a number: {text[:32]!r}") from None
    if not math.isfinite(value) or not 0 < value <= MAX_ADMIN_TIMEOUT:
        raise argparse.ArgumentTypeError(
            f"expected seconds above 0 and at most {MAX_ADMIN_TIMEOUT:g}"
        )
    return value


def _collect(args: argparse.Namespace, exceptions: Exceptions) -> list[Record]:
    records: list[Record] = []
    if args.python_project:
        records += python_records(args.python_project, exceptions.verified)
    for lock in args.npm_lock:
        records += npm_records(lock)
    for path in args.records:
        records += json_records(path)
    if not (args.python_project or args.npm_lock or args.records):
        raise PolicyError("no input: pass --python-project, --npm-lock or --records")
    return records


def _exceptions_path(args: argparse.Namespace) -> Path | None:
    if args.exceptions:
        return Path(args.exceptions)
    default = Path("license-exceptions.toml")
    return default if default.is_file() else None


def _licenses(args: argparse.Namespace) -> int:
    policy = load_policy(args.policy)
    exceptions = load_exceptions(_exceptions_path(args))
    records = _collect(args, exceptions)
    if args.command == "render":
        incomplete = [r for r in records if r.problem]
        for record in incomplete:
            print(f"  {record.name} {record.version}: {record.problem}", file=sys.stderr)
        if incomplete:
            print("cannot render from an incomplete environment", file=sys.stderr)
            return EXIT_FAIL
        text = render_markdown(records, exceptions, policy)
        if args.check:
            current = args.output.read_text(encoding="utf-8") if args.output.is_file() else ""
            if current != text:
                print(
                    f"{args.output} is out of date; run papaia-kit licenses render", file=sys.stderr
                )
                return EXIT_FAIL
            return EXIT_OK
        args.output.write_text(text, encoding="utf-8")
        return EXIT_OK

    today = datetime.now(UTC).date()
    results = [
        (r, evaluate(r, policy, exceptions, today=today, edition=args.edition)) for r in records
    ]
    if args.report:
        report = {
            "kit_version": __version__,
            "packages": [{**asdict(r), "violation": reason} for r, reason in results],
        }
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    failures = [(r, reason) for r, reason in results if reason]
    for record, reason in failures:
        print(
            f"  {record.name} {record.version} ({record.ecosystem}, {record.scope}): {reason}",
            file=sys.stderr,
        )
    if failures:
        print(f"license check failed: {len(failures)} of {len(records)} packages", file=sys.stderr)
        return EXIT_FAIL
    print(f"license check passed: {len(records)} packages")
    return EXIT_OK


def _repo(args: argparse.Namespace) -> int:
    if args.command == "words":
        findings = scan_files(args.root)
        label = "denied term(s)"
    else:
        if not valid_range(args.range):
            print(f"invalid revision range {args.range!r}", file=sys.stderr)
            return EXIT_USAGE
        findings = check_commits(args.root, args.range, args.email_domain)
        label = "commit rule violation(s)"
    for finding in findings:
        print(f"  {finding.location}: {finding.message}", file=sys.stderr)
    if findings:
        print(f"{len(findings)} {label}", file=sys.stderr)
        return EXIT_FAIL
    print(f"repo {args.command}: no findings")
    return EXIT_OK


def _names(args: argparse.Namespace) -> int:
    if args.command == "list":
        rows = [{**asdict(e), "kind": e.kind.value} for e in entries(args.kind)]
        print(json.dumps(rows, indent=2))
        return EXIT_OK
    if args.command == "scope":
        try:
            print(exchange_scope(args.audience))
        except InvalidName as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_FAIL
        return EXIT_OK
    failures: list[InvalidName] = []
    for name in args.name:
        try:
            validate(name, args.kind)
        except InvalidName as exc:
            failures.append(exc)
    for failure in failures:
        print(f"  {failure}", file=sys.stderr)
    if failures:
        print(f"{len(failures)} of {len(args.name)} name(s) invalid", file=sys.stderr)
        return EXIT_FAIL
    print(f"names check: {len(args.name)} name(s) valid")
    return EXIT_OK


def _report(result: SuiteResult, junit: Path | None) -> int:
    if junit is not None:
        junit.write_bytes(junit_xml([result]))
    for item in result.failed:
        for failure in item.failures:
            print(f"  FAIL {item.group} {item.name}: {failure}", file=sys.stderr)
    print(f"conformance {result.name}: {len(result.cases)} checks, {len(result.failed)} failed")
    return EXIT_OK if result.ok else EXIT_FAIL


def _admin_token(path: Path | None) -> str:
    if path is None:
        token = os.environ.get(ADMIN_TOKEN_ENV, "")
        if not token:
            raise RealmError(f"no admin token: pass --token-file or set {ADMIN_TOKEN_ENV}")
        return token.strip()
    try:
        with path.open("rb") as handle:
            raw = handle.read(_MAX_TOKEN_FILE + 1)
    except OSError as exc:
        raise RealmError(f"cannot read the token file: {exc.strerror}") from None
    if len(raw) > _MAX_TOKEN_FILE:
        raise RealmError("token file is too large")
    try:
        return raw.decode("ascii").strip()
    except UnicodeDecodeError:
        raise RealmError("token file is not ASCII") from None


def _realm(args: argparse.Namespace) -> int:
    if args.export is not None:
        try:
            realm = load_realm_export(args.export)
        except RealmError:
            return _report(check_realm_export_file(args.export), args.junit)
    else:
        try:
            realm = read_realm_admin(
                args.admin_url,
                args.realm,
                _admin_token(args.token_file),
                fetch=UrllibFetch(),
                timeout=args.timeout,
            )
        except RealmError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_USAGE
    # The intersection is the evidence of the separation rule (RE-01); names only.
    shared = sorted(exchange_clients(realm) & audiences(realm).keys())
    print(
        f"realm {realm.name}: exchange clients and audiences intersect in {{{', '.join(shared)}}}"
    )
    return _report(check_realm(realm, source=realm.name), args.junit)


def _server(args: argparse.Namespace) -> int:
    try:
        entry = select_entry(load_manifest(args.manifest), args.id)
        target = ServerTarget(
            url=args.url,
            entry=entry,
            tokens=IssuerTokens(args.issuer, timeout=args.timeout),
            azp=args.azp,
            roles=tuple(args.role),
            calls=load_calls(args.calls, entry),
            audit_file=args.audit_file,
            trust=args.trust,
            subject=args.subject,
            foreign_azp=args.foreign_azp,
            foreign_audience=args.foreign_audience,
            timeout=args.timeout,
            audit_wait=args.audit_wait,
        )
    except (ManifestError, ServerSuiteError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    return _report(run_server_suite(target), args.junit)


def _static(args: argparse.Namespace) -> int:
    default = args.root / "static-exceptions.toml"
    listed = args.exceptions or (default if default.is_file() else None)
    try:
        result = run_static(
            args.path,
            root=args.root,
            exceptions=load_static_exceptions(listed, require_approved=args.require_approved),
            include_dirs=args.include_dir,
        )
    except (ValueError, StaticExceptionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    counts = ", ".join(f"{k.removeprefix('skipped.')} {v}" for k, v in result.properties)
    print(f"conformance static: files not read, skipped: {counts}", file=sys.stderr)
    return _report(result, args.junit)


def _conformance(args: argparse.Namespace) -> int:
    handlers = {"realm": _realm, "server": _server, "static": _static}
    if (handler := handlers.get(args.command)) is not None:
        return handler(args)
    if args.command == "manifest":
        try:
            result = check_manifest_files(
                args.manifest, compose=args.compose, core_profile=args.core_profile
            )
        except (ValueError, ManifestError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_USAGE
    elif args.command == "catalog-consumer":
        if args.driver is not None:
            try:
                driver = CommandDriver(shlex.split(args.driver), timeout=args.timeout)
            except ValueError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return EXIT_USAGE
            result = run_catalog_consumer(driver)
        else:
            result = run_catalog_consumer(KitReaderDriver)
    else:
        try:
            problems = check_recording_file(args.recording, pin=args.pin)
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return EXIT_USAGE
        name = "recording"
        result = SuiteResult(name, (case(name, args.recording.name, "recording", problems),))
    return _report(result, args.junit)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    handlers = {
        "licenses": _licenses,
        "repo": _repo,
        "names": _names,
        "conformance": _conformance,
    }
    try:
        return handlers[args.group](args)
    except EnvironmentMismatch as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_FAIL
    except PolicyError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return EXIT_USAGE
    except subprocess.CalledProcessError as exc:
        print(f"error: {' '.join(exc.cmd)} failed: {exc.stderr}", file=sys.stderr)
        return EXIT_USAGE


if __name__ == "__main__":
    sys.exit(main())
