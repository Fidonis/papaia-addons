"""Recording format of provider suites (``papaia.conformance-recording/1``).

A provider suite records request and response pairs against the running
provider, with the schema version of the contract and the digest of the
provider image. The recording is published as a CI artifact of the provider and
is the only source of golden files at consumers. A consumer pins the digest of
the recording (``recording_digest``) and checks its copy against the pin, so an
altered copy fails its run.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Iterator, Mapping
from functools import cache
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from papaia_kit._resources import schemas_dir
from papaia_kit.catalog import canonical_json

RECORDING_FORMAT = "papaia.conformance-recording/1"
RECORDING_SCHEMA = "recording.v1.schema.json"
MAX_RECORDING_BYTES = 16 * 1024 * 1024
_MAX_PROBLEMS = 20
_DIGEST = re.compile(r"sha256:[0-9a-f]{64}")
# A JSON Web Token (header and payload start with '{"'); recordings never carry one.
_TOKEN = re.compile(r"eyJ[A-Za-z0-9_-]{2,}\.eyJ[A-Za-z0-9_-]{2,}\.[A-Za-z0-9_-]*")


class RecordingError(ValueError):
    """A recording is not readable or breaks the format. Messages name places, not values."""

    def __init__(self, problems: list[str]) -> None:
        self.problems = problems[:_MAX_PROBLEMS]
        super().__init__("; ".join(self.problems))


@cache
def _validator() -> Draft202012Validator:
    schema = json.loads((schemas_dir() / RECORDING_SCHEMA).read_text(encoding="utf-8"))
    return Draft202012Validator(schema)


def _unique_members(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise RecordingError(["file: duplicate member name"])
        result[key] = value
    return result


def _strings(node: object, where: str) -> Iterator[tuple[str, str]]:
    if isinstance(node, str):
        yield where, node
    elif isinstance(node, list):
        for index, item in enumerate(node):
            yield from _strings(item, f"{where}/{index}")
    elif isinstance(node, dict):
        for key, value in node.items():
            yield from _strings(key, where)
            yield from _strings(value, f"{where}/{key}")


def _schema_problem(error: Any) -> str:
    where = "/".join(str(p) for p in error.absolute_path) or "(root)"
    text = f"{where}: fails {error.validator}"
    if error.validator == "additionalProperties" and isinstance(error.instance, dict):
        # Field names are part of the format, not recorded values: name them.
        known = error.schema.get("properties", {})
        text += f" (unexpected {sorted(str(k) for k in error.instance if k not in known)})"
    return text


def _problems(document: object) -> list[str]:
    problems = [
        _schema_problem(e)
        for e in sorted(
            _validator().iter_errors(document), key=lambda e: [str(p) for p in e.absolute_path]
        )
    ]
    problems += [
        f"{where.lstrip('/')}: looks like a token; recordings never carry tokens"
        for where, text in _strings(document, "")
        if _TOKEN.search(text)
    ]
    return problems


def load_recording(data: bytes) -> dict[str, Any]:
    """Parse and check a recording; raises ``RecordingError`` with the places that fail."""
    if len(data) > MAX_RECORDING_BYTES:
        raise RecordingError([f"file: larger than {MAX_RECORDING_BYTES} bytes"])
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        raise RecordingError(["file: not UTF-8"]) from None
    try:
        document = json.loads(text, object_pairs_hook=_unique_members)
    except RecordingError:
        raise
    except (ValueError, RecursionError):
        raise RecordingError(["file: not JSON"]) from None
    problems = _problems(document)
    if problems:
        raise RecordingError(problems)
    if not isinstance(document, dict):  # pragma: no cover - the schema requires an object
        raise RecordingError(["(root): fails type"])
    return document


def dump_recording(document: Mapping[str, Any]) -> bytes:
    """The recording as indented JSON, after the same checks ``load_recording`` applies."""
    problems = _problems(document)
    if problems:
        raise RecordingError(problems)
    text = json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True)
    return (text + "\n").encode("utf-8")


def recording_digest(document: Mapping[str, Any]) -> str:
    """``sha256:`` over the RFC 8785 canonical form; independent of formatting."""
    return "sha256:" + hashlib.sha256(canonical_json(document)).hexdigest()


def check_recording_file(path: Path, *, pin: str | None = None) -> list[str]:
    """Problems of the recording at ``path``; with ``pin``, its digest must equal the pin."""
    if pin is not None and not _DIGEST.fullmatch(pin):
        raise ValueError("pin must be sha256:<64 lower-case hex digits>")
    try:
        data = path.read_bytes()
    except OSError as exc:
        return [f"recording: cannot read ({exc.strerror or type(exc).__name__})"]
    try:
        document = load_recording(data)
    except RecordingError as exc:
        return [f"recording: {problem}" for problem in exc.problems]
    digest = recording_digest(document)
    if pin is not None and digest != pin:
        return [f"recording: digest {digest} does not match the pin {pin}"]
    return []
