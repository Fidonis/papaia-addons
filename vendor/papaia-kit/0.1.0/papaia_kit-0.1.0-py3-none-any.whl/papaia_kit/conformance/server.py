"""Server suite: a running MCP server against its declaration (architecture V-03, V-05, V-09).

The suite talks MCP (JSON-RPC over HTTP POST) to the server under test with
tokens of the kit test issuer (``testing/issuer/``) and reads the audit rows
the server wrote (JSON lines, ``papaia.audit/1``). Checks, one case each:

- ``tools-list``: ``tools/list`` reports exactly the declared operations;
- ``describe-access`` / ``check-access``: the standard operations answer in
  their shape only, without content (V-05);
- ``error-envelope``: invalid input and a missing token are answered with the
  ``error.v1`` envelope of the right class and the sent correlation id;
- ``audit-per-write``: every ``write``, ``send`` and ``delete`` operation
  writes exactly one allowed server row with the correlation id;
- ``foreign-audience``, ``foreign-azp``, ``multi-audience``: such tokens are
  refused with ``unauthenticated`` and one denied row naming the ``azp``;
  the two-audience token of the released ``--azp`` is refused in every trust
  mode, so that step 2 of the check chain is exercised on its own and not only
  through the ``azp`` allow list of step 3.

Messages name operations, tool names, fields and statuses, never a token or
any other value the server returned.
"""

from __future__ import annotations

import ipaddress
import json
import time
import urllib.error
import urllib.request
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlsplit

from papaia_kit.audit import AuditEventError, validate_event
from papaia_kit.conformance.result import SuiteResult, case
from papaia_kit.correlation import CORRELATION_HEADER, mcp_meta, new_correlation_id
from papaia_kit.errors import CONTENT_TYPE, ErrorClass, ErrorEnvelope, parse_envelope

SUITE = "server"
SERVER_CHECKS = (
    "tools-list",
    "describe-access",
    "check-access",
    "error-envelope",
    "audit-per-write",
    "foreign-audience",
    "foreign-azp",
    "multi-audience",
)
STANDARD_OPERATIONS = ("describe_access", "check_access")
WRITE_EFFECTS = frozenset({"write", "send", "delete"})
RIGHTS = frozenset({"read", "write", "delete"})
DEFAULT_FOREIGN_AZP = "papaia-kit-testclient"
DEFAULT_FOREIGN_AUDIENCE = "mcp-kit-foreign"
CHAT_CLIENT = "librechat"
DEFAULT_SUBJECT = "kit-conformance-person"
UNKNOWN_FIELD = "papaia_kit_unknown_field"
MAX_CHECK_RESOURCES = 100
MAX_RESPONSE_BYTES = 1024 * 1024
MAX_CALLS_BYTES = 64 * 1024
MAX_AUDIT_BYTES = 64 * 1024 * 1024
MAX_LIST_PAGES = 50
AUDIT_SETTLE = 0.5  # seconds: one more read for late duplicate rows
PROTOCOL_VERSION = "2025-06-18"
HTTP_OK = 200
HTTP_ERROR = 400
HTTP_UNAUTHORIZED = 401


class ServerSuiteError(ValueError):
    """Unusable input of the suite (URL, entry, calls file): exit code 2."""


class TransportError(Exception):
    """The server or the issuer could not be reached or answered unreadably."""


def check_url(url: str, what: str) -> str:
    """``url`` itself when it is https, or http on a literal loopback address."""
    parts = urlsplit(url)
    if parts.username or parts.password or parts.fragment or not parts.hostname:
        raise ServerSuiteError(f"{what} must be an absolute URL without credentials")
    if parts.scheme == "https":
        return url
    try:
        loopback = parts.scheme == "http" and ipaddress.ip_address(parts.hostname).is_loopback
    except ValueError:
        loopback = False
    if not loopback:
        raise ServerSuiteError(
            f"{what} must use https; http only on a literal loopback address such as 127.0.0.1"
        )
    return url


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args: Any, **kwargs: Any) -> None:
        return None


@dataclass(frozen=True)
class Reply:
    status: int
    content_type: str
    body: bytes
    session_id: str | None


class Http:
    """POST over urllib without proxies of the environment and without redirects."""

    def __init__(self) -> None:
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)

    def post(self, url: str, body: bytes, headers: Mapping[str, str], timeout: float) -> Reply:
        request = urllib.request.Request(url, data=body, method="POST", headers=dict(headers))  # noqa: S310 - scheme checked by check_url
        try:
            with self._opener.open(request, timeout=timeout) as response:
                return self._reply(
                    response.status, response.headers, response.read(MAX_RESPONSE_BYTES + 1)
                )
        except urllib.error.HTTPError as error:
            return self._reply(error.code, error.headers, error.read(MAX_RESPONSE_BYTES + 1))
        except (urllib.error.URLError, OSError) as error:
            raise TransportError(
                f"no answer from {urlsplit(url).netloc}: {type(error).__name__}"
            ) from None

    @staticmethod
    def _reply(status: int, headers: Any, raw: bytes) -> Reply:
        if len(raw) > MAX_RESPONSE_BYTES:
            raise TransportError("answer is larger than 1 MiB")
        content_type = str(headers.get("Content-Type", "")).split(";")[0].strip().lower()
        return Reply(status, content_type, raw, headers.get("Mcp-Session-Id"))


class TokenSource(Protocol):
    """Issues test tokens; the kit test issuer in CI."""

    def token(self, *, sub: str, azp: str, aud: str | list[str], roles: Sequence[str]) -> str: ...


class IssuerTokens:
    """Tokens from the token endpoint of the kit test issuer (``testing/issuer/``)."""

    def __init__(self, url: str, *, timeout: float = 10.0, http: Http | None = None) -> None:
        self.url = check_url(url, "issuer URL").rstrip("/")
        self.timeout = timeout
        self._http = http or Http()

    def token(self, *, sub: str, azp: str, aud: str | list[str], roles: Sequence[str]) -> str:
        body = json.dumps({"sub": sub, "azp": azp, "aud": aud, "roles": list(roles)})
        reply = self._http.post(
            f"{self.url}/token", body.encode(), {"Content-Type": "application/json"}, self.timeout
        )
        if reply.status != HTTP_OK:
            raise TransportError(f"issuer refused the token request (HTTP {reply.status})")
        try:
            value = json.loads(reply.body)["access_token"]
        except (ValueError, KeyError, TypeError):
            raise TransportError("issuer answer has no access_token") from None
        if not isinstance(value, str) or not value:
            raise TransportError("issuer answer has no access_token")
        return value


def load_calls(path: Path, entry: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """``{"calls": {<operation>: <arguments>}}``: arguments the suite passes per operation."""
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise ServerSuiteError(f"cannot read the calls file: {exc.strerror}") from None
    if len(raw) > MAX_CALLS_BYTES:
        raise ServerSuiteError("calls file is larger than 64 KiB")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ServerSuiteError("calls file is not JSON") from None
    if not isinstance(document, dict):
        raise ServerSuiteError("calls file must be a JSON object")
    if set(document) != {"calls"}:
        raise ServerSuiteError(f"calls file: unknown fields {sorted(set(document) - {'calls'})}")
    calls = document["calls"]
    if not isinstance(calls, dict):
        raise ServerSuiteError("calls file: 'calls' must be an object")
    operations = entry.get("operations")
    declared = {op.get("name") for op in operations or [] if isinstance(op, dict)}
    for name, arguments in calls.items():
        if name not in declared:
            raise ServerSuiteError(f"calls file: operation {name!r} is not declared")
        if not isinstance(arguments, dict):
            raise ServerSuiteError(f"calls file: arguments of {name!r} must be an object")
    return calls


def select_entry(document: Mapping[str, Any], catalog_id: str | None) -> dict[str, Any]:
    """The ``mcp`` entry ``catalog_id`` of a manifest, or its only ``mcp`` entry."""
    entries = [e for e in document.get("exposes", []) if isinstance(e, dict)]
    mcp = [e for e in entries if e.get("kind") == "mcp"]
    if catalog_id is not None:
        chosen = [e for e in mcp if e.get("id") == catalog_id]
        if not chosen:
            raise ServerSuiteError(f"no mcp entry {catalog_id!r} in the manifest")
        return chosen[0]
    if len(mcp) != 1:
        raise ServerSuiteError(f"the manifest has {len(mcp)} mcp entries; name one with --id")
    return mcp[0]


@dataclass(frozen=True)
class ServerTarget:
    """The server under test and what the suite needs to drive it."""

    url: str
    entry: Mapping[str, Any]
    tokens: TokenSource
    azp: str
    roles: tuple[str, ...]
    calls: Mapping[str, Mapping[str, Any]]
    audit_file: Path
    trust: str = "addon"
    subject: str = DEFAULT_SUBJECT
    foreign_azp: str = DEFAULT_FOREIGN_AZP
    foreign_audience: str = DEFAULT_FOREIGN_AUDIENCE
    timeout: float = 10.0
    audit_wait: float = 5.0
    audit_settle: float = AUDIT_SETTLE

    def __post_init__(self) -> None:
        check_url(self.url, "server URL")
        entry = self.entry
        if entry.get("kind") != "mcp":
            raise ServerSuiteError("the server suite checks mcp entries only")
        if not isinstance(entry.get("id"), str) or not isinstance(entry.get("audience"), str):
            raise ServerSuiteError("the entry needs an id and an audience")
        operations = entry.get("operations")
        if not isinstance(operations, list) or not all(
            isinstance(op, dict) and isinstance(op.get("name"), str) for op in operations
        ):
            raise ServerSuiteError("the entry needs a list of named operations")
        if not isinstance(entry.get("identity", []), list):
            raise ServerSuiteError("identity of the entry must be a list")
        if self.trust not in ("addon", "platform"):
            raise ServerSuiteError("trust must be addon or platform")
        if self.trust == "platform" and self.azp == CHAT_CLIENT:
            # Step 2 needs a released client whose two-audience token must be
            # refused; the chat is the one client allowed several audiences.
            raise ServerSuiteError(
                f"at trust platform --azp must name a released client other than {CHAT_CLIENT}"
            )

    @property
    def catalog_id(self) -> str:
        return str(self.entry.get("id"))

    @property
    def audience(self) -> str:
        return str(self.entry.get("audience"))

    def operations(self) -> list[Mapping[str, Any]]:
        return [op for op in self.entry.get("operations", []) if op.get("via") == "tools"]

    def person_rights(self) -> bool:
        return "person" in self.entry.get("identity", [])


@dataclass
class _Expect:
    """An audit row the server must have written for one correlation id."""

    check: str
    correlation_id: str
    result: str
    azp: str
    operation: str | None = None
    effect: str | None = None


@dataclass
class _Run:
    target: ServerTarget
    http: Http
    session_id: str | None = None
    token: str = ""
    issued: list[str] = field(default_factory=list)
    expects: list[_Expect] = field(default_factory=list)
    failures: dict[str, list[str]] = field(default_factory=dict)
    next_id: int = 0

    def fail(self, check: str, message: str) -> None:
        self.failures.setdefault(check, []).append(message)

    def issue(self, azp: str, aud: str | list[str]) -> str:
        target = self.target
        value = target.tokens.token(sub=target.subject, azp=azp, aud=aud, roles=target.roles)
        self.issued.append(value)
        return value

    def send(
        self, method: str, params: dict[str, Any] | None, *, token: str | None, cid: str
    ) -> tuple[Reply, dict[str, Any] | None]:
        """One JSON-RPC request; the reply and the response message, if one could be read."""
        self.next_id += 1
        message: dict[str, Any] = {"jsonrpc": "2.0", "id": self.next_id, "method": method}
        if params is not None:
            message["params"] = params
        reply = self.http.post(
            self.target.url,
            json.dumps(message).encode(),
            self._headers(token, cid),
            self.target.timeout,
        )
        return reply, _response_message(reply, self.next_id)

    def notify(self, method: str, *, cid: str) -> None:
        message = {"jsonrpc": "2.0", "method": method}
        self.http.post(
            self.target.url,
            json.dumps(message).encode(),
            self._headers(self.token, cid),
            self.target.timeout,
        )

    def _headers(self, token: str | None, cid: str) -> dict[str, str]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            CORRELATION_HEADER: cid,
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
            headers["MCP-Protocol-Version"] = PROTOCOL_VERSION
        return headers

    def call(
        self, name: str, arguments: Mapping[str, Any], *, token: str | None, cid: str
    ) -> tuple[Reply, dict[str, Any] | None]:
        params = {"name": name, "arguments": dict(arguments), "_meta": mcp_meta(cid)}
        return self.send("tools/call", params, token=token, cid=cid)


def _response_message(reply: Reply, request_id: int) -> dict[str, Any] | None:
    """The JSON-RPC response of ``request_id`` in a JSON or event-stream answer."""
    try:
        text = reply.body.decode("utf-8")
    except UnicodeDecodeError:
        return None
    candidates: list[str] = []
    if reply.content_type == "text/event-stream":
        candidates = [line[5:].strip() for line in text.splitlines() if line.startswith("data:")]
    elif reply.content_type == "application/json":
        candidates = [text]
    for candidate in candidates:
        try:
            message = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(message, dict) and message.get("id") == request_id:
            return message
    return None


def _payload(  # noqa: PLR0911 - one return per way a tool answer can fail
    message: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, str | None]:
    """The structured result of a successful tool call, or why there is none."""
    if message is None:
        return None, "no JSON-RPC response"
    if "error" in message:
        error = message["error"]
        data = error.get("data") if isinstance(error, dict) else None
        cls = data.get("class") if isinstance(data, dict) else None
        if isinstance(cls, str) and cls in {c.value for c in ErrorClass}:
            return None, f"answered with error class {cls}"
        return None, "answered with an error"
    result = message.get("result")
    if not isinstance(result, dict):
        return None, "response has no result object"
    if result.get("isError") is True:
        return None, "tool result is an error"
    structured = result.get("structuredContent")
    if isinstance(structured, dict):
        return structured, None
    content = result.get("content")
    if isinstance(content, list) and len(content) == 1 and isinstance(content[0], dict):
        try:
            parsed = json.loads(content[0].get("text", ""))
        except (TypeError, json.JSONDecodeError):
            parsed = None
        if isinstance(parsed, dict):
            return parsed, None
    return None, "result carries no structured object"


def _envelope(  # noqa: PLR0911 - one return per way an error answer can fail
    reply: Reply, message: dict[str, Any] | None
) -> tuple[ErrorEnvelope | None, str]:
    """The ``error.v1`` envelope of an error answer, or why there is none."""
    if reply.status >= HTTP_ERROR:
        if reply.content_type != CONTENT_TYPE:
            return None, f"HTTP {reply.status} without {CONTENT_TYPE}"
        try:
            body = json.loads(reply.body)
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None, f"HTTP {reply.status} body is not JSON"
        where = "problem body"
    else:
        if message is None:
            return None, f"HTTP {reply.status} without a JSON-RPC response"
        error = message.get("error")
        if not isinstance(error, dict):
            return None, "not refused: the call succeeded"
        if "data" not in error:
            return None, "JSON-RPC error without error.data envelope"
        body = error["data"]
        where = "error.data"
    try:
        envelope = parse_envelope(body)
    except ValueError as exc:
        return None, f"{where} is no valid error envelope ({exc})"
    if reply.status >= HTTP_ERROR and envelope.status != reply.status:
        return None, f"envelope status {envelope.status} differs from HTTP {reply.status}"
    return envelope, ""


def _exact_keys(value: object, keys: set[str], where: str) -> list[str]:
    if not isinstance(value, dict):
        return [f"{where} is not an object"]
    problems = [
        f"{where} returns the field {key!r} (no content allowed)"
        for key in sorted(set(value) - keys)
    ]
    problems += [f"{where} lacks the field {key!r}" for key in sorted(keys - set(value))]
    return problems


# -- checks ---------------------------------------------------------------


def _tools_list(run: _Run) -> None:
    reported: list[str] = []
    page: str | None = None
    for _ in range(MAX_LIST_PAGES):
        params = {"cursor": page} if page else None
        _, message = run.send("tools/list", params, token=run.token, cid=new_correlation_id())
        result = message.get("result") if message else None
        if not isinstance(result, dict) or not isinstance(result.get("tools"), list):
            run.fail("tools-list", "tools/list returned no tool list")
            return
        for tool in result["tools"]:
            name = tool.get("name") if isinstance(tool, dict) else None
            if not isinstance(name, str):
                run.fail("tools-list", "tools/list reports a tool without a name")
                continue
            if not isinstance(tool.get("inputSchema"), dict):
                run.fail("tools-list", f"tool {name[:64]!r} has no inputSchema object")
            reported.append(name)
        following = result.get("nextCursor")
        page = following if isinstance(following, str) and following else None
        if page is None:
            break
    if page is not None:
        run.fail("tools-list", f"tools/list still names a next page after {MAX_LIST_PAGES} pages")
        return
    declared = [str(op.get("name")) for op in run.target.operations()]
    for name in sorted({n for n in reported if reported.count(n) > 1}):
        run.fail("tools-list", f"tool {name[:64]!r} is reported more than once")
    for name in sorted(set(reported) - set(declared)):
        run.fail(
            "tools-list",
            f"tool {name[:64]!r} is reported but not declared; consumers treat it as the "
            "highest data class and refuse writes (contract_mismatch)",
        )
    for name in sorted(set(declared) - set(reported)):
        run.fail("tools-list", f"operation {name!r} is declared but not reported")


def _declared(run: _Run, check: str, name: str) -> bool:
    if name in {op.get("name") for op in run.target.operations()}:
        return True
    run.fail(check, f"standard operation {name!r} is not declared (V-05, person rights)")
    return False


def _describe_access(run: _Run) -> None:
    check = "describe-access"
    if not _declared(run, check, "describe_access"):
        return
    _, message = run.call("describe_access", {}, token=run.token, cid=new_correlation_id())
    payload, problem = _payload(message)
    if payload is None:
        run.fail(check, f"describe_access: {problem}")
        return
    problems = _exact_keys(payload, {"scopes", "as_of"}, "describe_access")
    scopes = payload.get("scopes")
    if not isinstance(scopes, list):
        problems.append("describe_access: scopes is not a list")
        scopes = []
    if not isinstance(payload.get("as_of"), str):
        problems.append("describe_access: as_of is not a string")
    for index, scope in enumerate(scopes):
        where = f"describe_access scopes[{index}]"
        problems += _exact_keys(
            scope, {"resource_type", "ids_or_pattern", "rights"}, "describe_access"
        )
        if not isinstance(scope, dict):
            continue
        if not isinstance(scope.get("resource_type"), str):
            problems.append(f"{where}: resource_type is not a string")
        ids = scope.get("ids_or_pattern")
        if not (
            isinstance(ids, str) or (isinstance(ids, list) and all(isinstance(i, str) for i in ids))
        ):
            problems.append(f"{where}: ids_or_pattern is neither a pattern nor a list of ids")
        rights = scope.get("rights")
        if (
            not isinstance(rights, list)
            or not set(map(str, rights)) <= RIGHTS
            or len(set(map(str, rights))) != len(rights)
        ):
            problems.append(f"{where}: rights must be distinct values of read, write, delete")
    for item in problems:
        run.fail(check, item)


def _check_access(run: _Run) -> None:
    check = "check-access"
    if not _declared(run, check, "check_access"):
        return
    arguments = run.target.calls.get("check_access")
    if arguments is None:
        run.fail(check, "no call arguments for 'check_access' (pass them with --calls)")
        return
    resources = arguments.get("resources")
    if not isinstance(resources, list) or not resources:
        run.fail(check, "call arguments of 'check_access' need a non-empty resources list")
        return
    _, message = run.call("check_access", arguments, token=run.token, cid=new_correlation_id())
    payload, problem = _payload(message)
    if payload is None:
        run.fail(check, f"check_access: {problem}")
        return
    problems = _exact_keys(payload, {"results"}, "check_access")
    results = payload.get("results")
    if not isinstance(results, list):
        problems.append("check_access: results is not a list")
        results = []
    for index, row in enumerate(results):
        problems += _exact_keys(row, {"type", "id", "allowed"}, "check_access")
        if isinstance(row, dict) and not isinstance(row.get("allowed"), bool):
            problems.append(f"check_access results[{index}]: allowed is not a boolean")
    asked = [(r.get("type"), r.get("id")) for r in resources if isinstance(r, dict)]
    answered = [(r.get("type"), r.get("id")) for r in results if isinstance(r, dict)]
    if asked != answered:
        problems.append("check_access: results do not answer the asked resources in order")
    oversized = {**arguments, "resources": [resources[0]] * (MAX_CHECK_RESOURCES + 1)}
    _, message = run.call("check_access", oversized, token=run.token, cid=new_correlation_id())
    if _payload(message)[0] is not None:
        problems.append(f"check_access accepts more than {MAX_CHECK_RESOURCES} resources")
    for item in problems:
        run.fail(check, item)


def _probe_operation(run: _Run) -> tuple[str, Mapping[str, Any]] | None:
    """A read operation with arguments, for calls that must be refused or fail."""
    for op in run.target.operations():
        name = str(op.get("name"))
        if op.get("effect") != "read":
            continue
        if name == "describe_access":
            return name, {}
        if name in run.target.calls:
            return name, run.target.calls[name]
    return None


def _expect_error(
    run: _Run,
    check: str,
    label: str,
    answer: tuple[Reply, dict[str, Any] | None],
    *,
    expected: ErrorClass,
    cid: str,
) -> None:
    reply, message = answer
    envelope, problem = _envelope(reply, message)
    if envelope is None:
        run.fail(check, f"{label}: {problem}")
        return
    if envelope.error_class is not expected:
        run.fail(check, f"{label}: class {envelope.error_class.value}, expected {expected.value}")
    if envelope.correlation_id != cid:
        run.fail(check, f"{label}: envelope does not carry the sent correlation id")
    http_error = reply.status >= HTTP_ERROR
    if expected is ErrorClass.UNAUTHENTICATED and http_error and reply.status != HTTP_UNAUTHORIZED:
        run.fail(check, f"{label}: HTTP {reply.status}, expected 401")


def _error_envelope(run: _Run) -> None:
    check = "error-envelope"
    probe = _probe_operation(run)
    if probe is None:
        run.fail(check, "no read operation with call arguments to send invalid input to")
        return
    name, arguments = probe
    cid = new_correlation_id()
    reply, message = run.call(name, {**arguments, UNKNOWN_FIELD: True}, token=run.token, cid=cid)
    _expect_error(
        run,
        check,
        f"{name} with an unknown field",
        (reply, message),
        expected=ErrorClass.INVALID_INPUT,
        cid=cid,
    )
    cid = new_correlation_id()
    reply, message = run.call(name, arguments, token=None, cid=cid)
    _expect_error(
        run,
        check,
        f"{name} without a token",
        (reply, message),
        expected=ErrorClass.UNAUTHENTICATED,
        cid=cid,
    )


def _audit_per_write(run: _Run) -> None:
    check = "audit-per-write"
    for op in run.target.operations():
        effect = str(op.get("effect"))
        if effect not in WRITE_EFFECTS:
            continue
        name = str(op.get("name"))
        arguments = run.target.calls.get(name)
        if arguments is None:
            run.fail(check, f"no call arguments for {name!r} (pass them with --calls)")
            continue
        cid = new_correlation_id()
        _, message = run.call(name, arguments, token=run.token, cid=cid)
        payload, problem = _payload(message)
        if payload is None:
            run.fail(check, f"{name}: {problem}")
            continue
        run.expects.append(_Expect(check, cid, "allowed", run.target.azp, name, effect))


def _refused(run: _Run, check: str, label: str, azp: str, aud: str | list[str]) -> None:
    probe = _probe_operation(run)
    if probe is None:
        run.fail(check, "no read operation with call arguments to present the token to")
        return
    name, arguments = probe
    token = run.issue(azp, aud)
    cid = new_correlation_id()
    reply, message = run.call(name, arguments, token=token, cid=cid)
    _expect_error(run, check, label, (reply, message), expected=ErrorClass.UNAUTHENTICATED, cid=cid)
    run.expects.append(_Expect(check, cid, "denied", azp))


def _foreign_audience(run: _Run) -> None:
    target = run.target
    _refused(
        run,
        "foreign-audience",
        f"token for {target.foreign_audience}",
        target.azp,
        target.foreign_audience,
    )


def _foreign_azp(run: _Run) -> None:
    target = run.target
    _refused(
        run, "foreign-azp", f"token of {target.foreign_azp}", target.foreign_azp, target.audience
    )


def _multi_audience(run: _Run) -> None:
    check = "multi-audience"
    target = run.target
    both = [target.audience, target.foreign_audience]
    # The released --azp passes step 3, so only step 2 can refuse its token.
    # At trust platform --azp is never the chat (ServerTarget refuses that).
    _refused(run, check, f"token of {target.azp} with two audiences", target.azp, both)
    if target.trust == "addon":
        _refused(run, check, f"token of {CHAT_CLIENT} with two audiences", CHAT_CLIENT, both)
        return
    probe = _probe_operation(run)
    if probe is None:
        return
    name, arguments = probe
    _, message = run.call(
        name, arguments, token=run.issue(CHAT_CLIENT, both), cid=new_correlation_id()
    )
    payload, problem = _payload(message)
    if payload is None:
        run.fail(
            check, f"token of {CHAT_CLIENT} with two audiences at a platform server: {problem}"
        )


_CHECKS = {
    "tools-list": _tools_list,
    "describe-access": _describe_access,
    "check-access": _check_access,
    "error-envelope": _error_envelope,
    "foreign-audience": _foreign_audience,
    "foreign-azp": _foreign_azp,
    "multi-audience": _multi_audience,
    # Writes last: they may change what the read checks above look at.
    "audit-per-write": _audit_per_write,
}


# -- audit ----------------------------------------------------------------


def _read_audit(path: Path) -> tuple[list[tuple[str, dict[str, Any]]], str | None]:
    try:
        with path.open("rb") as handle:
            raw = handle.read(MAX_AUDIT_BYTES + 1)
    except FileNotFoundError:
        return [], None
    except OSError as exc:
        return [], f"cannot read the audit file: {exc.strerror}"
    if len(raw) > MAX_AUDIT_BYTES:
        return [], f"audit file is larger than {MAX_AUDIT_BYTES} bytes"
    rows: list[tuple[str, dict[str, Any]]] = []
    for number, line in enumerate(raw.decode("utf-8", errors="replace").splitlines(), 1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            return rows, f"audit file line {number} is not JSON"
        if isinstance(row, dict):
            rows.append((line, row))
    return rows, None


def _matches(expect: _Expect, row: Mapping[str, Any], catalog_id: str) -> bool:
    if row.get("event") != "operation" or row.get("role") != "server":
        return False
    if row.get("result") != expect.result or row.get("azp") != expect.azp:
        return False
    if expect.operation is None:
        return True
    return (
        row.get("operation") == expect.operation
        and row.get("effect") == expect.effect
        and row.get("catalog_id") == catalog_id
    )


def _check_audit(run: _Run) -> None:
    if not run.expects:
        return
    deadline = time.monotonic() + run.target.audit_wait
    catalog_id = run.target.catalog_id
    while True:
        rows, problem = _read_audit(run.target.audit_file)
        found = {
            e.correlation_id
            for e in run.expects
            if any(_matches(e, row, catalog_id) for _, row in rows)
        }
        if problem or time.monotonic() >= deadline:
            break
        if len(found) == len({e.correlation_id for e in run.expects}):
            # Every row is there once; read again after a settle interval so
            # that a late duplicate of an asynchronous writer is counted too.
            time.sleep(run.target.audit_settle)
            rows, problem = _read_audit(run.target.audit_file)
            break
        time.sleep(0.1)
    if problem:
        for check in {e.check for e in run.expects}:
            run.fail(check, problem)
        return
    for expect in run.expects:
        own = [
            (line, row) for line, row in rows if row.get("correlation_id") == expect.correlation_id
        ]
        hits = sum(1 for _, row in own if _matches(expect, row, catalog_id))
        what = f"{expect.operation}" if expect.operation else f"rejection of {expect.azp}"
        if hits != 1:
            run.fail(
                expect.check,
                f"{what}: {hits} {expect.result} server audit rows with the correlation id, "
                "expected 1",
            )
        if expect.result == "denied" and any(row.get("result") == "allowed" for _, row in own):
            run.fail(expect.check, f"{what}: an allowed audit row was written for a refused token")
        for line, row in own:
            if any(token in line for token in run.issued + [run.token]):
                run.fail(expect.check, f"{what}: an audit row carries the bearer token")
            try:
                validate_event(row)
            except AuditEventError as exc:
                run.fail(
                    expect.check,
                    f"{what}: audit row breaks papaia.audit/1: {'; '.join(exc.problems[:3])}",
                )


# -- suite ----------------------------------------------------------------


def _start(run: _Run) -> str | None:
    """Token and MCP session for the checks; the reason when they cannot run."""
    target = run.target
    try:
        run.token = run.issue(target.azp, target.audience)
        cid = new_correlation_id()
        params = {
            "protocolVersion": PROTOCOL_VERSION,
            "capabilities": {},
            "clientInfo": {"name": "papaia-kit-conformance", "version": "1"},
        }
        reply, message = run.send("initialize", params, token=run.token, cid=cid)
        if message is None or not isinstance(message.get("result"), dict):
            return f"initialize failed (HTTP {reply.status})"
        run.session_id = reply.session_id
        run.notify("notifications/initialized", cid=cid)
    except TransportError as exc:
        return str(exc)
    return None


def run_server_suite(target: ServerTarget, *, http: Http | None = None) -> SuiteResult:
    """Run every check of the server suite against ``target``; never skips a check."""
    started = time.monotonic()
    run = _Run(target, http or Http())
    checks = [
        c
        for c in SERVER_CHECKS
        if target.person_rights() or c not in ("describe-access", "check-access")
    ]
    blocked = _start(run)
    for name, check in _CHECKS.items():
        if name not in checks:
            continue
        if blocked is not None:
            run.fail(name, f"cannot run: {blocked}")
            continue
        try:
            check(run)
        except TransportError as exc:
            run.fail(name, str(exc))
    if blocked is None:
        _check_audit(run)
    cases = tuple(
        case(SUITE, target.catalog_id, name, run.failures.get(name, [])) for name in checks
    )
    return SuiteResult(SUITE, cases, time.monotonic() - started)
