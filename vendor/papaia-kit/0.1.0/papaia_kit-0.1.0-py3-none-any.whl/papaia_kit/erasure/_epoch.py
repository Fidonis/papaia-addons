"""The ``epoch`` file at the backup target and the state epoch check at module start.

A module state can come back without ``papaia-ctl restore``: a hypervisor
restores a VM backup, or volumes are copied back by hand. No ``erasure-replay``
runs then. At start every module therefore compares the erasure seq it applied
(kept in its own database) with the journal at the backup target, the mirror
and its local copy (sicherheit §4.9 (2), betrieb BE-16a). Behind the journal it
does not report ready, accepts no request and runs no background work until the
core applies the journal through ``POST /internal/lifecycle``.
"""

from __future__ import annotations

import contextlib
import json
import os
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from types import MappingProxyType
from typing import Literal

from papaia_kit.audit import AUDIT_FORMAT, validate_event
from papaia_kit.correlation import new_correlation_id
from papaia_kit.erasure._entry import (
    MAX_SEQ,
    JournalCorruptError,
    JournalUnavailableError,
    check_module,
    format_at,
)
from papaia_kit.erasure._journal import ErasureJournal, PlaceState
from papaia_kit.errors import ErrorEnvelope, build_envelope

EPOCH_FILE = "epoch"
EPOCH_FORMAT = "papaia.erasure-epoch/1"
EPOCH_SCHEMA = "erasure-epoch.v1.schema.json"
MAX_EPOCH_BYTES = 64 * 1024
MAX_EPOCH_SOURCES = 256

STATE_EPOCH_BEHIND_MESSAGE = (
    "Datenstand älter als das Löschjournal (z. B. nach Rückspielen einer VM-Sicherung). "
    "Ausführen: papaia-ctl recover-snapshot"
)
STATE_EPOCH_UNVERIFIED_MESSAGE = (
    "Löschjournal am Sicherungsziel nicht erreichbar; der Datenstand ist nur vorläufig "
    "gegen Spiegel oder lokale Kopie geprüft. Prüfen: papaia-ctl doctor erasure_journal"
)
STATE_EPOCH_UNKNOWN_MESSAGE = (
    "Datenstand nicht prüfbar: Löschjournal am Sicherungsziel nicht erreichbar und weder "
    "Spiegel noch lokale Kopie vorhanden. Prüfen: papaia-ctl doctor erasure_journal"
)

RECHECK_UNVERIFIED_SECONDS = 15 * 60
RECHECK_NOT_READY_SECONDS = 60
NOT_READY_RETRY_AFTER = 60

_FILE_MODE = 0o640
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_O_CLOEXEC = getattr(os, "O_CLOEXEC", 0)

Doctor = Literal["pass", "warn", "fail"]
Health = Literal["ok", "degraded", "down"]
AuditSink = Callable[[dict[str, object]], object]


# --- epoch file ------------------------------------------------------------------


def _check_count(value: object, name: str) -> int:
    if type(value) is not int or not 0 <= value <= MAX_SEQ:
        raise ValueError(f"{name} must be an integer from 0 to 2**53-1")
    return value


@dataclass(frozen=True)
class Epoch:
    """Content of ``<backup target>/erasure-journal/epoch``, kept by the core.

    ``generation`` rises with every ``restore``, ``rollback``,
    ``recover-snapshot`` and every run of the core start gate that found a
    backlog; ``seq`` holds the last journal seq per module and core source.
    """

    generation: int
    seq: Mapping[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _check_count(self.generation, "generation")
        given: object = self.seq  # checked at run time: callers are not always typed
        if not isinstance(given, Mapping) or len(given) > MAX_EPOCH_SOURCES:
            raise ValueError(f"seq must map at most {MAX_EPOCH_SOURCES} modules to a seq")
        checked: dict[str, int] = {}
        for module, value in given.items():
            checked[check_module(module)] = _check_count(value, "seq")
        object.__setattr__(self, "seq", MappingProxyType(dict(sorted(checked.items()))))

    def seq_of(self, module: str) -> int:
        return self.seq.get(module, 0)

    def to_json(self) -> str:
        record = {"format": EPOCH_FORMAT, "generation": self.generation, "seq": dict(self.seq)}
        return json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n"


def _unique_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    record = dict(pairs)
    if len(record) != len(pairs):
        raise ValueError("duplicate field")
    return record


def _refuse_constant(name: str) -> object:
    raise ValueError("not plain JSON")


def _parse_epoch(data: bytes) -> Epoch:
    if len(data) > MAX_EPOCH_BYTES:
        raise ValueError("file too large")
    record = json.loads(
        data.decode("utf-8"), object_pairs_hook=_unique_keys, parse_constant=_refuse_constant
    )
    if not isinstance(record, dict) or set(record) != {"format", "generation", "seq"}:
        raise ValueError("unknown or missing fields")
    if record["format"] != EPOCH_FORMAT:
        raise ValueError("unknown format")
    seq = record["seq"]
    if not isinstance(seq, dict):
        raise ValueError("seq is not an object")
    return Epoch(generation=record["generation"], seq=seq)


def read_epoch(target_dir: Path) -> Epoch | None:
    """The ``epoch`` file in ``target_dir`` (``<backup target>/erasure-journal``).

    ``None`` if the directory holds no ``epoch`` file yet. A missing directory
    or a symlink in place of the file raises :class:`JournalUnavailableError`
    (an unmounted target never looks like a fresh one); a malformed file raises
    :class:`JournalCorruptError` without repeating its content.
    """
    directory = Path(target_dir)
    if not directory.is_dir():
        raise JournalUnavailableError("target: journal directory is missing")
    try:
        fd = os.open(directory / EPOCH_FILE, os.O_RDONLY | _O_NOFOLLOW | _O_CLOEXEC)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise JournalUnavailableError(f"epoch: {exc.strerror}") from None
    try:
        with os.fdopen(fd, "rb") as fh:
            data = fh.read(MAX_EPOCH_BYTES + 1)
    except OSError as exc:
        raise JournalUnavailableError(f"epoch: {exc.strerror}") from None
    try:
        return _parse_epoch(data)
    except (ValueError, UnicodeDecodeError, RecursionError) as exc:
        reason = exc.args[0] if isinstance(exc, ValueError) and exc.args else "not valid"
        if not isinstance(reason, str) or isinstance(exc, json.JSONDecodeError):
            reason = "not valid JSON"
        raise JournalCorruptError(f"epoch: {reason}") from None


def write_epoch(target_dir: Path, epoch: Epoch) -> None:
    """Replace the ``epoch`` file atomically (core only; modules only read it)."""
    if not isinstance(epoch, Epoch):
        raise TypeError("epoch must be an Epoch")
    directory = Path(target_dir)
    if not directory.is_dir():
        raise JournalUnavailableError("target: journal directory is missing")
    tmp = directory / f".{EPOCH_FILE}.{os.getpid()}.{threading.get_ident()}.tmp"
    payload = epoch.to_json().encode("ascii")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _O_NOFOLLOW | _O_CLOEXEC, _FILE_MODE)
    try:
        try:
            view = memoryview(payload)
            while view:
                view = view[os.write(fd, view) :]
            os.fsync(fd)
        finally:
            os.close(fd)
        os.replace(tmp, directory / EPOCH_FILE)
    except BaseException:
        with contextlib.suppress(OSError):
            tmp.unlink()
        raise
    dir_fd = os.open(directory, os.O_RDONLY | _O_CLOEXEC)
    try:
        os.fsync(dir_fd)
    finally:
        os.close(dir_fd)


# --- start check -----------------------------------------------------------------


class EpochState(StrEnum):
    """Result of the start check (``doctor state_epoch``).

    ``current``: checked against the backup target, no backlog (ready, pass).
    ``unverified``: the target is not usable; mirror or local copy show no
    backlog (ready provisionally, warn, recheck every 15 min).
    ``behind``: entries beyond the module's applied seq in any place that
    could be read, damaged or conflicting places included (not ready, fail).
    ``unknown``: nothing to check against, or the module's applied seq is
    unreadable (not ready, fail).
    """

    CURRENT = "current"
    UNVERIFIED = "unverified"
    BEHIND = "behind"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class StateEpochCheck:
    """Outcome of one start check; carries numbers and place names, never journal content."""

    module: str
    state: EpochState
    applied_seq: int | None
    journal_seq: int | None
    generation: int | None
    checked_against: tuple[str, ...]
    problems: tuple[str, ...] = ()

    @property
    def ready(self) -> bool:
        return self.state in (EpochState.CURRENT, EpochState.UNVERIFIED)

    @property
    def journal_behind(self) -> bool:
        """The journal is shorter than the module state (for example an older target copy)."""
        return (
            self.applied_seq is not None
            and self.journal_seq is not None
            and self.journal_seq < self.applied_seq
        )

    @property
    def doctor(self) -> Doctor:
        if not self.ready:
            return "fail"
        if self.state is EpochState.UNVERIFIED or self.journal_behind:
            return "warn"
        return "pass"

    @property
    def message(self) -> str | None:
        """Operator sentence (German) for log, status and ``doctor state_epoch``."""
        return {
            EpochState.BEHIND: STATE_EPOCH_BEHIND_MESSAGE,
            EpochState.UNVERIFIED: STATE_EPOCH_UNVERIFIED_MESSAGE,
            EpochState.UNKNOWN: STATE_EPOCH_UNKNOWN_MESSAGE,
        }.get(self.state)

    @property
    def recheck_after(self) -> int | None:
        """Seconds until the next check; ``None`` once checked against the target."""
        if self.state is EpochState.UNVERIFIED:
            return RECHECK_UNVERIFIED_SECONDS
        if self.state is EpochState.CURRENT:
            return None
        return RECHECK_NOT_READY_SECONDS

    @property
    def audit_event(self) -> str | None:
        if self.state is EpochState.BEHIND:
            return "state_epoch_behind"
        if self.state is EpochState.UNVERIFIED:
            return "state_epoch_unverified"
        if self.state is EpochState.UNKNOWN:
            return "state_epoch_unknown"
        return None

    @property
    def backlog(self) -> int:
        if self.applied_seq is None or self.journal_seq is None:
            return 0
        return max(self.journal_seq - self.applied_seq, 0)


def _check_applied(applied_seq: object) -> int:
    if type(applied_seq) is not int:
        raise TypeError("applied_seq must be an integer")
    if not 0 <= applied_seq <= MAX_SEQ:
        raise ValueError("applied_seq must be from 0 to 2**53-1")
    return applied_seq


def check_state_epoch(journal: ErasureJournal, applied_seq: int) -> StateEpochCheck:
    """Compare the module's applied seq with the journal (sicherheit §4.9 (2)).

    Sources: the journal at the backup target and its ``epoch`` file, the mirror
    and the local copy. Only a usable target with a readable (or not yet
    written) ``epoch`` gives a verified result; otherwise the check against the
    mirror and the local copy is provisional, because the local copy may come
    from the same VM backup as the module. Never raises for a place; writes
    nothing.
    """
    if not isinstance(journal, ErasureJournal):
        raise TypeError("journal must be an ErasureJournal")
    applied = _check_applied(applied_seq)
    local, target, mirror, renumbered_from = journal._check_view()
    problems = [p.problem for p in (local, target, mirror) if p is not None and p.problem]

    epoch: Epoch | None = None
    epoch_ok = False
    if target.state is not PlaceState.UNREACHABLE:
        try:
            epoch = read_epoch(journal.target_dir)
            epoch_ok = True
        except (JournalCorruptError, JournalUnavailableError) as exc:
            problems.append(str(exc))

    places = [p for p in (target, local, mirror) if p is not None and p.usable]
    checked = tuple(p.name for p in places)
    if epoch is not None:
        checked += ("epoch",)
    # Fail closed: a damaged or conflicting place is never trusted for
    # ``current``, but every entry it still holds counts towards a backlog. A
    # target with one bad line must not hide entries beyond the applied seq
    # and leave only a local copy from the same VM backup to compare with.
    read = [
        p
        for p in (target, local, mirror)
        if p is not None and p.state is not PlaceState.UNREACHABLE
    ]
    ends = [e.seq for p in read for e in p.entries.values()]
    ends += [seq for p in read for seq in p.salvaged.values()]
    if epoch is not None:
        ends.append(epoch.seq_of(journal.module))
    journal_seq = max(ends, default=0) if places or ends else None
    verified = target.usable and epoch_ok

    if journal_seq is not None and (journal_seq > applied or renumbered_from is not None):
        state = EpochState.BEHIND
        if renumbered_from is not None:
            problems.append(f"entry renumbered from seq {renumbered_from}")
    elif verified:
        state = EpochState.CURRENT
    elif places:
        state = EpochState.UNVERIFIED
    else:
        state = EpochState.UNKNOWN
    return StateEpochCheck(
        module=journal.module,
        state=state,
        applied_seq=applied,
        journal_seq=journal_seq,
        generation=None if epoch is None else epoch.generation,
        checked_against=checked,
        problems=tuple(problems),
    )


class ModuleNotReadyError(Exception):
    """The module is behind the journal or its state is unknown; refuse the request."""

    def __init__(self, check: StateEpochCheck | None) -> None:
        self.check = check
        super().__init__(
            "module not ready: " + ("not checked yet" if check is None else check.state)
        )

    def envelope(self, correlation_id: object, *, lang: str = "de") -> ErrorEnvelope:
        """Error envelope for the refused request: ``PK-UPSTREAM-001``, 503, retry after 60 s."""
        return build_envelope(
            "PK-UPSTREAM-001",
            correlation_id=correlation_id,
            lang=lang,
            status=503,
            retry_after=NOT_READY_RETRY_AFTER,
        )


def _now() -> datetime:
    return datetime.now(UTC)


class StartGate:
    """Readiness of one module against its erasure journal.

    Run :meth:`check` at start, before the module serves anything; until then
    it is not ready. Call :meth:`require_ready` on every request (except
    ``POST /internal/lifecycle``) and :meth:`background_allowed` before every
    step, schedule, trigger rule, delivery, erasure run or redemption of a
    delegation. Call :meth:`check_if_due` periodically (every minute is
    enough); a provisional result is checked again every 15 minutes and drops
    readiness at once when it shows a backlog. The gate never replays: the core
    does, through :class:`LifecycleHandler`.

    With ``audit`` set, every change of state into ``behind``, ``unverified``
    or ``unknown`` writes one ``papaia.audit/1`` submission
    (``state_epoch_behind``, ``state_epoch_unverified`` with result
    ``allowed`` or ``state_epoch_unknown``).
    """

    def __init__(
        self,
        journal: ErasureJournal,
        applied_seq: Callable[[], int],
        *,
        audit: AuditSink | None = None,
        writer: str | None = None,
        monotonic: Callable[[], float] = time.monotonic,
        clock: Callable[[], datetime] = _now,
    ) -> None:
        if not isinstance(journal, ErasureJournal):
            raise TypeError("journal must be an ErasureJournal")
        if not callable(applied_seq):
            raise TypeError("applied_seq must be callable")
        if audit is not None and writer is None:
            raise ValueError("writer is required with audit")
        self._journal = journal
        self._applied_seq = applied_seq
        self._audit = audit
        self._writer = None if writer is None else check_writer(writer)
        self._monotonic = monotonic
        self._clock = clock
        self._lock = threading.Lock()
        self._last: StateEpochCheck | None = None
        self._checked_at = 0.0

    @property
    def last(self) -> StateEpochCheck | None:
        return self._last

    @property
    def ready(self) -> bool:
        last = self._last
        return last is not None and last.ready

    def background_allowed(self) -> bool:
        return self.ready

    def require_ready(self) -> None:
        if not self.ready:
            raise ModuleNotReadyError(self._last)

    def health(self) -> Health:
        """Value for ``GET /healthz``: ok, degraded (provisional) or down."""
        last = self._last
        if last is None or not last.ready:
            return "down"
        return "ok" if last.state is EpochState.CURRENT else "degraded"

    def check(self) -> StateEpochCheck:
        with self._lock:
            try:
                applied = self._applied_seq()
            except Exception:
                # The database is not reachable or the value is damaged: an
                # unknown state is never ready. The cause is left out, it may
                # carry connection details.
                result = StateEpochCheck(
                    module=self._journal.module,
                    state=EpochState.UNKNOWN,
                    applied_seq=None,
                    journal_seq=None,
                    generation=None,
                    checked_against=(),
                    problems=("applied seq of the module database is not readable",),
                )
            else:
                try:
                    result = check_state_epoch(self._journal, applied)
                except (TypeError, ValueError):
                    result = StateEpochCheck(
                        module=self._journal.module,
                        state=EpochState.UNKNOWN,
                        applied_seq=None,
                        journal_seq=None,
                        generation=None,
                        checked_against=(),
                        problems=("applied seq of the module database is not valid",),
                    )
            previous = self._last
            self._last = result
            self._checked_at = self._monotonic()
        if (previous is None or previous.state is not result.state) and result.audit_event:
            self._write_audit(result)
        return result

    def check_if_due(self) -> StateEpochCheck | None:
        """Check again when the last result asks for it; ``None`` if not due."""
        last = self._last
        if last is not None:
            after = last.recheck_after
            if after is None or self._monotonic() - self._checked_at < after:
                return None
        return self.check()

    def _write_audit(self, result: StateEpochCheck) -> None:
        if self._audit is None or self._writer is None or result.audit_event is None:
            return
        event = audit_submission(
            event=result.audit_event,
            result="allowed" if result.ready else "denied",
            writer=self._writer,
            correlation_id=new_correlation_id(),
            module=result.module,
            time=format_at(self._clock()),
            count=result.backlog,
        )
        self._audit(event)


# --- audit ------------------------------------------------------------------------


def check_writer(writer: object) -> str:
    """The audit ``writer`` (``<source>`` or ``<source>/<component>``), checked by the schema."""
    if not isinstance(writer, str):
        raise ValueError("writer must be a string")
    probe = audit_submission(
        event="erasure_replayed",
        result="allowed",
        writer=writer,
        correlation_id=new_correlation_id(),
        module="probe",
        time=format_at(datetime.now(UTC)),
    )
    try:
        validate_event({**probe, "source_seq": 1})
    except ValueError:
        raise ValueError("writer must be '<source>' or '<source>/<component>'") from None
    return writer


def audit_submission(
    *,
    event: str,
    result: Literal["allowed", "denied", "error"],
    writer: str,
    correlation_id: str,
    module: str,
    time: str,
    service_account: str | None = None,
    error_code: str | None = None,
    count: int | None = None,
) -> dict[str, object]:
    """A ``papaia.audit/1`` submission without ``source_seq``; the audit writer assigns it."""
    return {
        "format": AUDIT_FORMAT,
        "time": time,
        "correlation_id": correlation_id,
        "writer": writer,
        "role": "server",
        "identity_kind": None if service_account is None else "service",
        "service_account": service_account,
        "object_ref": {"type": "erasure_journal", "id": module},
        "result": result,
        "error_code": error_code,
        "detail": None if count is None else {"count": count},
        "event": event,
    }
