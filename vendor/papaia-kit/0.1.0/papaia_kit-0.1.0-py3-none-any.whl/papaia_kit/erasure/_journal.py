"""The single writer of a module's erasure journal, and the reader."""

from __future__ import annotations

import contextlib
import fcntl
import json
import os
import threading
import uuid
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path

from papaia_kit.erasure._entry import (
    MAX_LINE_BYTES,
    MAX_SEQ,
    ErasureKey,
    JournalConflictError,
    JournalCorruptError,
    JournalEntry,
    JournalError,
    JournalUnavailableError,
    Kind,
    check_kind,
    check_module,
    check_object_ref,
    check_reason,
    format_at,
)

_FILE_MODE = 0o640
_O_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_O_CLOEXEC = getattr(os, "O_CLOEXEC", 0)
_MAX_SEQ_DIGITS = len(str(MAX_SEQ))


class PlaceState(StrEnum):
    """State of one place that holds the journal."""

    OK = "ok"
    UNREACHABLE = "unreachable"  # not mounted, not writable or not readable
    CORRUPT = "corrupt"  # a malformed line or two entries for one seq
    CONFLICT = "conflict"  # holds another entry than the target for one id or seq


@dataclass(frozen=True)
class JournalStatus:
    """State of the local copy, the backup target and the mirror.

    ``target_pending`` and ``mirror_pending`` count the entries the place does
    not hold yet, compared by entry id. While a place is unreachable or corrupt
    the count is an upper bound. ``renumbered_from`` is set once an entry
    reached the target under a later ``seq`` than first handed out: the local
    copy was older than the target (for example restored from a VM backup), so
    the module state may be older than the journal too. ``ok`` is what
    ``doctor erasure_journal`` reports as pass; ``problems`` names the cause
    without journal content.
    """

    local: PlaceState
    target: PlaceState
    target_pending: int
    mirror: PlaceState | None
    mirror_pending: int
    renumbered_from: int | None = None
    problems: tuple[str, ...] = ()

    @property
    def target_reachable(self) -> bool:
        return self.target is not PlaceState.UNREACHABLE

    @property
    def mirror_reachable(self) -> bool | None:
        return None if self.mirror is None else self.mirror is not PlaceState.UNREACHABLE

    @property
    def ok(self) -> bool:
        return (
            self.local is PlaceState.OK
            and self.target is PlaceState.OK
            and self.target_pending == 0
            and self.mirror in (None, PlaceState.OK)
            and self.mirror_pending == 0
            and self.renumbered_from is None
        )


@dataclass(frozen=True)
class JournalRead:
    """Entries for a replay and the places that could not be read.

    ``provisional`` is true while the backup target is unavailable: the entries
    come from the mirror and the local copy only, which may be as old as the
    module state (sicherheit §4.9 (2), (2a) (v)).
    """

    entries: tuple[JournalEntry, ...]
    unavailable: tuple[str, ...]

    @property
    def provisional(self) -> bool:
        return "target" in self.unavailable


def _parse_seq(text: bytes) -> int | None:
    """A seq written by the writer, or None; never raises for a damaged marker."""
    # bytes.isdigit() accepts ASCII digits only; the length check keeps int()
    # far below its digit limit
    if not text.isdigit() or len(text) > _MAX_SEQ_DIGITS:
        return None
    seq = int(text)
    return seq if 0 < seq <= MAX_SEQ else None


def _unique_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    record = dict(pairs)
    if len(record) != len(pairs):
        raise ValueError("duplicate field")
    return record


def _parse(data: bytes, module: str, name: str) -> list[JournalEntry]:
    # A last line without a line break is a write that never completed (the
    # process died mid-write and the caller saw no success): it is ignored here
    # and cut off by the next append.
    complete = data[: data.rfind(b"\n") + 1]
    entries: list[JournalEntry] = []
    for number, raw in enumerate(complete.splitlines(), start=1):
        try:
            if len(raw) > MAX_LINE_BYTES:
                raise ValueError("line too long")
            record = json.loads(raw, object_pairs_hook=_unique_keys)
            entries.append(JournalEntry.from_record(record, module))
        except ValueError as exc:  # json.JSONDecodeError is a ValueError
            raise JournalCorruptError(f"{name} line {number}: {exc}") from None
    return entries


def _read_file(path: Path, module: str) -> list[JournalEntry]:
    """Lines of one journal file; a missing file inside a directory is empty."""
    try:
        fd = os.open(path, os.O_RDONLY | _O_NOFOLLOW | _O_CLOEXEC)
    except FileNotFoundError:
        return []
    with os.fdopen(fd, "rb") as fh:
        data = fh.read()
    return _parse(data, module, path.name)


def _append(path: Path, lines: Iterable[JournalEntry]) -> None:
    """Append complete lines, cutting off a torn last line first; fsync before return."""
    payload = "".join(e.to_line() for e in lines).encode("ascii")
    if not payload:
        return
    created = not path.exists()
    fd = os.open(
        path,
        os.O_RDWR | os.O_APPEND | os.O_CREAT | _O_NOFOLLOW | _O_CLOEXEC,
        _FILE_MODE,
    )
    try:
        size = os.fstat(fd).st_size
        if size and os.pread(fd, 1, size - 1) != b"\n":
            existing = os.pread(fd, size, 0)
            os.ftruncate(fd, existing.rfind(b"\n") + 1)
        view = memoryview(payload)
        while view:
            written = os.write(fd, view)
            view = view[written:]
        os.fsync(fd)
    finally:
        os.close(fd)
    if created:
        dir_fd = os.open(path.parent, os.O_RDONLY | _O_CLOEXEC)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)


def _collapse(module: str, lines: Iterable[JournalEntry]) -> dict[str, JournalEntry]:
    """One entry per id in one place: the last line of an id wins.

    Lines of one id must agree on everything but ``seq`` and
    ``provisional_seq``. The writer appends a later line for an entry when the
    target gave it another ``seq``; files are never rewritten.
    """
    entries: dict[str, JournalEntry] = {}
    for line in lines:
        known = entries.get(line.id)
        if known is not None and not known.same_entry(line):
            raise JournalConflictError(f"{module}: different entries for one id")
        entries[line.id] = line
    return entries


def _merge(module: str, views: Iterable[dict[str, JournalEntry]]) -> dict[str, JournalEntry]:
    """Union of places in order of authority: the first place that holds an id wins."""
    merged: dict[str, JournalEntry] = {}
    for view in views:
        for entry_id, entry in view.items():
            known = merged.get(entry_id)
            if known is None:
                merged[entry_id] = entry
            elif not known.same_entry(entry):
                raise JournalConflictError(f"{module}: different entries for one id")
    return merged


def _ordered(module: str, entries: dict[str, JournalEntry]) -> list[JournalEntry]:
    ordered = sorted(entries.values(), key=lambda e: e.seq)
    for before, after in zip(ordered, ordered[1:], strict=False):
        if before.seq == after.seq:
            raise JournalConflictError(f"{module}: different entries for seq {after.seq}")
    return ordered


def _place_view(module: str, lines: Iterable[JournalEntry]) -> dict[str, JournalEntry]:
    entries = _collapse(module, lines)
    _ordered(module, entries)
    return entries


def read_journal(module: str, directories: Iterable[Path]) -> list[JournalEntry]:
    """Union of the journal of ``module`` in every given directory, ordered by ``seq``.

    Strict reader for ``erasure-replay``: every directory must exist and be
    readable, otherwise :class:`JournalUnavailableError`. A missing directory is
    never an empty journal (an unmounted target would replay nothing). Inside an
    existing directory a missing file means nothing was journaled yet.

    Pass the target first: for one entry the line of the first directory that
    holds it wins, so the ``seq`` the target assigned is final. A malformed line,
    two entries for one ``seq`` or one id with different content raise, so a
    damaged journal is never replayed in part. To include a target that may be
    unreachable, use :meth:`ErasureJournal.entries`.
    """
    check_module(module)
    views: list[dict[str, JournalEntry]] = []
    for directory in directories:
        if not isinstance(directory, (str, os.PathLike)):
            raise TypeError("every source must be a directory path")
        path = Path(directory)
        if not path.is_dir():
            raise JournalUnavailableError(f"{path}: journal directory is missing")
        try:
            views.append(_place_view(module, _read_file(path / f"{module}.jsonl", module)))
        except OSError as exc:
            raise JournalUnavailableError(f"{path}: {exc.strerror}") from None
    return _ordered(module, _merge(module, views))


def _salvage(path: Path, module: str) -> dict[str, int]:
    """Id and highest ``seq`` of the valid lines of a damaged file.

    Only to count the backlog and to find entries beyond a module's applied
    ``seq``; a salvaged line is never replayed.
    """
    seqs: dict[str, int] = {}
    with contextlib.suppress(OSError):
        fd = os.open(path, os.O_RDONLY | _O_NOFOLLOW | _O_CLOEXEC)
        with os.fdopen(fd, "rb") as fh:
            for raw in fh.read().splitlines():
                with contextlib.suppress(ValueError, JournalError):
                    for e in _parse(raw + b"\n", module, path.name):
                        seqs[e.id] = max(e.seq, seqs.get(e.id, 0))
    return seqs


@dataclass
class _Place:
    name: str
    directory: Path
    state: PlaceState
    lines: list[JournalEntry] = field(default_factory=list)
    entries: dict[str, JournalEntry] = field(default_factory=dict)
    problem: str | None = None
    salvaged: dict[str, int] = field(default_factory=dict)

    @property
    def usable(self) -> bool:
        return self.state is PlaceState.OK

    def add(self, module: str, lines: list[JournalEntry]) -> None:
        self.lines.extend(lines)
        self.entries = _collapse(module, self.lines)


class ErasureJournal:
    """Writer of the erasure journal of one module.

    ``target_dir`` is ``<backup target>/erasure-journal``, ``local_dir`` the local
    copy (volume ``papaia-erasure``, excluded from backups), ``mirror_dir`` the
    optional second place (``--erasure-mirror``). The writer never creates the
    target or the mirror directory: a missing mount must show as unreachable,
    not as an empty directory inside the container.

    Call :meth:`record` in the same operation as the deletion and before the
    deletion commits; store the returned ``seq`` as the module's applied seq in
    the same transaction. If the local copy cannot be written or is damaged,
    ``record`` raises and the deletion must not go ahead. If the target or the
    mirror is unreachable or damaged, the entry stays in the local copy (and
    the mirror) and is delivered by the next ``record`` or :meth:`flush`;
    :meth:`status` reports the backlog.

    The target assigns the final ``seq``, and its line of an entry is final:
    the local copy and the mirror take it over. An entry recorded while the
    target was not usable carries a provisional ``seq``; if the target already
    holds that number for another entry, the entry is delivered under the next
    free ``seq`` with ``provisional_seq`` set, :meth:`status` reports
    ``renumbered_from`` and :func:`replay` rewinds behind it. While the target
    is not usable, entries only the mirror holds are taken into the local copy;
    one that collides with a local ``seq`` gets the next free provisional
    ``seq``. No write leaves two entries under one ``seq`` in a place.
    """

    def __init__(
        self,
        module: str,
        *,
        key: ErasureKey,
        target_dir: Path,
        local_dir: Path,
        mirror_dir: Path | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self.module = check_module(module)
        if not isinstance(key, ErasureKey):
            raise TypeError("key must be an ErasureKey")
        self._key = key
        self._target_dir = Path(target_dir)
        self._local_dir = Path(local_dir)
        self._mirror_dir = None if mirror_dir is None else Path(mirror_dir)
        self._clock = clock or (lambda: datetime.now(UTC))
        self._mutex = threading.Lock()

    @property
    def _file(self) -> str:
        return f"{self.module}.jsonl"

    @property
    def _marker(self) -> Path:
        return self._local_dir / f".{self.module}.renumbered"

    @property
    def _final_marker(self) -> Path:
        # "<seq> <id>": every line of the local copy up to this seq is the
        # target's final line. Kept next to the lines, so a restored volume
        # brings back a matching marker.
        return self._local_dir / f".{self.module}.final"

    @contextlib.contextmanager
    def _locked(self) -> Iterator[None]:
        # One writer at a time across threads and processes of the module, so
        # that seq stays gap-free and unique.
        with self._mutex:
            try:
                fd = os.open(
                    self._local_dir / f".{self.module}.lock",
                    os.O_RDWR | os.O_CREAT | _O_NOFOLLOW | _O_CLOEXEC,
                    _FILE_MODE,
                )
            except OSError as exc:
                raise JournalUnavailableError(f"local copy: {exc.strerror}") from None
            try:
                fcntl.flock(fd, fcntl.LOCK_EX)
                yield
            finally:
                os.close(fd)

    # --- reading the places --------------------------------------------------

    def _read(self, name: str, directory: Path) -> _Place:
        """Read one place; never raises for an unreachable or damaged place."""
        if not directory.is_dir():
            return _Place(name, directory, PlaceState.UNREACHABLE, problem=f"{name}: missing")
        if not os.access(directory, os.R_OK | os.W_OK | os.X_OK):
            return _Place(name, directory, PlaceState.UNREACHABLE, problem=f"{name}: no access")
        path = directory / self._file
        try:
            lines = _read_file(path, self.module)
            entries = _place_view(self.module, lines)
        except OSError as exc:
            return _Place(
                name, directory, PlaceState.UNREACHABLE, problem=f"{name}: {exc.strerror}"
            )
        except JournalError as exc:
            return _Place(
                name,
                directory,
                PlaceState.CORRUPT,
                problem=f"{name}: {exc}",
                salvaged=_salvage(path, self.module),
            )
        return _Place(name, directory, PlaceState.OK, lines, entries)

    def _load(self) -> tuple[_Place, _Place, _Place | None]:
        local = self._read("local copy", self._local_dir)
        target = self._read("target", self._target_dir)
        mirror = None if self._mirror_dir is None else self._read("mirror", self._mirror_dir)
        return local, target, mirror

    def _require_local(self, local: _Place) -> None:
        # The local copy is the module's own volume; without it no entry is safe.
        if local.state is PlaceState.CORRUPT:
            raise JournalCorruptError(local.problem or "local copy")
        if local.state is not PlaceState.OK:
            raise JournalUnavailableError(local.problem or "local copy")

    def _renumbered_from(self) -> int | None:
        try:
            text = self._marker.read_bytes().strip()
        except OSError:
            return None
        # anything but a seq in range counts as set
        return _parse_seq(text) or 1

    def _write_marker(self, path: Path, text: str) -> None:
        tmp = path.with_name(path.name + ".tmp")
        try:
            tmp.write_text(text, encoding="ascii")
            tmp.replace(path)
        except OSError as exc:
            raise JournalUnavailableError(f"local copy: {exc.strerror}") from None

    def _mark_renumbered(self, seq: int) -> None:
        known = self._renumbered_from()
        value = seq if known is None else min(known, seq)
        self._write_marker(self._marker, f"{value}\n")

    def _final_through(self, local: _Place) -> int:
        """Highest seq up to which the local copy holds the target's final lines.

        0 if the marker is missing, unreadable or does not fit the local copy
        (the lines were replaced without it): no line counts as final then.
        """
        try:
            seq_text, _, entry_id = self._final_marker.read_bytes().strip().partition(b" ")
        except OSError:
            return 0
        seq = _parse_seq(seq_text)
        held = local.entries.get(entry_id.decode("ascii", "replace"))
        return seq if seq is not None and held is not None and held.seq == seq else 0

    def _mark_final(self, local: _Place, target: _Place) -> None:
        """Move the final marker up to the last local line the target confirms."""
        last: JournalEntry | None = None
        for entry in sorted(local.entries.values(), key=lambda e: e.seq):
            if target.entries.get(entry.id) != entry:
                break
            last = entry
        if last is not None and last.seq > self._final_through(local):
            self._write_marker(self._final_marker, f"{last.seq} {last.id}\n")

    def _check_final(self, local: _Place, target: _Place) -> None:
        """A target that changed a line the local copy holds as final is a conflict.

        The target assigns ``seq`` once; only an entry the local copy holds
        under a provisional ``seq`` may arrive under another one. A changed
        final line (for example two entries with swapped ``seq``) would make a
        replay skip a deletion, so the target is left out instead of followed.
        """
        through = self._final_through(local)
        for entry in local.entries.values():
            if entry.seq > through:
                continue
            held = target.entries.get(entry.id)
            if held is not None and held != entry:
                target.state = PlaceState.CONFLICT
                target.problem = f"target: changed the line of final seq {entry.seq}"
                return

    # --- delivering ----------------------------------------------------------

    @staticmethod
    def _end(*places: _Place | None) -> int:
        return max((e.seq for p in places if p is not None for e in p.entries.values()), default=0)

    def _write(self, place: _Place, lines: Iterable[JournalEntry], *, dry: bool) -> bool:
        """Append the lines the place lacks; False only if the place is not writable.

        A line for an entry the place holds with other content is left out, and
        nothing is written if the lines would leave two entries under one
        ``seq``: the place never becomes damaged by the writer, and
        :meth:`status` reports the conflict.
        """
        wanted = [
            e
            for e in sorted(lines, key=lambda e: e.seq)
            if (known := place.entries.get(e.id)) is None or (known != e and known.same_entry(e))
        ]
        if not wanted:
            return True
        try:
            _place_view(self.module, [*place.lines, *wanted])
        except JournalConflictError:
            return True
        if not dry:
            try:
                _append(place.directory / self._file, wanted)
            except OSError:
                # Unmounted, read-only, full or a planted symlink: the place is
                # not writable now and the entries stay where they are.
                return False
        place.add(self.module, wanted)
        return True

    def _to_target(
        self, local: _Place, target: _Place, mirror: _Place | None, *, dry: bool
    ) -> bool:
        """Deliver what the target lacks, by id, from the local copy, then the mirror."""
        pending: dict[str, JournalEntry] = {}
        for source in (local, mirror):
            if source is not None and source.usable:
                for entry in source.entries.values():
                    if entry.id not in target.entries:
                        pending.setdefault(entry.id, entry)
        end = self._end(target)
        delivered: list[JournalEntry] = []
        for entry in sorted(pending.values(), key=lambda e: e.seq):
            end += 1
            first = entry.provisional_seq or entry.seq
            delivered.append(
                replace(entry, seq=end, provisional_seq=None if end == first else first)
            )
        if not self._write(target, delivered, dry=dry):
            return False
        # only entries the target now holds were moved; a refused write moves none
        moved = [
            e.provisional_seq
            for e in delivered
            if e.provisional_seq is not None
            and e.seq > e.provisional_seq
            and target.entries.get(e.id) == e
        ]
        if moved and not dry:
            self._mark_renumbered(min(moved))
        return True

    def _provisional(
        self, local: _Place, target: _Place, mirror: _Place | None
    ) -> dict[str, JournalEntry]:
        """Local copy plus the entries only the mirror holds, without a shared ``seq``."""
        view = dict(local.entries)
        if mirror is None or not mirror.usable:
            return view
        taken = {e.seq for e in view.values()}
        end = self._end(local, target, mirror)
        for line in sorted(mirror.entries.values(), key=lambda e: e.seq):
            entry = line
            if entry.id in view:
                continue
            if entry.seq in taken:
                end += 1
                first = entry.provisional_seq or entry.seq
                entry = replace(entry, seq=end, provisional_seq=None if end == first else first)
            taken.add(entry.seq)
            view[entry.id] = entry
        return view

    def _deliver(
        self, local: _Place, target: _Place, mirror: _Place | None, *, dry: bool = False
    ) -> None:
        """Bring target, local copy and mirror up to date, in memory and on disk."""
        if target.usable and local.usable:
            self._check_final(local, target)
        if target.usable and not self._to_target(local, target, mirror, dry=dry):
            target.state = PlaceState.UNREACHABLE
            target.problem = "target: not writable"
        # the target's lines are final; without it the local copy leads
        view = target.entries if target.usable else self._provisional(local, target, mirror)
        for place in (local, mirror):
            if place is None or not place.usable:
                continue
            if not self._write(place, list(view.values()), dry=dry) and place is local:
                raise JournalUnavailableError("local copy: not writable")
        if target.usable and local.usable and not dry:
            self._mark_final(local, target)

    def _union(
        self, local: _Place, target: _Place, mirror: _Place | None
    ) -> dict[str, JournalEntry]:
        """What a replay reads: target, local copy, mirror, in that order of authority.

        A usable place that does not fit the places before it is marked
        ``conflict`` and left out.
        """
        merged: dict[str, JournalEntry] = {}
        before: list[str] = []
        for place in (target, local, mirror):
            if place is None or not place.usable:
                continue
            try:
                candidate = _merge(self.module, [merged, place.entries])
                _ordered(self.module, candidate)
            except JournalConflictError as exc:
                place.state = PlaceState.CONFLICT
                place.problem = f"{place.name}: does not match {' and '.join(before)}: {exc}"
                continue
            merged = candidate
            before.append(place.name)
        return merged

    def _status(self, local: _Place, target: _Place, mirror: _Place | None) -> JournalStatus:
        known: dict[str, JournalEntry] = {}
        for place in (target, local, mirror):
            if place is not None and place.usable:
                for entry_id, entry in place.entries.items():
                    known.setdefault(entry_id, entry)
        ids = set(known)
        for place in (local, mirror):
            if place is not None:
                ids |= place.salvaged.keys()  # a damaged copy is never counted as delivered
        target_pending = len(ids - set(target.entries)) if target.usable else len(ids)
        if mirror is None:
            mirror_pending = 0
        elif not mirror.usable:
            mirror_pending = len(known)
        else:
            mirror_pending = sum(1 for e in known.values() if mirror.entries.get(e.id) != e)
        # the same check as entries(), on the places as the next delivery leaves them
        with contextlib.suppress(JournalError):
            self._deliver(local, target, mirror, dry=True)
        self._union(local, target, mirror)
        return JournalStatus(
            local=local.state,
            target=target.state,
            target_pending=target_pending,
            mirror=None if mirror is None else mirror.state,
            mirror_pending=mirror_pending,
            renumbered_from=self._renumbered_from(),
            problems=tuple(p.problem for p in (local, target, mirror) if p and p.problem),
        )

    # --- public API ----------------------------------------------------------

    def record(self, kind: Kind, *, object_ref: str, sub: str, reason: str) -> JournalEntry:
        """Write one entry for ``sub`` and return it.

        ``reason`` is a short code (for example ``user_request``, ``art17``,
        ``retention``), never free text; ``object_ref`` names the object (for a
        delivery: reminder and due time), never its content.
        """
        checked_kind = check_kind(kind, self.module)
        check_object_ref(object_ref)
        check_reason(reason)
        subject_ref = self._key.subject_ref(sub)
        at = format_at(self._clock())

        with self._locked():
            local, target, mirror = self._load()
            self._require_local(local)
            self._deliver(local, target, mirror)
            # Final while the target is usable (every entry is there now);
            # provisional otherwise: the highest number any readable place knows.
            entry = JournalEntry(
                id=str(uuid.uuid4()),
                module=self.module,
                seq=self._end(local, target, mirror) + 1,
                kind=checked_kind,
                object_ref=object_ref,
                subject_ref=subject_ref,
                at=at,
                reason=reason,
            )
            if not self._write(local, [entry], dry=False) or local.entries.get(entry.id) != entry:
                raise JournalUnavailableError("local copy: not writable")
            self._deliver(local, target, mirror)
        return entry

    def flush(self) -> JournalStatus:
        """Deliver buffered entries to the target and the mirror."""
        with self._locked():
            local, target, mirror = self._load()
            self._require_local(local)
            self._deliver(local, target, mirror)
            return self._status(local, target, mirror)

    def status(self) -> JournalStatus:
        """State and backlog per place without writing (input of ``doctor erasure_journal``).

        Never raises for an unreachable, corrupt or conflicting place; the state
        shows in the result and ``ok`` is false. It does not wait for the writer
        lock: a writer stuck on a dead mount does not hold up ``doctor``.
        """
        return self._status(*self._load())

    def entries(self) -> JournalRead:
        """Entries for ``erasure-replay``: target, local copy and mirror.

        Delivers what is pending first, then returns the union; for one entry
        the target's line wins. A place that is unreachable is named in
        ``unavailable`` (the run is provisional while it is the target); a
        corrupt or conflicting place and an unusable local copy raise, so a
        damaged journal is never replayed in part.
        """
        with self._locked():
            local, target, mirror = self._load()
            self._require_local(local)
            places = [p for p in (target, mirror) if p is not None]
            for place in places:
                if place.state is PlaceState.CORRUPT:
                    raise JournalCorruptError(place.problem or place.name)
            self._deliver(local, target, mirror)
            merged = self._union(local, target, mirror)
            for place in (local, *places):
                if place.state is PlaceState.CONFLICT:
                    raise JournalConflictError(place.problem or place.name)
            return JournalRead(
                entries=tuple(_ordered(self.module, merged)),
                unavailable=tuple(p.name for p in places if not p.usable),
            )

    @property
    def target_dir(self) -> Path:
        return self._target_dir

    def _check_view(self) -> tuple[_Place, _Place, _Place | None, int | None]:
        """Places as the next delivery leaves them, for the start check.

        Like :meth:`status` it writes nothing, takes no lock and never raises
        for a place; a place that does not fit the ones before it is marked
        ``conflict``.
        """
        local, target, mirror = self._load()
        with contextlib.suppress(JournalError):
            self._deliver(local, target, mirror, dry=True)
        self._union(local, target, mirror)
        return local, target, mirror, self._renumbered_from()

    def acknowledge_renumbering(self) -> None:
        """Clear ``renumbered_from`` after ``recover-snapshot`` replayed the journal."""
        with self._locked(), contextlib.suppress(FileNotFoundError):
            self._marker.unlink()
