"""Repository discipline checks run in the CI of every papaia repository.

``words`` scans tracked and new files for denied terms (tool and vendor names,
private tooling). ``commits`` checks author, committer, sign-off and message of
every commit in a range. The patterns are stored base64-encoded so that this
file does not match itself.
"""

from __future__ import annotations

import base64
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

_DENIED_B64 = (
    "XGIoY2xhdWRlfGFudGhyb3BpY3xvcGVuYWl8Y2hhdGdwdHxjb3BpbG90fGN1cnNvcnxhaWRlcnxhZ2VudHM/fGFnZW50aWN8"
    "dmliZWNvZFthLXpdKnxwYXBhaWEtdG9vbHN8c2V0dXAtcGFwYWlhfHVwZGF0ZS1wYXBhaWF8Zmlkb25pcy1jdGwpXGI="
)
_DENIED_EXACT_B64 = "XGJBSVxi"  # matched case-sensitively, so the product name papAIa passes
# API key prefix of one vendor, in any case and position (no word boundary)
_DENIED_VENDOR_PREFIX_B64 = "KD9pKXNrLWFudC0="

# Uses of two denied words that name no tool and stay allowed. Matching spans
# are blanked before the denied terms are searched, so any other hit on the
# same line still counts. Each pattern is narrow on purpose: lower case where
# code spells it that way, fixed value lists, no free prose.
ALLOWED_CONTEXTS_B64 = (
    # HTTP request header name (RFC 9110), any spelling of the separator
    "KD88IVtcdy1dKSg/aTp1c2VyWy1fIF1hZ2VudCkoPyFbXHctXSk=",
    # key daemons of OpenSSH and GnuPG
    "KD88IVtcdy1dKSg/OnNzaHxncGcpLWFnZW50KD8hW1x3LV0p",
    # CSS pointer-shape property followed by a CSS keyword value, url() or var()
    "KD88IVtcdy1dKWN1cnNvclxzKjpccyooPzooPzphdXRvfGRlZmF1bHR8bm9uZXxjb250ZXh0LW1lbnV8aGVscHxwb2ludGVy"
    "fHByb2dyZXNzfHdhaXR8Y2VsbHxjcm9zc2hhaXJ8dGV4dHx2ZXJ0aWNhbC10ZXh0fGFsaWFzfGNvcHl8bW92ZXxuby1kcm9w"
    "fG5vdC1hbGxvd2VkfGdyYWJiaW5nfGdyYWJ8YWxsLXNjcm9sbHxjb2wtcmVzaXplfHJvdy1yZXNpemV8bmVzdy1yZXNpemV8"
    "bndzZS1yZXNpemV8W25zZXddezEsMn0tcmVzaXplfHpvb20taW58em9vbS1vdXR8aW5oZXJpdHxpbml0aWFsfHVuc2V0fHJl"
    "dmVydC1sYXllcnxyZXZlcnQpKD8hW1x3LV0pfHVybFwofHZhclwoKQ==",
    # CSS utility classes for the pointer shape with the same keyword values
    "KD88IVtcdy1dKWN1cnNvci0oPzphdXRvfGRlZmF1bHR8bm9uZXxjb250ZXh0LW1lbnV8aGVscHxwb2ludGVyfHByb2dyZXNz"
    "fHdhaXR8Y2VsbHxjcm9zc2hhaXJ8dGV4dHx2ZXJ0aWNhbC10ZXh0fGFsaWFzfGNvcHl8bW92ZXxuby1kcm9wfG5vdC1hbGxv"
    "d2VkfGdyYWJiaW5nfGdyYWJ8YWxsLXNjcm9sbHxjb2wtcmVzaXplfHJvdy1yZXNpemV8bmVzdy1yZXNpemV8bndzZS1yZXNp"
    "emV8W25zZXddezEsMn0tcmVzaXplfHpvb20taW58em9vbS1vdXR8aW5oZXJpdHxpbml0aWFsfHVuc2V0fHJldmVydC1sYXll"
    "cnxyZXZlcnQpKD8hW1x3LV0p",
    # attribute or method of a code object right after an identifier, such as
    # the database API (PEP 249) or a DOM style object; not a dot-directory
    "KD88PVtcdylcXV0pXC5jdXJzb3IoPyFbXHcvLi1dKQ==",
    # pagination parameter of the MCP list methods as a quoted key or lookup
    "KD88PSIpY3Vyc29yKD89Ils6KVxdXSk=",
)

_DENIED = re.compile(base64.b64decode(_DENIED_B64).decode(), re.IGNORECASE)
_DENIED_EXACT = re.compile(base64.b64decode(_DENIED_EXACT_B64).decode())
_DENIED_VENDOR_PREFIX = re.compile(base64.b64decode(_DENIED_VENDOR_PREFIX_B64).decode())
_ALLOWED = re.compile("|".join(f"(?:{base64.b64decode(p).decode()})" for p in ALLOWED_CONTEXTS_B64))

# Third-party package names in lock files are not wording.
_SKIPPED_NAMES = frozenset({"uv.lock", "package-lock.json"})
_BINARY_PROBE = 8192
_MAX_RANGE = 200
_RANGE = re.compile(r"[A-Za-z0-9_./~^@{}-]+(\.\.\.?[A-Za-z0-9_./~^@{}-]+)?")
_CO_AUTHOR = re.compile(r"^co-authored-by:", re.IGNORECASE | re.MULTILINE)


@dataclass(frozen=True)
class Finding:
    location: str
    message: str


def find_denied_words(text: str) -> list[str]:
    """Denied terms in the text, in order of appearance (allowed contexts excluded)."""
    masked = _ALLOWED.sub(lambda m: " " * len(m.group(0)), text)
    hits = [
        (m.start(), m.group(0))
        for pattern in (_DENIED, _DENIED_EXACT, _DENIED_VENDOR_PREFIX)
        for m in pattern.finditer(masked)
    ]
    return [word for _, word in sorted(hits)]


def _git(root: Path, *args: str) -> str:
    # Fixed argument list without a shell; ranges are validated by valid_range.
    return subprocess.run(  # noqa: S603
        ["git", "-C", str(root), *args],  # noqa: S607 - git from PATH, like every developer tool
        check=True,
        capture_output=True,
        text=True,
    ).stdout


def scan_files(root: Path) -> list[Finding]:
    """Check every file git would version (tracked plus new, not ignored)."""
    listed = _git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard")
    findings = []
    for rel in sorted(set(filter(None, listed.split("\0")))):
        path = root / rel
        if path.name in _SKIPPED_NAMES or not path.is_file() or path.is_symlink():
            continue
        data = path.read_bytes()
        if b"\0" in data[:_BINARY_PROBE]:
            continue
        for number, line in enumerate(data.decode("utf-8", errors="replace").splitlines(), 1):
            words = find_denied_words(line)
            if words:
                findings.append(Finding(f"{rel}:{number}", ", ".join(words)))
    return findings


def valid_range(revision_range: str) -> bool:
    return (
        0 < len(revision_range) <= _MAX_RANGE
        and not revision_range.startswith("-")
        and _RANGE.fullmatch(revision_range) is not None
    )


def check_commits(root: Path, revision_range: str, email_domain: str) -> list[Finding]:
    """Check author, committer, sign-off and wording of every commit in the range."""
    if not valid_range(revision_range):
        raise ValueError(f"invalid revision range {revision_range!r}")
    log = _git(
        root, "log", "-z", "--format=%H%x1f%an%x1f%ae%x1f%cn%x1f%ce%x1f%B", revision_range, "--"
    )
    suffix = "@" + email_domain.lower()
    findings = []
    for raw in filter(None, log.split("\0")):
        sha, author, author_email, _, committer_email, message = raw.split("\x1f", 5)
        where = sha[:12]
        if not author_email.lower().endswith(suffix):
            findings.append(Finding(where, f"author email {author_email} is not {suffix}"))
        if not committer_email.lower().endswith(suffix):
            findings.append(Finding(where, f"committer email {committer_email} is not {suffix}"))
        if f"Signed-off-by: {author} <{author_email}>" not in message:
            findings.append(Finding(where, "missing sign-off of the author"))
        if _CO_AUTHOR.search(message):
            findings.append(Finding(where, "co-author trailer is not allowed"))
        words = find_denied_words(message)
        if words:
            findings.append(Finding(where, f"denied term(s) in message: {', '.join(words)}"))
    return findings
