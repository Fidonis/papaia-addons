"""User interface contract: design tokens, shell markup and the specimen page."""
