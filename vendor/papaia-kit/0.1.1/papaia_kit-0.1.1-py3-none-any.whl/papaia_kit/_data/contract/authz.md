# Check chain `papaia_kit.authz`

Every module endpoint and every catalog server checks each incoming bearer
token with the same chain, on the server, for every request. The client view is
never the control. Python: `papaia_kit.authz.CheckChain`.

```python
from papaia_kit.authz import (
    AzpAllowList,
    CheckChain,
    Effect,
    JwksCache,
    Request,
    ServerConfig,
    bearer_token,
)

config = ServerConfig(
    audience="mcp-paperless",
    issuer="https://login.example.org/realms/papaia",
    trust="addon",  # from the platform catalog, set by the core
    writer="mcp-paperless",
    allowlist=AzpAllowList.from_file("/run/papaia/security/azp-allowlist.json"),
    upstream_origins={"papaia-data": ["papaia-studio-gateway"]},  # from the catalog
)
chain = CheckChain(
    config,
    JwksCache(fetch_jwks),  # fetch_jwks uses a short timeout
    audit=audit_writer.submit,
    revocations=revocation_loader.current,  # required; None disables step 5
)

principal = chain.check(
    bearer_token(headers.get("Authorization")) or "",
    Request(
        catalog_id="paperless.documents",
        operation="add_note",
        effect=Effect.WRITE,
        roles=frozenset({"paperless-user"}),  # required; see step 6
        correlation_id=headers.get("X-Papaia-Correlation-Id"),
        origin_header=headers.get("X-Papaia-Origin-Azp"),
    ),
)
# AuthzDenied: answer with error.envelope.to_dict() and error.status.
```

## Order of the checks

A failure ends the chain. The answer never tells whether an object exists.

| Step | Check | Failure |
|---|---|---|
| 1 | Signature against the realm keys; algorithms RS256 and ES256 only (`none`, HMAC and every other algorithm refused before a key is looked up; a key is used only with the algorithm of its type; RSA at least 2048 bits, EC only P-256); `crit` header refused; header `typ`, if present, `JWT` or `at+jwt` (`application/at+jwt`); `iss` exactly the configured issuer; claim `typ` exactly `Bearer` (access token; ID, refresh and logout tokens are refused, RFC 8725 3.11); `exp`, `iat` (and `nbf` if present) integer NumericDates from 0 to 2^63 - 1 with 30 s tolerance; `auth_time`, if present, such an integer as well | `unauthenticated` 401 |
| 2 | `aud` exactly the own audience (a string or an array with one element). Several audiences only at a server with `trust: platform`, only from `librechat`, without duplicates and including the own audience | `unauthenticated` 401 |
| 3 | `azp` in the allow list of the own audience. An empty list, or no entry for the own audience, refuses every token (fail closed) | `unauthenticated` 401 |
| 4 | Identity kind: `person` (`person_id` = `sub`, session id present) or `service` (service account client, no session id), by `papaia_kit.names.person_id`; missing or malformed `sub` is refused; the operation must admit the kind | `unauthenticated` 401, kind not admitted `forbidden_or_not_found` 403 |
| 5 | Revocation list: `iat < global_since`, or a listed `sub` with `iat < since`. Skipped while the source returns None and disabled with `revocations=None` (see below) | `identity_revoked` 401 |
| 6 | One of the module roles of the route in the flat `roles` claim. `Request.roles` is a required keyword; a route without a module role passes `roles=frozenset()` with `no_role_required=True` and must be declared as such: its server suite runs without `--role` (`contract/conformance.md`) | `forbidden_or_not_found` 403 |
| 7 | The effect of the operation is released for this `azp` in the allow list | `forbidden_or_not_found` 403 |

Object checks (sharing, rights of the target system) follow in the module or
the server. The person is taken from `Principal` only; identifiers in path,
query, body or headers are never used for "own data".

The `scope` claim is never read. A scope naming an audience does not replace
`aud`, a scope naming a role does not replace `roles`.

## The server's row of an allowed request

`Principal` carries the verified identity and the token times: `issued_at`
(`iat`), `expires_at` (`exp`), `auth_time` (None when the token has none, as
for a service account) and `checked_at` (the time of the check in whole
seconds). `remaining_seconds` is `expires_at - checked_at`, at least 0.
`Principal.audit_fields()` returns the identity part of the server's own
`papaia.audit/1` row (`role: server`, `correlation_id`, `sub`,
`identity_kind`, `service_account`, `azp`, `aud`, `origin_azp`,
`origin_source`, `origin_asserted_by`) and the token times `token_iat`,
`token_auth_time` and `token_remaining_s` (PLT-11-A2). The server adds
`format`, `time`, `writer`, `catalog_id`, `operation`, `effect`, `result` and
`event: operation` and hands the row to its audit writer. The token itself is
never part of it. Rows of a rejection carry no token times.

## Rejections

`AuthzDenied` carries the `error.v1` envelope (`PK-AUTH-001`,
`PK-ACCESS-001` with status 403, `PK-IDENTITY-001`), the status and a `reason`
for local diagnosis. The reason is never sent to the caller.

Before raising, the chain hands one `papaia.audit/1` row to the audit sink:
`result: denied`, `event: operation`, `role: server`, the request's
`catalog_id`, `operation`, `effect` and correlation id, and `error_code`.
Every row names all identity fields (`sub`, `identity_kind`,
`service_account`, `azp`, `aud`, `origin_azp`, `origin_source`,
`origin_asserted_by`); a field the chain does not know is `null`. `sub`, `azp`,
`aud` and `identity_kind` are filled only after the signature and issuer have
been verified and only when they fit the character sets of the audit format;
`identity_kind` is then taken from the same rule as step 4, so a rejection in
steps 1 to 3 of a signed token (foreign audience, foreign `azp`) is a complete
`operation` event. The row never contains the token or any part of it.

Open schema point (KIT-005): `papaia.audit/1` requires `sub`, `identity_kind`
and `azp` as strings for `event: operation`. A rejection before the identity is
known (malformed token, unknown key, bad signature, foreign issuer, missing
`sub`) has `null` there and does not validate until KIT-005 admits `null` for
`result: denied` (or adds a separate rejection event). The audit writer must
not drop such a row. The sink is the source's audit writer, which adds
`source_seq` and delivers; an exception of the sink propagates, so the
request still fails.

## Allow list `azp-allowlist.json`

Generated by the realm sync from the pairings and mounted read-only into every
server.

```json
{
  "version": 1,
  "audiences": {
    "mcp-paperless": {
      "papaia-studio-gateway": ["read", "write", "delete"],
      "papaia-data": ["read", "write"],
      "papaia-data-ui": ["read", "write"]
    }
  }
}
```

Effects: `read`, `write`, `send`, `delete`, `check`. Audiences and clients must
follow the naming register; removed names are refused. Unknown fields,
duplicate keys, duplicate effects and files larger than 1 MiB are refused.

## Origin of a chain

- `upstream_origins` maps the chain holder `papaia-data` to its one allowed
  origin, as published in the platform catalog. A token with that `azp` gets
  `origin_azp` = the origin and `origin_source: policy`; the identity provider
  has already refused chains from any other origin.
- Every other caller is its own origin: `origin_azp` = `azp`,
  `origin_source: azp` (for example `papaia-data-ui`).
- `upstream_origins` never contains a Data client (`papaia-data`,
  `papaia-data-ui`) and holds exactly one origin per chain holder; several
  origins need one chain client each. Only the chain holder has origins.
- A chain holder that the allow list releases for the own audience must have
  its origin configured; `ServerConfig` refuses the configuration otherwise
  (the default `upstream_origins={}` included). `origin_of` never returns a
  chain holder as origin (it raises `LookupError`), so `origin_azp` is never a
  Data client acting as chain holder.
- The header `X-Papaia-Origin-Azp` is information only. A well-formed value is
  recorded as `origin_asserted_by` in every row, also in a denied one. A value
  that differs from `origin_azp`, or is malformed (then not recorded),
  produces the event `origin_header_mismatch` with `result: allowed` only when
  the request passes. On a denied request the one denied row carries
  `origin_azp` (when step 3 was reached) and `origin_asserted_by`, so the
  mismatch is visible there; no second row is written. The header never
  changes a decision; a missing header is no mismatch. `origin_header_mismatch`
  is not yet in the event list of KIT-005.

## Revocation list

`RevocationList.from_dict` parses `revocations.json`:
`{seq, issued_at, global_since?, entries: [{sub, since, reason}]}` with
NumericDate times. Unknown fields are refused. Loading the file from the
security state volume, checking its Ed25519 signature and reloading it at least
every 15 s belong to the loader passed as `revocations`; the kit has no such
loader yet.

`revocations` is a required argument of `CheckChain`:

- a source function: step 5 runs whenever it returns a list; while it returns
  `None` (nothing loaded yet) step 5 is skipped;
- `None`: step 5 is disabled. Allowed in stage 0 only until the kit loader
  exists; no server adopts the chain with step 5 disabled in production.

`CheckChain.revocation_status()` returns the state (`disabled`, `not_loaded`,
`loaded`), `seq`, `issued_at` and `age_seconds` (now minus `issued_at`); doctor
reports it as `revocations_age_seconds`. The emergency stop (security 4.11,
`HaltGuard`) is not part of this chain yet.

## Keys

`KeySet.from_jwks` reads a JWKS document; keys that cannot be used by the
chain are skipped. `JwksCache(fetch)` fetches through a function supplied by
the server, refetches on an unknown `kid` at most every 30 s and after 300 s,
and keeps the previous keys when a fetch fails.

`fetch` runs under the cache lock, so concurrent checks wait for it: it must
use a short timeout (a few seconds). While fetches fail, keys removed from the
JWKS stay in use. `age_seconds()` (time since the last successful load) and
`stale()` (nothing loaded, or older than `max_age_seconds`) expose this for
doctor.
