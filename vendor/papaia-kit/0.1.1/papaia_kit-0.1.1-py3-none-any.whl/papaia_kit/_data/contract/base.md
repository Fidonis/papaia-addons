# Base layer `pk.base`: content elements and form controls

Server-rendered modules write plain semantic HTML inside `main#pk-main`
(headings, paragraphs, lists, links, fieldsets, labels and form controls
without a wrapper class). The base layer gives this HTML the kit's typography,
rhythm and controls, so no element is drawn with a browser default. This file
is normative; the data lives in `base.yaml` (elements, read properties,
viewports) and in the generated `base-expected.<theme>.json`.

## Layer and scope

`dist/css/papaia-kit.css` declares the layers in this order:

```css
@layer pk.tokens, pk.base, pk.shell, pk.patterns;
```

The base layer comes from `ui/base.css` (also shipped alone as
`dist/css/base.css`). Every rule starts with
`:where(.pk-body #pk-main, dialog.pk-dialog)`: only the content area and kit
dialogs are touched, never the shell, and the scope adds no specificity.
Later layers (shell, pattern classes) and a module's own unlayered styles win
over the base layer. Values come only through `var(--pk-*)`; literal colours,
`@import` and `url()` are refused by the build.

## Elements and rules

| Element | Rule |
|---|---|
| `h2`, `h3`, `h4` | Brand font, colour `text`; `h2` = `.pk-h2` (`--pk-text-xl`, 700), `h3` = `.pk-h3` (`--pk-text-lg`, 600), `h4` `--pk-text-base`, 600 |
| Flow | In the content area, a dialog and the plain grouping elements (`section`, `article`, `form`, `fieldset`, `details`, `blockquote`, `div` without class): blocks 1rem apart, 2rem before a heading, 0.75rem after one; the first child has no top margin. A `div` with a class (a flex or grid row) is not a flow container. |
| `p`, `dl`, `blockquote`, lists without class | At most `--pk-measure` (72ch) wide |
| `ul`, `ol` without class | Indent 1.5rem, items 0.25rem apart |
| `a[href]` | `--pk-color-secondary`, visited the same colour, underline 1px with offset 0.2em, 2px on hover |
| `code`, `kbd`, `samp`, `pre` | Kit mono font `--pk-font-mono` |
| `fieldset` | No frame, no padding |
| `legend` | Group label: `--pk-text-sm`, 600, 0.75rem space below |
| `label` | Block above its field, 500; next to a checkbox or radio inline, 400 |
| `input` (types text, email, search, number, date, time, url, password, or none), `select`, `textarea` | Look of the `.pk-field` controls: height 2.5rem (`textarea` at least 6rem), border `border`, radius `--pk-radius-btn`, ground `surface-raised`; hover border `text-muted`, focus border `secondary` plus the shell's focus ring, invalid (`aria-invalid="true"` or `:user-invalid`) border `error`, disabled ground `disabled-bg` and text `disabled-fg` |
| Field width | Controls stop at `--pk-field-max` (32rem), `textarea` at `--pk-field-max-wide` (40rem); below 640px the full width |
| `input[type=checkbox]`, `input[type=radio]` | 1.125rem, `accent-color: var(--pk-color-primary)` |
| `.pk-inline` | A field and one button on one line; below 480px the button goes under the field |
| A field's error or hint (`p` right after the control) | 0.25rem below the control |

Buttons are pattern classes (`tokens/patterns.css`, layer `pk.patterns`):
`<a class="pk-btn">` and `<button class="pk-btn">` render the same box
(box sizing, margin, font, line height reset); `.pk-form-actions`,
`.pk-dialog-actions`, `.pk-actions` and any `.pk-btn` followed by `.pk-btn`
keep 0.5rem between buttons; the four variants have hover, pressed and
disabled states in the derived colours (below). Disabled is drawn with
`disabled-bg`/`disabled-fg`, not with opacity.

Shell (`ui/shell.css`): the label of the menu button stays on one line (the
menu button is not one of the breaking elements of UXB-P06); `h1`,
breadcrumb and navigation rows hyphenate (`hyphens: auto`, language of the
page) before `overflow-wrap: anywhere` applies; where the heading would get
less than 15rem next to the menu button, it moves onto its own row.

## Variables

The base layer adds variables and changes none: every variable the kit
shares with the manager keeps its value
(`tests/fixtures/tokens/variables-manager.json`, so the value comparison with
the manager, PLT-24-A1, stays equal).

| Variable | Value |
|---|---|
| `--pk-measure` | `72ch` (token `measure`) |
| `--pk-field-max`, `--pk-field-max-wide` | `32rem`, `40rem` (tokens `field.max`, `field.max-wide`) |
| `--pk-color-primary-hover`, `--pk-color-primary-active` | `primary`, one and two OKLCH lightness steps of 0.06 (lighter for a fill darker than L 0.4, else darker) |
| `--pk-color-error-hover` | `error`, one step |
| `--pk-color-surface-hover` | `surface-raised`, 0.05 towards `text` |
| `--pk-color-disabled-bg` | `surface-page`, 0.05 towards `text` |
| `--pk-color-disabled-fg` | `text-muted` without chroma |

The derived colours are computed by the token reader
(`papaia_kit.ui.tokens.derive_state_colors`) when `tools/build.py` writes
`tokens.css`, written out as hex per theme and listed with their contrast in
`tokens/contrast-pairs.yaml`.

## Read properties and comparison rule

Per element `base.yaml` lists the computed properties it is checked on
(`expect`) and the properties whose value must differ from the same page
without the kit stylesheet (`not_default`, taken from `default_props`). Read
properties: `color`, `background-color`, `border-top-color`,
`text-decoration-color`, `accent-color`, `font-family`, `font-size`,
`font-weight`, `line-height`, `margin-top`, `margin-bottom`, `padding-top`,
`padding-left`, `border-top-width`, `border-top-style`,
`border-top-left-radius`, `height`, `width`, `max-width`,
`text-underline-offset`, `text-decoration-thickness`, `text-decoration-line`,
`display`, `box-sizing`, `list-style-type`, `opacity`. Elements in state
`hover` are read under the pointer, `active` with the button held down,
`disabled` as they are; every transition has ended before a value is read.
Values compare with the rule of `specimen.md` (colours in 8-bit sRGB with a
tolerance of 1 per channel, lengths in px rounded to 0.5, `0` as `0px`).

A visited link cannot be read from computed styles (browsers hide
`:visited`); the browser test compares the pixels of a visited and an
unvisited link instead.

## Fixture page and checks

`papaia-kit base page --lang de|en --theme light|dark` prints the fixture
document: the shell of the reference input with the page "Benachrichtigungen"
and the content of `py/papaia_kit/ui/templates/pk/base.html`, plain semantic
HTML with `data-pk-base` hooks. `papaia-kit base expected [--check]` writes or
checks `base-expected.<theme>.json` (part of `make check-tokens`).

The browser test `js/test-browser/base.browser.ts` (`make test-browser`)
checks in both themes: computed styles equal the expected files; no element
keeps the browser default; a visited link looks like an unvisited one;
adjacent buttons are at least 8px apart and of equal height, `<a>` and
`<button>` give the same box; `.pk-inline` wraps below 480px; field widths;
at 390px the menu button label is one line, the `h1` "Benachrichtigungen" is
not split, `h1`, breadcrumb and navigation rows hyphenate, and the page does
not scroll sideways.
