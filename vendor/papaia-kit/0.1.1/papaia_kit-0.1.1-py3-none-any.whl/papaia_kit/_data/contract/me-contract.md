# Personal-area contract, version 2

Every module that keeps personal settings or personal data serves them to the
personal area ("Me") over one module API. The module declares the structure once;
the personal area renders forms from the declaration, asks the module for values with
a token meant for that module only, and stores nothing itself. Version 2 extends
version 1 (core repository, `docs/personal-settings-contract.md`) by field types,
collection operations, group roles, data categories with deletion and receipts,
write results with operation ids, and idempotent destructive operations.

| Part | Where |
|---|---|
| JSON Schema of the declaration and of every API body | `schemas/me-contract.v2.schema.json` (root: declaration; `$defs/<name>`: API bodies, listed in `$defs/api_message`) |
| Test vectors (declarations, runtime entries, exchanges) | `testing/vectors/me-contract.v2.json` |
| Address, base path and audience of the module API | the module's `exposes` entry of kind `me` (`exposes.md`) |
| Exit export schema of the module | `exposes[].export.exit.schema` (`exposes.md`) |

Where this text and the schema disagree, the schema wins and the text is corrected.
The words MUST, MUST NOT and MAY are used as in RFC 2119.

## Declaration

The declaration is the value of the manifest key `personal_settings:` (an add-on in
its `papaia-app.yaml`, a core module in `personal-settings.yaml` of its directory).
It holds structure and defaults only, never values and never secrets.

<!-- schema: # -->
```yaml
personal_settings:
  api: 2
  module: papaia-assist
  title: {de: "Assistant", en: "Assistant"}
  exposes: assist.me
  data:
    summary: /api/me/data/summary
    export: /api/me/data/export
    activity: /api/me/data/activity
    erasure: self
    categories:
      - {id: memory, erasure: self, erasure_endpoint: /api/me/data/memory/erase}
      - {id: conversations, erasure: request, erasure_endpoint: /api/me/data/conversations/erasure-request}
      - {id: usage, erasure: none}
  groups:
    - id: answers
      title: {de: "Antworten", en: "Answers"}
      data_class: personal
      settings:
        - key: detail
          type: choice
          default: short
          options:
            - {value: short, title: {de: "Kurz", en: "Short"}}
            - {value: full, title: {de: "Ausführlich", en: "Detailed"}}
          title: {de: "Ausführlichkeit", en: "Level of detail"}
    - id: memory
      kind: collection
      role: memory
      title: {de: "Gedächtnis", en: "Memory"}
      data_class: personal
      item:
        fields:
          - {key: text, type: multiline_text, max_length: 2000, content: true,
             title: {de: "Was soll sich Assistant merken?", en: "What should Assistant remember?"}}
          - {key: origin, type: provenance, editable: false, title: {de: "Herkunft", en: "Origin"}}
      operations: [create, update, delete]
      delete_all: true
      empty_hint: {de: "Noch nichts gemerkt, etwa: Ich bevorzuge kurze Antworten.",
                   en: "Nothing remembered yet, for example: I prefer short answers."}
    - id: reminders
      kind: collection
      role: reminders
      title: {de: "Erinnerungen", en: "Reminders"}
      data_class: personal
      item:
        fields:
          - {key: text, type: multiline_text, max_length: 500, content: true, title: {de: "Text", en: "Text"}}
          - {key: due, type: datetime, max_days: 366, title: {de: "Fällig", en: "Due"}}
          - {key: repeat, type: recurrence, title: {de: "Wiederholung", en: "Repeat"}}
      operations: [create, update, delete]
```

| Key | Rule |
|---|---|
| `api` | `2`. A declaration with `1` is checked against the version 1 schema; see [Versions](#versions). |
| `module` | unique across the installation; for an add-on its manifest name |
| `title` | plain text, `de` and/or `en`, at most 80 characters each |
| `exposes` | id of the module's `exposes` entry of kind `me`; the personal area takes address, base path and audience from there and from nowhere else. There is no audience of the personal area itself. |
| `data` | see [Data](#data) |
| `groups` | 1 to 32 groups, see [Groups](#groups) |

## Groups

Every group has `id` (stable key), `title`, optional `description` (at most 300
characters), `data_class` (the platform's eight-level scale, `data-classes.md`) and
`sensitive`. `kind` is `settings` (the default: key and value) or `collection`
(items with a life cycle).

- **Fresh sign-in marker.** `sensitive: true` means every write to the group needs a
  sign-in at most 300 s old. The module checks `auth_time` of the presented token and
  otherwise answers `403 step_up_required` with `max_age: 300`; the personal area signs
  the person in again (`prompt=login`, `max_age`) and repeats the request once with a
  newly exchanged token. The same check applies, independent of `sensitive`, to
  `delete_all`, to deleting a data category the person deletes (`self`) and to the
  export of data from the class `personal` upwards.
- A settings group lists 1 to 64 fields in `settings`.
- A collection lists 1 to 16 item fields in `item.fields` and the operations it serves
  in `operations`. `delete_all: true` (requires `delete`) lets the person delete every
  item at once. `empty_hint` (`de` and `en`, at most 200 characters) is shown while the
  collection is empty.

### Group roles

`role` tells the personal area on which page it shows the group; a group without a
role appears on the module's settings page.

| Role | Kind | Rule |
|---|---|---|
| `reachability` | settings | how the person is reached; only the core service for preferences declares it, a second declaration stops the render |
| `language` | settings | language and region; only the core service for preferences |
| `memory` | collection | what the assistant remembers about the person |
| `reminders` | collection | must serve `create` and carry a `datetime` and a `recurrence` field; the personal area creates reminders |
| `delegation` | collection | authorisations the person granted to a holder |
| `accounts` | collection | access accounts of the person at connected systems |

## Field types

The set is closed; a declaration with any other type is refused. Every field has
`key` (`^[a-z][a-z0-9_]{0,63}$`, stable), `title`, optional `hint`, `replaces` (the
key it was renamed from), `editable` (default `true`) and `content` (default
`false`).

| Type | Own properties | Value in the module API |
|---|---|---|
| `boolean` | `default` | `true` / `false` |
| `choice` | `options` (required), `default` | one option value, in the type of the options |
| `multi_choice` | `options` (required), `default` (list) | list of option values, no duplicates, order irrelevant |
| `ordered_multi_choice` | `options` (required), `default` (list) | list of option values, no duplicates, order is the person's priority |
| `integer` | `min`, `max` (both required), `default` | integer |
| `text` | `max_length` (1..1000, required), `pattern`, `default` | string, plain text, one line |
| `multiline_text` | `max_length` (1..4000, required), `default` | string, plain text, line breaks allowed |
| `time_range` | `default` | `{"start": "HH:MM", "end": "HH:MM"}`; `end` before `start` crosses midnight |
| `date` | `max_days` (1..3660) | `"YYYY-MM-DD"`, from today to today + `max_days` |
| `datetime` | `max_days` (1..3660) | `{"at": "YYYY-MM-DDTHH:MM[:SS]", "tz": "<IANA zone>"}`: wall-clock time in the zone, no offset |
| `recurrence` | `forms` (subset of the five forms), `default` | `{"form": "none" \| "daily" \| "weekdays"}`, `{"form": "weekly", "weekdays": ["mo", …]}`, `{"form": "monthly", "month_day": 1..31}` |
| `person` | none | write: the id as a string; read: `{"id", "display"}` |
| `provenance` | `editable` must be `false` | read only: `{"source": {"kind", "ref"?, "title"?}, "created_at", "created_by"}` |

- `options` is `runtime` or a list of 1 to 64 `{value, title}`; an option value is a
  string (`^[a-z0-9/][a-z0-9_./-]{0,254}$`), an integer within ±(2^53 − 1) or a boolean,
  and all options of one field have one type. JSON keeps `1`, `true` and `"1"` apart,
  and so does every party.
- `editable: false`: the personal area shows the value as text; a write that carries
  the key is refused with the field error `read_only`.
- `content: true`: the value is content of the person (a memory, a reminder text). It
  is never logged, never cached, never part of an audit row, and every answer that
  carries it has `Cache-Control: no-store`.
- A `recurrence` is a subset of RFC 5545 RRULE (FREQ=DAILY, DAILY with BYDAY=MO..FR,
  WEEKLY with BYDAY, MONTHLY with BYMONTHDAY); the five forms are the whole set.
- `provenance.source.kind` is `conversation` (with `ref` and `title` of the
  conversation), `me` (created in the personal area) or `module`; `created_by` is
  `person`, `assistant` or `module`.

## Collection operations

| Operation | Request | Answer |
|---|---|---|
| `create` | `POST {base}/{group}/items` with `Idempotency-Key` and the fields | `201` `item_write_result`, `Location: {base}/{group}/items/{id}` |
| `update` | `POST {base}/{group}/items/{id}/update` with `If-Match`, `Idempotency-Key` and the changed editable fields | `200` `item_write_result` |
| `delete` | `POST {base}/{group}/items/{id}/delete` with `If-Match`, `Idempotency-Key`, no body | `200` `delete_result` with `deleted: 1` |
| `end` | `POST {base}/{group}/items/{id}/end` with `If-Match`, `Idempotency-Key`, optional fields | `200` `item_write_result` |
| `renew` | `POST {base}/{group}/items/{id}/renew` with `If-Match`, `Idempotency-Key`, optional fields | `200` (or `201` when the renewal is a new item) `item_write_result` |

`delete_all` is not an item operation: `POST {base}/{group}/delete_all` with
`If-Match` (the collection's ETag), `Idempotency-Key` and a fresh sign-in, answer
`200` `delete_result` with the number deleted. An item lists in `operations` the
declared operations it allows now (never `create`); an operation that does not fit
the item's state answers `409 not_allowed_now`.

## Module API

`{base}` is the path of the `exposes` entry of kind `me`. Bodies are JSON in UTF-8.
Every answer carries `Cache-Control: no-store`; an answer larger than 256 KiB (except
the export) or slower than 2 s counts as "module not reachable". The personal area
sends `X-Papaia-Correlation-Id` with every request; the module writes one
`papaia.audit/1` row per write with that id, naming the group and the changed keys,
never values.

### Read all groups

```http
GET {base}
```

<!-- schema: #/$defs/read_response -->
```json
{
  "contract": 2,
  "module": "papaia-assist",
  "groups": {
    "answers": {"etag": "\"a-3\"", "values": {"detail": "short"},
                "runtime": {"options": {"detail": [{"value": "short"}]}}},
    "memory": {"etag": "\"m-12\"", "count": 4}
  }
}
```

A group the person may not use is left out; the personal area derives no rights itself.

### Runtime only narrows

`runtime.options.<key>` (a subset of the declared options, in their type; for
`options: runtime` 0 to 64 entries with `title`, the only source) and
`runtime.bounds.<key>` (`{min, max}` within the declared range, `{max_length}` at most
the declared one, `{max_days}` at most the declared one) may only narrow the
declaration. The personal area drops every entry that widens it, offers nothing from
it, shows the group read-only and records `me.declaration_mismatch` without values.

### Replace a settings group

```http
PUT {base}/{group}
If-Match: "a-3"
Idempotency-Key: "5b0c2f3e-8a41-4c7e-9a8f-0d6e1b2c3a4f"
```

<!-- schema: #/$defs/settings_write -->
```json
{"detail": "full"}
```

The body holds every editable declared key; a key that is not declared is
`unknown_key`, a key with `editable: false` is `read_only`. Answer `200`, the new ETag
also in the `ETag` header:

<!-- schema: #/$defs/settings_write_result -->
```json
{"etag": "\"a-4\"", "values": {"detail": "full"}, "operation_id": "op-7c41",
 "undo_token": "u7d0Qm2xR4pL9sV1"}
```

### Items of a collection

```http
GET {base}/{group}/items?page_token=<t>&limit=<n>&q=<text>
```

`limit` is 1 to 100 (default 20), `q` (2 to 64 characters) searches the item texts of
the person, `page_token` is the `next_page_token` of the previous page (`null` on the last page).

<!-- schema: #/$defs/items_page -->
```json
{
  "etag": "\"m-12\"",
  "items": [
    {"id": "mem-1", "etag": "\"mem-1-2\"", "state": "active",
     "fields": {"text": "Ich bevorzuge kurze Antworten.",
                "origin": {"source": {"kind": "conversation", "ref": "c-81", "title": "Reiseplanung"},
                           "created_at": "2026-11-20T09:14:03Z", "created_by": "assistant"}},
     "operations": ["update", "delete"]}
  ],
  "next_page_token": null
}
```

Create, update, end and renew send the fields:

<!-- schema: #/$defs/item_write -->
```json
{"text": "Termine bitte immer mit Wochentag.",
 "due": {"at": "2026-12-01T09:00", "tz": "Europe/Berlin"},
 "repeat": {"form": "weekly", "weekdays": ["mo"]}}
```

<!-- schema: #/$defs/item_write_result -->
```json
{"operation_id": "op-7c42", "undo_token": "u8e1Rn3yS5qM0tW2",
 "item": {"id": "rem-9", "etag": "\"rem-9-1\"", "state": "active",
          "fields": {"text": "Termine bitte immer mit Wochentag.",
                     "due": {"at": "2026-12-01T09:00", "tz": "Europe/Berlin"},
                     "repeat": {"form": "weekly", "weekdays": ["mo"]}},
          "operations": ["update", "delete"]}}
```

Delete and delete all answer a receipt:

<!-- schema: #/$defs/delete_result -->
```json
{"operation_id": "op-7c43", "receipt_id": "rcpt-2b91", "deleted": 4}
```

### Undo

Every reversible write (replace, create, update, end, renew) MAY answer an
`undo_token`, valid 15 s, single use, bound by the module to the person and the
operation. The module keeps the previous state, not the personal area.

```http
POST {base}/undo
Idempotency-Key: "0e7d6c5b-4a39-4281-9f0e-d1c2b3a4f5e6"
```

<!-- schema: #/$defs/undo_request -->
```json
{"undo_token": "u7d0Qm2xR4pL9sV1"}
```

<!-- schema: #/$defs/undo_result -->
```json
{"operation_id": "op-7c44"}
```

After 15 s, after a second use or when another change came in between, the module
answers `409 undo_expired` or `412 stale` and changes nothing.

### Choosing a person

`GET {base}/{group}/persons?q=<text>` as in version 1: `q` 2 to 64 characters, at most
20 entries sorted by `display`, only persons the caller may name for that group,
`429 rate_limited` beyond the module's bound.

<!-- schema: #/$defs/persons_response -->
```json
{"persons": [{"id": "4c0a9e1d-2b7f-4f53-9d0e-6a1c2b3d4e5f", "display": "Bernd Muster"}]}
```

## Data

`data.summary`, `data.export` and the optional `data.activity` are paths below the
module's service; `data.categories` lists the categories with their deletion route.

### Erasure modes

| Mode | Meaning | `erasure_endpoint` |
|---|---|---|
| `none` | kept for the reason and period named in the summary; no deletion route | not allowed |
| `self` | the person deletes the category; fresh sign-in; answer `erasure_receipt` with `state: done` and the number deleted | required |
| `request` | the module registers a request to the data protection contact; answer `202` `erasure_receipt` with `state: registered` | required |

`data.erasure` names the strongest mode of the module's categories: with `self` at
least one category is `self`, with `request` at least one is `request` and none is
`self`, with `none` every category is `none`.

### Summary

<!-- schema: #/$defs/summary_response -->
```json
{"contract": 2,
 "categories": [
   {"id": "memory", "title": {"de": "Gedächtnis", "en": "Memory"}, "count": 4,
    "data_class": "personal",
    "purpose": {"de": "Damit Assistant Ihre Vorlieben kennt.", "en": "So Assistant knows your preferences."},
    "retention": {"de": "Bis Sie den Eintrag löschen.", "en": "Until you delete the entry."}}
 ]}
```

Counts only, never content; `id` is a category of the declaration.

### Export

`GET {data.export}` answers the person's own data as one JSON object, built on every
call and never stored, in the shape of the module's exit export schema. It contains
the `content` fields and therefore needs a fresh sign-in from the data class
`personal` upwards.

### Deleting a category

```http
POST /api/me/data/memory/erase
Idempotency-Key: "7f3e2d1c-0b9a-4876-a5f4-e3d2c1b0a9f8"
```

<!-- schema: #/$defs/erasure_request -->
```json
{}
```

<!-- schema: #/$defs/erasure_receipt -->
```json
{"receipt_id": "rcpt-5e02", "operation_id": "op-9a10", "mode": "self", "state": "done", "deleted": 4}
```

A request (mode `request`) carries the kind and an optional note of the person:

<!-- schema: #/$defs/erasure_request -->
```json
{"kind": "erasure", "note": "Bitte auch die Anhänge löschen."}
```

<!-- schema: #/$defs/erasure_receipt -->
```json
{"receipt_id": "req-5e03", "operation_id": "op-9a11", "mode": "request", "state": "registered"}
```

The `receipt_id` is the person's proof; the module keeps it with the deletion
journal so that a deletion survives a restore.

### Activity

<!-- schema: #/$defs/activity_response -->
```json
{"entries": [{"time": "2026-11-20T09:20:00Z", "operation_id": "op-7c43", "group": "memory",
              "action": "delete_all", "correlation_id": "c0a8-4e2f-91"}]}
```

The person's own latest writes, newest first, at most 100, without values.

## Conflicts and idempotency

- **ETag.** One strong ETag (RFC 9110, quoted, at most 128 characters) per group, per
  collection and per item. It changes on every change by whatever route and is
  opaque. `PUT`, every item operation and `delete_all` require `If-Match`: without it
  the module answers `428 precondition_required`, with an old one `412 stale` with
  the current `etag`, and nothing is changed. `If-Match: *` is not accepted, so every
  write follows a read.
- **Idempotency key.** Every write of version 2 carries `Idempotency-Key` (a UUID as a
  structured-field string, new for every submitted form); without it the module
  answers `400 malformed_request`. The module keeps the key per person, module, method
  and path for at least 24 hours. A repeat with the same key and the same body
  answers the first answer again, status, `operation_id` and `receipt_id` included,
  and does nothing a second time. The same key with another body, or while the first
  request still runs, answers `409 conflict`.
- **Write result.** Every write answers an `operation_id`; the personal area shows it
  as the reference of the confirmation and the audit row carries it.

## Errors

The error body is `application/problem+json` (RFC 9457) with the contract code in
`code`; the module's own code MAY follow in `module_code` and a plain-text `detail`
(at most 300 characters) is shown only as text, never interpreted.

<!-- schema: #/$defs/error -->
```json
{"status": 412, "code": "stale", "etag": "\"a-5\"", "correlation_id": "c0a8-4e2f-91"}
```

<!-- schema: #/$defs/error -->
```json
{"status": 403, "code": "step_up_required", "max_age": 300}
```

<!-- schema: #/$defs/error -->
```json
{"status": 422, "code": "invalid",
 "errors": [{"pointer": "/due/tz", "code": "unknown_time_zone"},
            {"pointer": "/origin", "code": "read_only"}]}
```

| Status | `code` | Meaning |
|---|---|---|
| `400` | `malformed_request` | not JSON, not the shape above, or `Idempotency-Key` missing |
| `401` | `unauthorized` | token missing, invalid or not for this audience |
| `403` | `forbidden` | the person may not use this group or item |
| `403` | `step_up_required` | a fresh sign-in is needed; `max_age` (s) names how fresh |
| `404` | `unknown_group`, `unknown_item`, `unknown_operation` | |
| `405`, `409` | `not_allowed_now` | `PUT` on a collection (405); the operation does not fit the item's state (409) |
| `409` | `conflict` | the `Idempotency-Key` was used for another request, or its first request still runs |
| `409` | `undo_expired` | the undo token is older than 15 s or was used |
| `412` | `stale` | the ETag in `If-Match` is not the current one; `etag` names the current one |
| `422` | `invalid` | values do not pass the module's checks; `errors` lists them |
| `428` | `precondition_required` | `If-Match` is missing |
| `429` | `rate_limited` | too many requests of this person; `Retry-After` says when |
| `503` | `maintenance` | the module is in its backup window; nothing was done |

## Field error codes

`pointer` is a JSON Pointer (RFC 6901) into the request body.

| `code` | For |
|---|---|
| `required` | a declared key is missing |
| `unknown_key` | a key that is not declared |
| `read_only` | a key with `editable: false` or of type `provenance` |
| `wrong_type` | the value has the wrong JSON type |
| `not_an_option` | not among the (runtime) options |
| `duplicate` | a value twice in a list |
| `out_of_range` | integer outside the (runtime) bounds |
| `too_long` | text longer than the (runtime) `max_length` |
| `pattern_mismatch` | text does not match `pattern` |
| `invalid_time` | not `HH:MM` |
| `invalid_date` | not a date, in the past or beyond `max_days` |
| `invalid_datetime` | not a valid wall-clock time, in the past or beyond `max_days` |
| `unknown_time_zone` | `tz` is not a zone of the IANA time zone database |
| `invalid_recurrence` | not one of the declared forms, or its weekdays or day do not fit |
| `unknown_person` | no such person in the directory |
| `not_allowed` | the module's own rule refuses the value |

## Versions

- The core serves the window `API_MIN = 1`, `API_CURRENT = 2`. `api` of the
  declaration and `contract` of the module API count the same generation. Modules with
  version 1 and version 2 run side by side; the personal area shows and stores both.
- A declaration with `api: 1` is checked against the version 1 schema; a declaration
  with a higher `api` than the consumer serves is not refused by the render step: the
  personal area shows the module read-only with a link into the module and a note
  naming the reason, and saving is blocked.
- A group with a field type the consumer does not know is shown read-only.
- Keys are stable; a renamed key names the old one in `replaces`.

## Checks beyond the schema

The render step of the core and the personal area apply these rules in addition to
the schema. The render step refuses a declaration that violates the schema or one of
these rules with the file name and the JSON Pointer of the place (the error locations
of the vectors in `testing/vectors/me-contract.v2.json` show where), and the registry
stays at its previous valid state.

- Plain text as in version 1: no markup, links, model control tokens or text shaped
  like an instruction to a model (`instruction-patterns.yaml`).
- Defaults fit: among the options, within `min`..`max`, at most `max_length`, matching
  `pattern`; `min` ≤ `max`; `pattern` within the safe subset of version 1.
- Unique: group ids per module, keys per group or item, option values per field,
  category ids per module, module names across the installation.
- `exposes` names an entry of kind `me` of the same module; `data.categories` and the
  summary name the same category ids.
- At most one `reachability` group in the installation.
- `datetime.at` is a real calendar time and `tz` a zone of the IANA database.
