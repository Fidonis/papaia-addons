# Patterns

The nine interaction patterns and the components (layout primitives, section
head, card, module tile, list rows, badges and counts, description lists, the
actions menu, the welcome) every module renders the same way. Mandatory are
the element, its role, the ARIA attributes, the `data-pk-*` hooks and the fixed
texts. Recommended are the `pk-*` classes of `dist/css/patterns.css` (layer
`pk.patterns` of `papaia-kit.css`). Own classes and components are allowed when
the computed styles of the specimen page are the same and own values use only
`var(--pk-*)`.

| File | Content |
|---|---|
| `patterns.yaml` | States per pattern and per component, mandatory elements, fixed text keys, timing |
| `examples/<id>.<lang>.html` | Example markup of a pattern or component, one `<section data-pk-example="<state>">` per state |
| `../messages/patterns.{de,en}.yaml` | Fixed texts of the patterns |
| `../messages/welcome.{de,en}.yaml` | Fixed texts of the welcome (`pk-welcome`) |
| `../messages/states.{de,en}.yaml` | Fixed texts of the five states (missing, stopped, no access, not found, session expired) |
| `../messages/codes.{de,en}.yaml`, `../messages/consequences.{de,en}.yaml` | Pattern 8 texts per code and the closed list of consequence sentences |
| `../vectors/formats.json` | Pattern 9 formats, kinds of time value, shared test vectors |

`papaia_kit.ui.patterns.check_example` checks parsed markup against a state of
`patterns.yaml` (`load_patterns()` for the nine patterns, `load_components()`
for the components); `papaia_kit.ui.messages.text` fills a fixed text;
`papaia-kit messages check [--dir DIR]` runs the forbidden patterns
(`../forbidden-patterns.yaml`) over every message file of a directory, with
placeholders filled, and fails when the German and English files differ in
keys or placeholders.

## Symbols and surfaces

No state is told apart by colour alone. Every message block shows a symbol
`<svg class="pk-icon" aria-hidden="true" focusable="false"><use
href="…/sprite.svg#pk-icon-<symbol>"></use></svg>` and a text; `symbols` in
`patterns.yaml` is the rule the checker applies:

| Block | Symbol |
|---|---|
| `.pk-toast`, `.pk-alert` with `data-pk-tone` | `info` → `info`, `success` → `circle-check`, `warning` → `warning`, `error` → `circle-x` |
| `.pk-error` (pattern 8) | `circle-x` |
| `.pk-loading` (pattern 7) | `loader`, turning with `data-pk-spin` (still under reduced motion) |
| `.pk-empty` (pattern 6) | any; `inbox` by default, `data-pk-size="lg"` |

Toast markup: symbol, `<p class="pk-message-text">`, optional undo form
(`data-pk-size="sm"` ghost button "Rückgängig" / "Undo"), close button
`<button type="button" class="pk-btn" data-pk-variant="ghost"
data-pk-size="sm" data-pk-icon-only data-pk-dismiss aria-label="Meldung
schließen">` ("Close message", text `close_message`). The surface is
`--pk-color-<tone>-subtle` with a 4 px accent bar in the tone colour at the
start; a toast also has `--pk-shadow-md`, at most 28rem width and enters and
leaves in 0.2 s (none under reduced motion); `shell.js` removes a message
whose close button is pressed. The inline alert `.pk-alert` looks the same in
the flow of the page, for hint lines with `role="status"` such as
`states.stopped`; the shell's notice zone uses the same look. Symbol-only
buttons (`data-pk-icon-only`) need an `aria-label`; small buttons
(`data-pk-size="sm"`) are 2rem high, every target at least 24 × 24 px. Symbol
sizes: `.pk-icon[data-pk-size="sm|md|lg"]` (1, 1.25, 1.5rem).

`papaia_kit.ui.patterns.check_example` reports a block without symbol, with a
visible symbol (no `aria-hidden="true"`), with the wrong symbol or without
text, and a symbol-only button without name.

## Timing

One value per entry in all modules (`patterns.yaml`, `timing`):

| Entry | Value |
|---|---|
| Undo offer after a reversible write (patterns 4 and 5) | 15 s, equal to the validity of `undo_token`, and as long as pointer or focus is inside |
| Loading indicator appears after | 0.3 s |
| Second loading stage after | 10 s |
| Loading aborted with a pattern 8 message after | 30 s |
| Success toast stands at least | 6 s; error toasts stay until closed |

## Pattern 1: table

`<table>` with `<th scope="col">`; sorting through a `<button>` in the header
cell and `aria-sort` on the `th`; container `div.pk-table-scroll` with
`tabindex="0"` and a name. From 50 rows on, pages with the range
`table_range` ("1–50 von 120" / "1–50 of 120"). Row action in the last column,
one visible, the rest in a menu ("Weitere Aktionen" / "More actions");
multiple selection only with check boxes. Focus outlines inside scroll
containers are drawn inward (`outline-offset: -2px`). States: `default`, `paged`.

## Pattern 2: form

`<label for>` above the field; mandatory fields carry `required`,
`aria-required="true"` and "(Pflicht)" / "(required)" in the name; field
errors in a `<p id>` referenced by `aria-describedby`; error summary
`<div role="alert" tabindex="-1">` ("Prüfen Sie die markierten Angaben." /
"Check the marked details."), focused after a failed submit. Checks run on
leaving a field and on submit. Primary action bottom left, "Abbrechen" /
"Cancel" next to it. Unsaved changes on leaving: dialog "Änderungen
verwerfen?" / "Discard changes?" with focus on "Weiter bearbeiten" / "Keep
editing". Every form posting to the module carries the hidden field
`pk_csrf`. States: `default`, `error`, `discard`.

## Pattern 3: write in the own module

Message in `role="status"`: "Gespeichert." / "Saved.". State: `default`.

## Pattern 4: write into an integration

Before writing, a `<dialog aria-labelledby aria-describedby>` names the three
details `data-pk-confirm="integration|function|object"` ("Anbindung",
"Funktion", "Objekt" / "Integration", "Function", "Object"); without
confirmation nothing is written. Afterwards the receipt "Ausgeführt am <Zeit>.
Kennung: <Korrelationskennung>" / "Carried out on <time>. Reference:
<correlation id>", whose reference is found in the audit. A reversible write
offers "Rückgängig" / "Undo" for the undo window (`data-pk-undo-ms="15000"`).
States: `dialog`, `receipt`, `undo`.

## Pattern 5: destructive action

`pk-btn` with `data-pk-variant="danger"`; `<dialog>` with default focus on
"Abbrechen" / "Cancel" (`autofocus`), so the Enter key deletes nothing. The
dialog names object and consequence: "„<Objekt>“ wird endgültig gelöscht." /
"“<object>” will be deleted permanently.", or "… wird gelöscht und kann
<Frist> wiederhergestellt werden." / "… will be deleted and can be restored
for <period>.". More than one object: the number ("<n> Einträge werden
endgültig gelöscht."), the affected people, groups, workflows or dashboards
("Betroffen: …" / "Affected: …") and typing the name ("Geben Sie zur
Bestätigung „<Name>“ ein.") or a fresh sign-in. After a reversible delete the
same undo offer as in pattern 4. Every write action of a module is classified
in its `ui/write-actions.yaml` as `umkehrbar`, `endgültig` or `wirkt auf
andere`. States: `final`, `restorable`, `many`, `undo`.

## Pattern 6: empty state

`<div class="pk-empty" data-pk-state="empty">` with a symbol (`inbox` by
default), one sentence saying what appears here (in `--pk-color-text`) and at
most one action as a secondary button. The sentence belongs to the module.
Inside cards `data-pk-compact` gives less space and a smaller symbol. State:
`default`.

## Pattern 7: loading

`<div data-pk-state="loading" aria-busy="true">`, shown only after 0.3 s:
the turning `loader` symbol next to "Wird geladen …" / "Loading …". Lists and
cards may show skeleton blocks `<span class="pk-skeleton" aria-hidden="true">`
(`data-pk-shape="card"` for a card) with the text for screen readers. After 10 s "Das dauert länger als üblich." /
"This is taking longer than usual."; after 30 s the load is aborted with a
pattern 8 message, for example "Die Daten konnten nicht geladen werden. Es
wurde nichts geändert." / "The data could not be loaded. Nothing was
changed.", and "Erneut versuchen" / "Try again". States: `loading`, `slow`,
`skeleton`, `failed`.

## Pattern 8: error message

`<div class="pk-error" role="alert">` with three children
`data-pk-part="what|todo|id"` in this order: (1) what happened, one sentence,
followed where the person entered or triggered something by the consequence
sentence `<span data-pk-part="consequence">` from the closed list (referred to
by id in `codes.{de,en}.yaml`; free consequence text is rejected; the list
grows only with a kit minor version, see `consequences.register.json`); (2)
what to do, exactly one action; (3) "Kennung: <Korrelationskennung>" / "Reference:
<correlation id>" with a small ghost copy button ("Kennung kopieren" / "Copy
reference"). The block starts with the `circle-x` symbol on the subtle error
surface.
Parts 1 and 2 never match a forbidden pattern. The state pages "Kein Zugang" /
"No access" (HTTP 403) and "Nicht gefunden oder nicht erlaubt" / "Not found or
not permitted" (HTTP 404) inside the frame use the texts of
`states.{de,en}.yaml` and the same reference line. States: `default`,
`unavailable` (inline alert with `states.stopped`), `no_access`, `not_found`.

## Pattern 9: date, time, number

`<time datetime="2026-03-07T14:05:00+01:00">`; German "07.03.2026", "14:05",
"1.234.567,5"; English "7 Mar 2026", "14:05", "1,234,567.5". The date never
contains a weekday. `formats.json` decides per kind of time value whether a
weekday stands as its own element `<span data-pk-weekday>` before the
`<time>`: with weekday for due dates, reminders and the next scheduled run;
never for log entries, versions and the data state. Form: "Sa., 07.03.2026,
14:05" / "Sat 7 Mar 2026, 14:05". The server formats in the time zone of the
person (`time_zone` from `prefs`). Relative times only with the absolute time
as `title` or second line; exports in ISO 8601 with offset. Formats are fixed
patterns with the kit's own month list, not locale data (English "Sep", never
"Sept"); Python (`papaia_kit.ui.formats`) and TypeScript (`@papaia/kit`) run
the same vectors. Numbers use `<data value="1234567.5">`. States:
`with_weekday`, `without_weekday`, `number`.

```python
from papaia_kit.ui.formats import format_moment, format_number, moment_html

moment = format_moment(due_at, kind="due", lang="de", time_zone="Europe/Berlin")
moment.text  # "Sa., 07.03.2026, 14:05"
moment_html(
    moment
)  # '<span data-pk-weekday>Sa.</span>, <time datetime="…">07.03.2026, 14:05</time>'
format_number("1234567.5", "en")  # "1,234,567.5"
```

## Components

Building blocks that are not one of the nine numbered patterns, described in
`patterns.yaml` under `components` in the same form (states, mandatory
elements, fixed texts) and with examples per language. The recommended classes
are in `dist/css/patterns.css`; their children lose the flow margins of the
base layer. Symbols are `<svg class="pk-icon" aria-hidden="true"
focusable="false" data-pk-symbol="<name>">`; the examples write the reference
as a fragment (`<use href="#pk-icon-lock">`), a module points it at its copy of
`icons/sprite.svg`. A state is never told by colour alone: it always has a
symbol and words. `papaia-kit components page [--lang] [--theme]` prints every
example inside the shell (fixture of `js/test-browser/components.browser.ts`).

## Component: layout

| Class | Behaviour |
|---|---|
| `.pk-stack` | Vertical, `data-pk-gap="sm|md|lg"` = 0.5, 1, 2rem (`md` without the attribute) |
| `.pk-cluster` | Wrapping row, gap 0.5rem, centred on the cross axis |
| `.pk-grid` | As many columns as fit, each at least `data-pk-min="sm|md|lg"` = 12, 16, 22rem (`md` without the attribute), gap 1rem, never wider than its container |
| `.pk-lead` | Intro paragraph: `--pk-text-lg`, `text-muted`, at most `--pk-measure` |

States: `stack`, `cluster`, `grid`, `lead`.

## Component: section

`<section aria-labelledby>` with `div.pk-section-head`: the `h2` (with `id`) on
the left; on the right optionally a count `span.pk-section-count` with
`<data value>` and at most one action (`.pk-btn`); optionally a description
`p.pk-section-description` below in `text-muted`. Below 640px the parts stack.
On the landing page each section has one `h2` (UXB-P16). States: `default`
(count and action), `described`.

## Component: card

`.pk-card` on `<article>` or `<section>` with `aria-labelledby`: raised
surface, 1px border, `--pk-radius-box`, padding 1.25rem (1rem below 640px).
Parts: `div.pk-card-head` (title `h3` and one trailing action, on one baseline
from 640px, stacked below), `div.pk-card-body` (for example one summary
sentence), `p.pk-card-foot` (meta line, 0.875rem, `text-muted`). A card that is
one link (`data-pk-linked`) holds exactly one real `<a class="pk-card-link">`
in its title whose hit area covers the card: one tab stop, no other control.
`data-pk-state="unavailable"`: dashed border on `--pk-color-surface-sunken`,
`p.pk-card-status` with the warning symbol and the fixed sentence of
`states.{de,en}.yaml` (`stopped.text`). `data-pk-highlight` with
`tabindex="-1"`: 2px `secondary` border for the target card of an address such
as `/reminders/{id}`, which the page focuses. States: `default`, `linked`,
`unavailable`, `highlight`.

## Component: tile

Module tiles of the landing page (interface spec 2.6, PLT-58): `ul.pk-tiles`
(at most three columns, at least 18rem each, one column on narrow screens),
one `li.pk-tile` per module with `data-pk-state="open|no_access|stopped"`.

- `open`: symbol `span.pk-tile-symbol` (2.5rem on `nav-active-bg`), display
  name `h3.pk-tile-name` (brand font, 600, `--pk-text-lg`) holding the one
  link `a.pk-tile-link` whose hit area covers the tile, purpose
  `p.pk-tile-purpose` (one sentence of at most 15 words), example
  `p.pk-tile-example` led by `<span data-pk-label="example">` "Beispiel:" /
  "Example:", and `span.pk-tile-go` with the symbol `go` (the arrow). A link
  that opens a new tab has `target="_blank" rel="noopener noreferrer"`, the
  hint `span.pk-tile-hint` "(öffnet in neuem Tab)" / "(opens in new tab)"
  inside the link and the symbol `external-link`. Hovering raises the border
  colour and adds `--pk-shadow-sm`. Name, purpose and example come from the
  platform catalogue (`ui[].summary`, `ui[].example`), never from the module.
- `no_access`: an installed module the person cannot open. No link; dashed
  border on `--pk-color-surface-sunken`; `p.pk-tile-status` with the lock
  symbol and "Kein Zugang" / "No access" (`states.no_access.title`), then the
  sentence "Zugang erhalten Sie über <Ansprechstelle>." / "You can get access
  through <contact point>." (`states.no_access.todo`, contact point from
  `branding.contact`). Every text in `--pk-color-text`, no `opacity`.
- `stopped`: no link; `p.pk-tile-status` with the warning symbol and the
  sentence `states.stopped.text` ("<Modul> ist gerade nicht erreichbar.").

## Component: list

Lists of tasks, search hits, memory entries and reminders: `ul.pk-list` with
one `li.pk-list-row` per entry, divided by 1px lines, `--pk-color-surface-hover`
under the pointer. Slots of a row, in this order:

- `span.pk-list-symbol` (optional): leading symbol, for example the module;
- `div.pk-list-body` with `p.pk-list-primary` (link or text, 600) and
  `p.pk-list-meta` (0.875rem, `text-muted`): module, due date and the like.
  Dates follow pattern 9 with the weekday element for the kinds of
  `formats.json` that have one (`due`, `reminder`, `next_run`), written by
  `papaia_kit.ui.formats.moment_html`;
- `span.pk-list-trail` (optional): one badge or one action.

A row that is one link (`data-pk-linked`) holds exactly one real
`<a class="pk-list-link">` in its primary line whose hit area covers the row:
one tab stop, no other control in the row. `data-pk-density="compact|comfortable"`
on the list sets the row padding (0.5rem or 0.75rem; `comfortable` without the
attribute). States: `linked`, `action`, `compact`.

## Component: badge

`span.pk-badge` with `data-pk-tone="neutral|info|success|warning|error"`: a
small pill on the subtle surface of the tone (`--pk-color-<tone>-subtle`,
neutral on `--pk-color-surface-sunken`), text in `--pk-color-text`, an
optional symbol in the tone colour before it. The text is always present; the
checker rejects a badge without words or with an unknown tone.

Count `span.pk-count`: a pill with tabular figures on `nav-active-bg` after a
heading or a navigation entry, `<data value="<n>">` and the hidden words
`<span class="pk-sr-only"> offen</span>` / `" open"`, so that the name reads
"Meine Aufgaben 3 offen" / "My tasks 3 open" (`count_open` in
`patterns.{de,en}.yaml`). States: `tones`, `count`.

## Component: dl

`dl.pk-dl`: terms and values in two columns from 640px (term column at most
14rem), stacked below; term 0.875rem in `text-muted`, value in
`--pk-color-text`. State: `default`.

## Component: menu

Actions menu "Weitere Aktionen" / "More actions" (`row_actions`) in the page
header and in table rows (interface spec 2.1, pattern 1): `details.pk-menu`
with a `summary` styled as ghost button (`class="pk-btn"
data-pk-variant="ghost" data-pk-icon-only`) holding the `ellipsis` symbol and
the name as `aria-label`; panel `ul.pk-menu-panel` on `surface-raised` with
`--pk-shadow-md`, `--pk-radius-box` and at least 12rem width, aligned to the
end of the summary. Items are `a.pk-menu-item` or `button.pk-menu-item` in a
`form method="post"` with `pk_csrf`; a destructive item carries
`data-pk-destructive` and is drawn in the error colour (it leads to the
dialog of pattern 5). The menu works without script (the browser opens and
closes `details`); `shell.js` adds Escape to close with the focus back on the
summary, the arrow keys, Home and End, and closing on a click outside or when
the focus leaves. The checker rejects a menu whose summary has no name.

In the page header (`div.pk-actions`) at most one primary button stands
beside the menu; the shell renders both from `page.primary_action` and
`page.more_actions` of the shell input (`contract/shell/shell.md`). States:
`default`, `header`.

## Component: welcome

`section.pk-welcome` with `aria-labelledby` at the top of the overview
(interface spec 2.6, 3.5, PLT-58-A5): a card on `surface-raised` with
`p.pk-welcome-progress` ("Begrüßung · Schritt <n> von <m>" / "Welcome · Step
<n> of <m>"), the title `h2`, one sentence and `div.pk-welcome-actions` with
two forms posting to the module: "Weiter" / "Next" (primary, `/welcome/next`
with the current `step`) and "Überspringen" / "Skip" (ghost, `/welcome/skip`).
Both work without script. `data-pk-welcome-step` names the step.

The element of the current step carries `data-pk-welcome-target`: the head
of a section whose heading carries the `secondary` bar of the welcome card, no
permanent outline. The module may give it `tabindex="-1"` and focus it; on
keyboard focus (`:focus-visible`) it shows the focus ring (`--pk-focus-ring`,
2px `secondary`, offset `--pk-focus-ring-offset`), never on pointer focus. Nothing moves under reduced motion. The fixed texts are in
`welcome.{de,en}.yaml`, among them the three steps of the landing page
(`landing.modules`, `landing.tasks`, `landing.settings`) and the help page
button "Begrüßung erneut zeigen" / "Show the welcome again" (`restart`). Whether
the welcome was seen is stored per person and surface in
`prefs.welcome_seen` (`papaia_kit.ui.prefs`), never in the module. States:
`step_1`, `step_2`, `step_3`, `target`, `restart`.

## Macros

Server-rendered modules write the markup above with the Jinja2 macros of
`papaia_kit/ui/templates/pk/components.html`; the React consoles use the
class constants `classes` of `@papaia/kit` (`js/src/classes.ts`, generated
from `tokens/patterns.css` by `tools/ts_classes.py`).

```python
import jinja2
from papaia_kit.ui import extend_environment

env = jinja2.Environment(loader=jinja2.FileSystemLoader("templates"), autoescape=True)
extend_environment(env)  # kit loader after the module's own, helpers pk_ui and pk_text
html = env.get_template("page.html").render(pk_lang="de", pk_csrf=csrf_token)
```

```jinja
{% import "pk/components.html" as pk with context %}
{% call pk.form(action="/reports") %}
  {{ pk.field("text", "title", "Titel", required=true, error=errors.title) }}
  {{ pk.form_actions("Speichern", cancel_href="/reports") }}
{% endcall %}
```

Rules: the macros are imported `with context`; the context holds `pk_lang`
(`de` or `en`, the language of the page, from `prefs`) and `pk_csrf` (every
form posting to the module carries it). Fixed texts come from
`../messages/` in that language. Every value is escaped (the environment
must autoescape), every argument is checked: an unknown argument raises
`TypeError`, a value outside the contract (tone, variant, symbol, link
scheme, id, a free consequence sentence, …) raises
`papaia_kit.ui.MacroError`. No macro writes a script, a `style` attribute or
an event handler (strict Content Security Policy). `extend_environment(env,
sprite=…)` points the symbols at the module's copy of `icons/sprite.svg`
(default `/_kit/<version>/icons/sprite.svg`). `pk_text(file, key, …)` gives
a fixed text in the page language for the module's own markup. Values passed
as `Markup` (for example a `{% set %}` block holding `pk.datetime(...)`) are
inserted as they are; the module answers for them. The macros are display
only: every module checks rights server-side on every request.

Golden test: `tests/fixtures/macros/<id>.html` holds, per state, the call
that renders `examples/<id>.<lang>.html` after the normalisation of
`../shell/normalize.md` (`tests/test_component_macros.py`).

| Pattern or component | Macro | Classes |
|---|---|---|
| 1 table | `table(label, columns, actions, pager)`, rows in the call block | `pk-table-scroll`, `pk-table`, `pk-num`, `pk-pager`, `pk-sr-only` |
| 2 form | `form(action)`, `field(type, name, label, …)` (text, email, search, number, date, time, select, textarea, checkbox, radio, checkbox_group, radio_group), `form_actions(submit, cancel_href)`, `error_summary(errors)`, `discard_dialog()` | `pk-form`, `pk-field`, `pk-field-error`, `pk-form-actions`, `pk-error-summary`, `pk-dialog`, `pk-dialog-actions` |
| 3 saved | `toast()` (fixed text "Gespeichert." / "Saved."), `toasts(items)` for the region `#pk-toasts` of a page without the shell | `pk-toast`, `pk-message-text`, `pk-btn` |
| 4 confirm | `confirm_dialog(integration, function, object)`, `receipt(time, reference, time_zone)`, `toast(text, undo_token=…)` | `pk-dialog`, `pk-confirm`, `pk-dialog-actions`, `pk-toast` |
| 5 destructive | `destructive_dialog(object, period)` or `destructive_dialog(count, affected, confirm_name)`, `toast(text, undo_token=…)`, `toast(tone="info", undone=true)` | `pk-dialog`, `pk-field`, `pk-dialog-actions`, `pk-toast` |
| 6 empty | `empty(text, action, symbol, compact)` | `pk-empty`, `pk-icon` |
| 7 loading | `loading(state, reference, shapes)` (`loading`, `slow`, `skeleton`, `failed`) | `pk-loading`, `pk-skeleton`, `pk-sr-only`, `pk-error` |
| 8 error | `error_message(reference, code=… or text={what, consequence, todo})`, `alert(text or stopped, tone)`, `state_page(kind, reference, module, contact, heading)` (`heading=false` inside the shell, whose page header carries the title as `h1`) | `pk-error`, `pk-alert`, `pk-message-text`, `pk-state-page` |
| 9 datetime | `datetime(value, kind, time_zone)`, `number(value, decimals)` | none (`time`, `data`, `data-pk-weekday`) |
| layout | `stack(gap)`, `cluster()`, `grid(min)` with a call block, `lead(text)` | `pk-stack`, `pk-cluster`, `pk-grid`, `pk-lead` |
| section | `section(title, id, count, action, description)`, content in an optional call block | `pk-section-head`, `pk-section-count`, `pk-section-description` |
| card | `card(title, id, action, href, foot, unavailable, highlight)`, body in an optional call block | `pk-card`, `pk-card-head`, `pk-card-body`, `pk-card-foot`, `pk-card-link`, `pk-card-status` |
| tile | `tiles(items)`, one `tile(state, name, symbol, href, new_tab, purpose, example, contact)` per item | `pk-tiles`, `pk-tile`, `pk-tile-*` |
| list | `list(label, density)` with `list_row(primary, href, symbol, meta, trail)` in the call block | `pk-list`, `pk-list-row`, `pk-list-symbol`, `pk-list-body`, `pk-list-primary`, `pk-list-meta`, `pk-list-link`, `pk-list-trail` |
| badge | `badge(text, tone, symbol)`, `count(value)` | `pk-badge`, `pk-count`, `pk-sr-only` |
| dl | `dl(items)` with (term, value) pairs | `pk-dl` |
| menu | `menu(items, primary, label, open)` (`open=true` only for reference pages) | `pk-menu`, `pk-menu-panel`, `pk-menu-item`, `pk-actions`, `pk-btn` |
| welcome | `welcome(step, total, title, text, id)`, `welcome_target(title, id)` with a call block, `welcome_restart(action)` | `pk-welcome`, `pk-welcome-progress`, `pk-welcome-actions` |

Building blocks used by all of them: `button(label, variant, size, symbol,
href, type, disabled, reason, id, icon_only, autofocus, name, value)` (a
disabled button names its reason, linked by `aria-describedby`) and
`icon(name, size, spin)`.

`field`: the label carries "(Pflicht)" / "(required)" for a required field,
the control `required` and `aria-required="true"`; hint and error are `<p
id>` linked by `aria-describedby` (error first), an error also sets
`aria-invalid="true"`. Checkbox and radio groups sit in a `fieldset` with a
`legend`; a required radio group is a `radiogroup` with `aria-required`,
a required checkbox group shows "(Pflicht)" in its legend and is checked by
the module on submit (`required` on each box would require all of them).
