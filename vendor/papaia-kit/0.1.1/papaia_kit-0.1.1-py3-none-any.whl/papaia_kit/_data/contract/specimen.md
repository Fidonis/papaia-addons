# Specimen page and UI conformance (K5)

Every module and the manager serve `/_kit/specimen`: one page, for signed-in
persons only, without data, built with the module's real components. The kit
checks it in the module's CI with `pk-conform` (browser check) and `pk-audit`
(accessibility baseline). This file is normative; the data lives in
`specimen.yaml` (elements and properties, pinned tools, viewports) and in the
generated `specimen-expected.<theme>.json`.

## Required elements

Every element of `specimen.yaml` carries `data-pk-specimen="<name>"`, exactly
once, except `heading-1`, which is the page's only `h1` in `page-header`, and
the elements whose selector starts with the hook of another element: the kit's
macros write no hooks, so a section carries the hook and the component inside
it is found by an attribute or class selector (for example
`[data-pk-specimen="tiles"] [data-pk-state="no_access"]`). The page has
sections for:

- buttons primary, secondary, danger and ghost at rest, primary, secondary and
  danger under the pointer (`-hover`), primary with keyboard focus, primary
  and secondary disabled, small (`button-small`) and symbol-only
  (`button-icon-only`);
- every control type (`input`, `select`, `textarea`, `checkbox`, `radio`) in
  the states rest, hover, focus, disabled and invalid (`<control>-<state>`;
  the invalid text field keeps its name `input-error`);
- base elements: headings 1 to 3, body text, link, bullet list, `code`,
  date/time (pattern 9, the values of PLT-76-A8) and number;
- layout (stack, cluster, grid, lead), cards (plain and linked) and module
  tiles in the three states open, no access and stopped;
- list rows, badges (`badge`, `badge-error`), count, description list and the
  actions menu open (`menu-open`, `menu-item`);
- toasts in the four tones and with undo (`toast-undo`), alerts in the four
  tones, empty, loading and skeleton state, error message (pattern 8);
- table head and body cell; the closed dialog (`dialog`); the confirmation
  and the destructive dialog drawn open in place (`dialog-confirm`,
  `dialog-destructive`); the welcome.

A page may carry more elements of its own; `pk-conform` reports every unknown
`data-pk-specimen` name.

## Composed reference pages

`contract/examples/pages/{overview,settings,list,state,data}.{de,en}.html` show how
a real page of a module looks: rendered only from the macros of
`pk/components.html`, in the shell of the reference input with the test
branding, module Mein Bereich, synthetic data.

| Page | Content |
|---|---|
| `overview` | module tiles in the three states, task list with count and due weekday, group cards |
| `settings` | error summary, fieldsets, checkbox and radio groups, select, an ordered choice with up and down buttons, form actions |
| `list` | lead, table with an actions menu per row and a pager; one primary action and the menu in `page-header` |
| `state` | not found (the page header carries the title), empty state with one action |
| `data` | what the modules keep about a person: lead, export button, module cards in a grid with one description list per category (whole sentences as values), one module unreachable |

`papaia-kit specimen page --page <name> [--lang de|en] [--theme light|dark]`
prints one page; `papaia-kit specimen pages` writes the files and `--check`
names every file that differs (part of `make check`). The pages pass the
design checks of `design-review.md` in both themes and widths; they are the
visual target of a module pull request.

The kit's reference content is `papaia_kit.ui.specimen.specimen_body(lang)`;
Jinja2 modules mount it inside their shell unchanged. React consoles render
their own components with the same hooks. `papaia-kit specimen page --module
<id>` prints the whole reference document with the test branding.

## Read properties

`background-color`, `color`, `border-top-color`, `font-family`, `font-size`,
`font-weight`, `line-height`, `border-top-left-radius`, `padding-top`,
`padding-left`, `opacity`, and for elements in state `focus` the outline
(`outline-color`, `outline-style`, `outline-width`, `outline-offset`). Each
element lists the properties it is checked on; an empty list checks presence
only. Elements in state `focus` are focused before reading, elements in state
`hover` are read under the pointer (one at a time, pointer and focus removed
afterwards), elements in state `invalid` carry `aria-invalid="true"` and are
read at rest, and every transition has ended before any value is read.

Besides the elements, `pk-conform` reads every `--pk-*` custom property of
`:root` and compares it with the token file.

## Comparison rule

- Colours are converted to sRGB with 8 bits per channel and alpha in two
  decimals (`rgb()`, `rgba()`, hex, `color(srgb …)`, `oklab()`, `oklch()`);
  equal means each channel differs by at most 1 and the alpha is the same.
- Lengths in CSS pixels (`rem` at 16 px), rounded to 0.5 px, equal.
- Font family: the first family name without quotes, case-insensitive.
- Weight as a number (`normal` 400, `bold` 700).
- Other values (keywords, custom properties that are neither colour nor
  length) compare as text with collapsed whitespace.

The Python side writes the expected values with this rule
(`papaia-kit specimen expected`); `pk-conform` normalises what the browser
reports with the same rule (one implementation for all surfaces).

## Structure checks

On the specimen page at 1280 × 800: the first focusable element is the skip
link `a.pk-skip` to the content; exactly one `main`; every `nav` has an
accessible name; exactly one `h1` and no skipped heading level; `lang` is the
person's language; the title reads `<page> – <module> – <installation>`; the
zones `brand`, `switcher`, `nav`, `footer`, `page-header` occur once each and
in this order; the sidebar is 256 ± 1 px wide; `brand`, `switcher` and
`footer` start at 0 ± 1 px; at most one primary action in `page-header`;
`<meta name="papaia-kit">` equals the kit version (the version of the
`pk-conform` package; the expected files carry no kit version, so a release
cut does not change them). At 320 × 640 the page does
not scroll horizontally (`scrollWidth ≤ innerWidth`; table containers scroll
on their own).

## Reference images

Shots: zone `brand`; `switcher` closed and open; `footer`; account menu open;
both themes; the current module's name masked. Path:
`refimg/<playwright-version>/<os>-<arch>/<module>/<shot>-<theme>.png`, only for
`linux-arm64` and `linux-amd64` (pinned Playwright container), compared only
within the same platform. A pixel differs when its YIQ distance exceeds 0.1 and
it is not an anti-aliased edge pixel; a shot matches when at most 0.5 % of its
pixels differ.

Whole pages: the specimen page and the five composed pages in German, at
1440 × 900 and 390 × 844 (`desktop`, `phone`), both themes, full page, in the
shell of module Mein Bereich. Path:
`refimg/<playwright-version>/<os>-<arch>/pages/<page>-<viewport>-<theme>.png`.
`make shots` renders the same images into the untracked folder `shots/` for a
local review; they are never reference images.

Reference images are made only in a kit release, from the reference specimen
page with the test branding of `shell/inputs/branding/` (`make refimg
TAG=vX.Y.Z` in the container of each platform), ship as the release file
`papaia-kit-refimg-<version>.tar.gz` (unpacked into the folder given to
`--kit-dir`), and change only with a diff report in the changelog. Module repositories keep no reference images. Without
a reference set for the platform the shots are reported as not checked and
`pk-conform` ends with exit code 3, never as passed.

## Accessibility baseline

`pk-audit` runs axe-core in the exact version of `specimen.yaml` (`tools`)
with the tags `wcag2a`, `wcag2aa`, `wcag21a`, `wcag21aa`; `wcag22aa` runs as
report only. Every page given with `--page` (the pages of the module's page
list reachable without neighbours) is checked in both themes, at rest, with
every menu (`details`) open and with the first dialog open, where the page has
one. Passed: no violation of impact `critical` or `serious`; every other
violation stands in the module's `a11y-known.yaml`:

```yaml
- rule: region
  page: /help
  ticket: "papaia-me#41"
  reason: Help text outside a landmark until the help layout is reworked.
```

The list holds flat entries with exactly these four fields, plain or
double-quoted values and comments on their own lines; anything else is
refused. Entries no run needs are named as stale.

## Pinned tools

Playwright (`playwright-core`) and axe-core are pinned in `specimen.yaml` and
in `js/package.json` (development and peer dependency, same version); a test
keeps both equal. `pk-conform` refuses another Playwright version and
`pk-audit` another axe-core version.
