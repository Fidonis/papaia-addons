# Contract schemas

This directory holds the machine-readable contract of the papaia platform. Every
module, add-on and server validates against these files; none keeps its own copy.

| Schema | Format | File it describes | Description |
|---|---|---|---|
| `platform-services.v1.schema.json` | `papaia.platform-services/1` | `platform/services.json` (catalog) | `contract/platform-services.md` |
| `platform-groups.v1.schema.json` | `papaia.platform-groups/1` | `platform/groups.json` (group list) | `contract/platform-services.md` |
| `me-contract.v2.schema.json` | personal-area contract, generation 2 | manifest key `personal_settings:` with `api: 2` and the bodies of the module API | `contract/me-contract.md` |

Rules for every schema file:

- JSON Schema draft 2020-12, one schema per file.
- File name `<name>.v<major>.schema.json`; the `$id` ends with the same file name.
- Unknown properties are rejected (`"additionalProperties": false` or
  `"unevaluatedProperties": false`) unless the schema states why not.
- Every `$` anchor in a `pattern` is written `$(?!\n)`: Python's `re` lets a bare
  `$` match before a trailing line break, ECMA-262 does not.
- A breaking change creates a new major file next to the old one; the old file
  stays until no released consumer reads it.
- A `pattern` that ends with `$` is written `$(?!\n)`: some validators let `$`
  match before a final line break, so a value with a trailing newline would pass.
  `exposes.v1` and `healthz.v1` use the stricter `$(?![\s\S])`.
- The top-level keyword `x-papaia-schema-version` carries the full version
  (Semantic Versioning, major equal to the file name); every change gets an
  entry in `CHANGELOG.md`.

## Files

| File | Content |
|---|---|
| `data-classes.json` | The one data class scale (`papaia.data-classes/1`): eight classes, least sensitive first, with titles and definitions in German and English, plus the mapping tables of the five-level scale (Me contract v1) and of Studio. A data file, not a schema; see `../contract/data-classes.md`. |
| `inventory.v1.schema.json` | Inventory of work objects (`papaia.inventory/1`), served by every module at `GET /internal/inventory`; see `../contract/inventory.md`. |
| `exposes.v1.schema.json` | Manifest section `exposes:` of add-ons and core profiles; see `../contract/exposes.md`. |
| `healthz.v1.schema.json` | Response of `/healthz` of every module; see `../contract/exposes.md`, section Health. |
| `audit.v1.schema.json` | Audit event (`papaia.audit/1`); `#/$defs/submission` is the form a source writes, the root is the stored and exported form; see `../contract/audit.md`. |
| `injection-corpus.v1.schema.json` | One file of the corpus of injected instructions (`papaia.injection-corpus/1`), kit cases in `../testing/injection/`; see `../contract/conformance.md`, section injection. |
| `task-item.v1.schema.json` | Task item (`papaia.task-item/1`) of "Meine Aufgaben"; `#/$defs/list` and `#/$defs/summary` are the bodies of `GET /api/v1/me/tasks` and `/summary`; see `../contract/tasks.md`. |
| `recording.v1.schema.json` | Recording of a provider suite (`papaia.conformance-recording/1`): request and response pairs, schema version, provider image digest; see `../contract/conformance.md`. |

The Python package exposes this directory as `papaia_kit.schemas_dir()`; the
wheel carries a copy under `papaia_kit/_data/schemas`.
