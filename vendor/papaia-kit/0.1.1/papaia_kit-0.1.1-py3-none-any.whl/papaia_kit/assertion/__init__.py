"""Module context assertion (architecture V-11): which app, run, step or analysis called.

A module (Studio, Flow, Data, the assistant) sends with each call to a server
the header ``X-Papaia-Module-Context``: a compact JWS (ES256) over ``iss``
(module client), ``sub``, ``aud`` (target audience), ``ctx`` (module, kind,
id, version), ``ath`` (hash of the access token sent alongside), ``iat``,
``exp`` (at most 60 s later) and a single-use ``jti``. ``ModuleContextSigner``
builds it, ``ModuleContextVerifier`` checks it in the fixed order of
``contract/assertion.md``, ``ContextGuard`` applies the server mode ``off``,
``log`` or ``enforce``. The assertion grants nothing; rights come from the
token alone.
"""

from papaia_kit.assertion._guard import (
    DENIED_CODE,
    DENIED_STATUS,
    MODE_VARIABLE,
    ContextDenied,
    ContextGuard,
    ContextOutcome,
    Mode,
)
from papaia_kit.assertion._token import (
    ASSERTION_TYPE,
    HEADER,
    LEEWAY_SECONDS,
    MAX_ASSERTION_LENGTH,
    MAX_LIFETIME_SECONDS,
    REPLAY_TTL_SECONDS,
    Code,
    ContextInvalid,
    Kind,
    LruReplayCache,
    ModuleContext,
    ModuleContextSigner,
    ModuleContextVerifier,
    ReplayCache,
    access_token_hash,
    vectors_path,
)

__all__ = [
    "ASSERTION_TYPE",
    "DENIED_CODE",
    "DENIED_STATUS",
    "HEADER",
    "LEEWAY_SECONDS",
    "MAX_ASSERTION_LENGTH",
    "MAX_LIFETIME_SECONDS",
    "MODE_VARIABLE",
    "REPLAY_TTL_SECONDS",
    "Code",
    "ContextDenied",
    "ContextGuard",
    "ContextInvalid",
    "ContextOutcome",
    "Kind",
    "LruReplayCache",
    "Mode",
    "ModuleContext",
    "ModuleContextSigner",
    "ModuleContextVerifier",
    "ReplayCache",
    "access_token_hash",
    "vectors_path",
]
