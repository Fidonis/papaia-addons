"""The source's audit outbox: tables, statements and the ingest wire format.

Everything here is free of I/O so that the sync and the async writer share one
implementation of the rules in ``contract/audit.md`` ("Writer and ingest").
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal

from papaia_kit.audit import AuditEventError, validate_event

Dialect = Literal["sqlite", "postgres"]

# Rows per ingest call (governance GV-01).
MAX_BATCH = 500
# An acknowledgement of 500 rows is about 20 KiB; anything far larger is not one.
MAX_ACK_BYTES = 256 * 1024

# Fields the writer (source_seq) or papaia-audit (source, seq, prev_hash, hash)
# assign. validate_event rejects the latter for a submission; source_seq is
# refused here so that a caller cannot pick its own counter value.
_ASSIGNED = ("source_seq",)

__all__ = [
    "MAX_ACK_BYTES",
    "MAX_BATCH",
    "AckError",
    "Dialect",
    "OutboxError",
    "OutboxStatus",
    "OutboxStatements",
    "check_row",
    "encode_batch",
    "outbox_ddl",
    "parse_ack",
    "prepare_row",
]


class OutboxError(RuntimeError):
    """The outbox is missing or holds a row that cannot be delivered."""


class AckError(ValueError):
    """The ingest response is not a valid acknowledgement of the batch."""


@dataclass(frozen=True)
class OutboxStatus:
    """Rows waiting for delivery and the source time of the oldest one."""

    depth: int
    oldest_time: str | None


_DDL: dict[str, tuple[str, ...]] = {
    "sqlite": (
        "CREATE TABLE IF NOT EXISTS audit_outbox_state ("
        " id INTEGER PRIMARY KEY CHECK (id = 1),"
        " last_source_seq INTEGER NOT NULL CHECK (last_source_seq >= 0))",
        "INSERT INTO audit_outbox_state (id, last_source_seq) VALUES (1, 0)"
        " ON CONFLICT (id) DO NOTHING",
        "CREATE TABLE IF NOT EXISTS audit_outbox ("
        " source_seq INTEGER PRIMARY KEY CHECK (source_seq >= 1),"
        " created_at TEXT NOT NULL,"
        " body TEXT NOT NULL)",
    ),
    "postgres": (
        "CREATE TABLE IF NOT EXISTS audit_outbox_state ("
        " id smallint PRIMARY KEY CHECK (id = 1),"
        " last_source_seq bigint NOT NULL CHECK (last_source_seq >= 0))",
        "INSERT INTO audit_outbox_state (id, last_source_seq) VALUES (1, 0)"
        " ON CONFLICT (id) DO NOTHING",
        "CREATE TABLE IF NOT EXISTS audit_outbox ("
        " source_seq bigint PRIMARY KEY CHECK (source_seq >= 1),"
        " created_at text NOT NULL,"
        " body text NOT NULL)",
    ),
}


def outbox_ddl(dialect: Dialect) -> tuple[str, ...]:
    """Statements that create the outbox tables; safe to run on every start."""
    if dialect not in _DDL:
        raise ValueError(f"unknown dialect {dialect!r}; expected 'sqlite' or 'postgres'")
    return _DDL[dialect]


@dataclass(frozen=True)
class OutboxStatements:
    """The writer's statements in the parameter style of one dialect."""

    next_seq: str
    insert: str
    select_batch: str
    delete: str
    status: str

    @classmethod
    def for_dialect(cls, dialect: Dialect) -> OutboxStatements:
        outbox_ddl(dialect)
        # Statements are fixed text; only the placeholder differs (qmark for
        # sqlite3, format for psycopg). Values always travel as parameters.
        mark = "?" if dialect == "sqlite" else "%s"
        return cls(
            # One row holds the counter. Updating it locks the row until the
            # caller's transaction ends, so numbers are gapless (a rollback
            # returns its number) and commit in counter order: delivery never
            # sees a later row before an earlier one.
            next_seq="UPDATE audit_outbox_state SET last_source_seq = last_source_seq + 1"
            " WHERE id = 1 RETURNING last_source_seq",
            insert="INSERT INTO audit_outbox (source_seq, created_at, body)"
            " VALUES (?, ?, ?)".replace("?", mark),
            select_batch="SELECT source_seq, body FROM audit_outbox"
            " ORDER BY source_seq LIMIT ?".replace("?", mark),
            delete="DELETE FROM audit_outbox WHERE source_seq = ?".replace("?", mark),
            status="SELECT COUNT(*), MIN(created_at) FROM audit_outbox",
        )


def prepare_row(event: Mapping[str, Any], source_seq: int) -> tuple[str, str]:
    """Validate ``event`` with its ``source_seq``; return ``(time, body)`` for the outbox.

    Raises :class:`AuditEventError` naming fields, never values.
    """
    if not isinstance(event, Mapping):
        raise AuditEventError(["$: not a JSON object"])
    for field in _ASSIGNED:
        if field in event:
            raise AuditEventError([f"$.{field}: assigned by the writer"])
    row = {**event, "source_seq": source_seq}
    validate_event(row, stage="submission")
    body = json.dumps(row, allow_nan=False, ensure_ascii=False, separators=(",", ":"))
    return str(row["time"]), body


def check_row(source_seq: object, body: object) -> None:
    """Refuse an outbox row whose body does not belong to its key."""
    if not isinstance(source_seq, int) or isinstance(source_seq, bool) or source_seq < 1:
        raise OutboxError("outbox row with an invalid source_seq")
    if not isinstance(body, str):
        raise OutboxError(f"outbox row {source_seq}: body is not text")
    try:
        row = json.loads(body)
    except ValueError:
        raise OutboxError(f"outbox row {source_seq}: body is not JSON") from None
    if not isinstance(row, dict) or row.get("source_seq") != source_seq:
        raise OutboxError(f"outbox row {source_seq}: body does not match its source_seq")


def encode_batch(bodies: Sequence[str]) -> bytes:
    """JSON lines, one compact event per line, in the order given."""
    if not 1 <= len(bodies) <= MAX_BATCH:
        raise ValueError(f"a batch holds 1 to {MAX_BATCH} rows")
    return "".join(body + "\n" for body in bodies).encode("utf-8")


def _reject_constant(name: str) -> object:
    raise ValueError(f"non-standard JSON constant {name}")


def parse_ack(raw: bytes, sent: Sequence[int]) -> dict[int, int]:
    """Map ``source_seq`` to the ``seq`` papaia-audit assigned, for rows of this batch.

    The response is ``{"acknowledged": [{"source_seq": n, "seq": m}, ...]}``.
    papaia-audit stores a batch in order and stops at the first row it does not
    store, so the entries must be the leading rows of ``sent``, in that order,
    with strictly rising ``seq``. Anything else raises :class:`AckError`, and
    the writer deletes nothing: deleting a later row while an earlier one stays
    would let the later row overtake it in the store. Messages never repeat the
    response.
    """
    if len(raw) > MAX_ACK_BYTES:
        raise AckError("acknowledgement too large")
    try:
        data = json.loads(raw.decode("utf-8"), parse_constant=_reject_constant)
    except (UnicodeDecodeError, ValueError):
        raise AckError("acknowledgement is not JSON") from None
    if not isinstance(data, dict) or set(data) != {"acknowledged"}:
        raise AckError("acknowledgement must be an object with only 'acknowledged'")
    entries = data["acknowledged"]
    if not isinstance(entries, list) or len(entries) > len(sent):
        raise AckError("'acknowledged' must be a list no longer than the batch")
    acknowledged: dict[int, int] = {}
    last_seq = 0
    for expected, entry in zip(sent, entries, strict=False):
        if not isinstance(entry, dict) or set(entry) != {"source_seq", "seq"}:
            raise AckError("acknowledgement entry must hold exactly source_seq and seq")
        source_seq, seq = entry["source_seq"], entry["seq"]
        if not (_positive_int(source_seq) and _positive_int(seq)):
            raise AckError("acknowledgement entry with a non-positive or non-integer value")
        if source_seq != expected:
            raise AckError("acknowledgement is not the leading rows of the batch in order")
        if seq <= last_seq:
            raise AckError("acknowledgement seq does not rise with source_seq")
        acknowledged[source_seq] = seq
        last_seq = seq
    return acknowledged


def _positive_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 1
