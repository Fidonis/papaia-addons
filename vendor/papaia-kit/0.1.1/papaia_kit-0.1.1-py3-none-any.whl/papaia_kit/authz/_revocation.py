"""Revocation list ``revocations.json`` (security 1.12 Nr. 3, RE-102).

``{seq, issued_at, global_since?, entries: [{sub, since, reason}]}``. Times are
NumericDate values (seconds since the epoch, as ``iat`` in the token). A token
with ``iat < global_since`` is refused for everyone; a token of a listed
``sub`` with ``iat < since`` is refused for that person. Both give
``identity_revoked``.

This module parses an already loaded document. Reading the file from the
``papaia-security-state`` volume, checking its Ed25519 signature and reloading
it every 15 s belong to the loader that hands the list to the chain (not part
of the kit yet). ``RevocationStatus`` tells doctor whether step 5 runs and how
old the list is (``revocations_age_seconds``).
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import StrEnum
from types import MappingProxyType

MAX_ENTRIES = 100_000
MAX_SUB_LENGTH = 255
MAX_REASON_LENGTH = 64
_REQUIRED = {"seq", "issued_at", "entries"}
_OPTIONAL = {"global_since"}
_ENTRY = {"sub", "since", "reason"}


def _numeric(value: object, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer of at least {minimum}")
    return value


def _sub(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value
        or len(value) > MAX_SUB_LENGTH
        or not value.isprintable()
        or value != value.strip()
    ):
        raise ValueError("revocation entry 'sub' is malformed")
    return value


def _reason(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value
        or len(value) > MAX_REASON_LENGTH
        or not all(char.isascii() and (char.isalnum() or char in "_-") for char in value)
    ):
        raise ValueError("revocation entry 'reason' is malformed")
    return value


@dataclass(frozen=True)
class RevocationList:
    seq: int
    issued_at: int
    global_since: int | None
    entries: Mapping[str, int]

    @classmethod
    def from_dict(cls, data: object) -> RevocationList:
        if not isinstance(data, Mapping):
            raise ValueError("revocation list must be an object")
        keys = set(data)
        if not keys >= _REQUIRED or keys - _REQUIRED - _OPTIONAL:
            raise ValueError("revocation list has unknown or missing fields")
        seq = _numeric(data["seq"], "seq", minimum=1)
        issued_at = _numeric(data["issued_at"], "issued_at")
        global_since = data.get("global_since")
        if global_since is not None:
            global_since = _numeric(global_since, "global_since")
        raw_entries = data["entries"]
        if not isinstance(raw_entries, list) or len(raw_entries) > MAX_ENTRIES:
            raise ValueError("revocation list 'entries' must be a list")
        entries: dict[str, int] = {}
        for raw in raw_entries:
            if not isinstance(raw, Mapping) or set(raw) != _ENTRY:
                raise ValueError("revocation entry needs exactly 'sub', 'since', 'reason'")
            sub = _sub(raw["sub"])
            since = _numeric(raw["since"], "since")
            _reason(raw["reason"])
            entries[sub] = max(since, entries.get(sub, since))
        return cls(seq, issued_at, global_since, MappingProxyType(entries))

    def revoked(self, sub: str, issued_at: int) -> bool:
        """True when a token of ``sub`` issued at ``issued_at`` must be refused."""
        if self.global_since is not None and issued_at < self.global_since:
            return True
        since = self.entries.get(sub)
        return since is not None and issued_at < since


class RevocationState(StrEnum):
    """Whether step 5 of the chain runs."""

    DISABLED = "disabled"  # the server passed revocations=None: step 5 never runs
    NOT_LOADED = "not_loaded"  # the source has no list yet: step 5 is skipped
    LOADED = "loaded"  # step 5 runs against the list


@dataclass(frozen=True)
class RevocationStatus:
    """State of the revocation list as the chain sees it, for doctor."""

    state: RevocationState
    seq: int | None = None
    issued_at: int | None = None
    age_seconds: float | None = None
