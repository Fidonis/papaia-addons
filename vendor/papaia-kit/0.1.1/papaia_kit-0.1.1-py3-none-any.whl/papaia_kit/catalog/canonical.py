"""JSON Canonicalization Scheme (RFC 8785) and the catalog entry hash.

``content_hash`` of a catalog entry is ``sha256:`` plus the SHA-256 of the
canonical form of the entry without its ``content_hash`` field (architecture
V-02 rule 3). The canonical form is defined by RFC 8785: object members sorted
by the UTF-16 code units of their names, no whitespace, strings escaped only
where JSON requires it, numbers written as ECMAScript writes a double.

Values outside I-JSON (RFC 7493) have no canonical form and raise
``ValueError``: NaN, infinities, integers a double cannot hold exactly, strings
with lone surrogates and non-string object keys.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from decimal import Decimal
from typing import Any

__all__ = ["HASH_FIELD", "canonical_json", "content_hash"]

HASH_FIELD = "content_hash"

# Largest integer magnitude a double represents exactly (2**53).
_EXACT_INT = 2**53
# ECMAScript Number::toString switches to exponent form above 21 integer digits.
_MAX_PLAIN_DIGITS = 21
# ... and below 1e-6.
_MIN_PLAIN_EXPONENT = -6


def canonical_json(value: Any) -> bytes:
    """The RFC 8785 canonical form of ``value`` as UTF-8 bytes."""
    parts: list[str] = []
    _write(value, parts)
    try:
        return "".join(parts).encode("utf-8")
    except UnicodeEncodeError as exc:
        raise ValueError("string with a lone surrogate has no canonical form") from exc


def content_hash(entry: Mapping[str, Any]) -> str:
    """``sha256:<hex>`` over the canonical form of ``entry`` without ``content_hash``."""
    if not isinstance(entry, Mapping):
        raise TypeError("a catalog entry is an object")
    body = {key: value for key, value in entry.items() if key != HASH_FIELD}
    return "sha256:" + hashlib.sha256(canonical_json(body)).hexdigest()


def _write(value: Any, out: list[str]) -> None:
    # bool before int: bool is a subclass of int.
    if value is None:
        out.append("null")
    elif value is True:
        out.append("true")
    elif value is False:
        out.append("false")
    elif isinstance(value, int):
        out.append(_integer(value))
    elif isinstance(value, float):
        out.append(_double(value))
    elif isinstance(value, str):
        out.append(_string(value))
    elif isinstance(value, Mapping):
        _object(value, out)
    elif isinstance(value, Sequence) and not isinstance(value, bytes | bytearray):
        out.append("[")
        for index, item in enumerate(value):
            if index:
                out.append(",")
            _write(item, out)
        out.append("]")
    else:
        raise ValueError(f"{type(value).__name__} has no JSON form")


def _object(value: Mapping[Any, Any], out: list[str]) -> None:
    keys = list(value)
    if not all(isinstance(key, str) for key in keys):
        raise ValueError("object keys must be strings")
    # Sorting the UTF-16BE encoding byte-wise equals sorting by UTF-16 code units.
    keys.sort(key=lambda key: key.encode("utf-16-be", "surrogatepass"))
    out.append("{")
    for index, key in enumerate(keys):
        if index:
            out.append(",")
        out.append(_string(key))
        out.append(":")
        _write(value[key], out)
    out.append("}")


def _string(value: str) -> str:
    # json.dumps with ensure_ascii=False escapes exactly what RFC 8785 escapes:
    # quote, backslash, \b \t \n \f \r and the other controls as lower-case \u00xx.
    return json.dumps(value, ensure_ascii=False)


def _integer(value: int) -> str:
    if abs(value) <= _EXACT_INT:
        return str(value)
    as_double = float(value)
    if int(as_double) != value:
        raise ValueError("integer outside the exact range of a double")
    return _double(as_double)


def _double(value: float) -> str:
    """ECMAScript Number::toString of ``value`` (ECMA-262, 7.1.12.1)."""
    if not math.isfinite(value):
        raise ValueError("NaN and infinities have no JSON form")
    if value == 0:
        return "0"  # also for -0
    sign = "-" if value < 0 else ""
    # repr gives the shortest digit string that round-trips, as ECMAScript requires.
    _, digit_tuple, exponent = Decimal(repr(abs(value))).as_tuple()
    if not isinstance(exponent, int):  # only for NaN and infinities, excluded above
        raise ValueError("NaN and infinities have no JSON form")
    all_digits = "".join(str(d) for d in digit_tuple)
    digits = all_digits.rstrip("0")
    exponent += len(all_digits) - len(digits)
    k = len(digits)
    n = exponent + k  # position of the decimal point relative to the digits
    if k <= n <= _MAX_PLAIN_DIGITS:
        text = digits + "0" * (n - k)
    elif 0 < n <= _MAX_PLAIN_DIGITS:
        text = digits[:n] + "." + digits[n:]
    elif _MIN_PLAIN_EXPONENT < n <= 0:
        text = "0." + "0" * -n + digits
    else:
        e = n - 1
        mantissa = digits[0] + ("." + digits[1:] if k > 1 else "")
        text = f"{mantissa}e{'+' if e >= 0 else '-'}{abs(e)}"
    return sign + text
