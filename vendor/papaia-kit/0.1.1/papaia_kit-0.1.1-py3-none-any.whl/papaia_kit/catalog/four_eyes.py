"""The four-eyes setting of the platform, as the core publishes it in the catalog.

One installation setting ``approvals.four_eyes`` (``on``/``off``) decides for
every module whether an approval needs a second person (E-18). Security
profile ``kritis`` is always ``on``; in every other profile the default is
``off`` and the administration may switch it on, then for all modules. No
module keeps a setting of its own, and no rule depends on the size profile or
on the number of administrators. See ``contract/platform-services.md``
section 2.7.

The helpers fail closed: a missing catalog, an object that is not a catalog
checked by :func:`papaia_kit.catalog.parse_services`, an unknown profile or
any value other than exactly ``off`` count as ``on``. They decide the person
rule only; whether the approver holds the reviewer or confirmation role is
the module's server-side rights check.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Final, Literal

from papaia_kit.catalog.document import Catalog

__all__ = [
    "FOUR_EYES_DEFAULT",
    "SELF_APPROVAL_FLAG",
    "SELF_REVIEW_CODE",
    "FourEyes",
    "ReviewDecision",
    "four_eyes_required",
    "four_eyes_setting",
    "review_decision",
]

FourEyes = Literal["on", "off"]

FOUR_EYES_DEFAULT: Final[FourEyes] = "off"
"""Value of ``approvals.four_eyes`` when the catalog states none (never in ``kritis``)."""

SELF_APPROVAL_FLAG: Final = "selbstfreigabe"
"""``detail`` field of the audit row of an approval by the submitter while the setting is off."""

SELF_REVIEW_CODE: Final = "PK-REVIEW-SELF"
"""Error code of a refused approval by the submitter; used only while four eyes are on."""

# Longest subject the audit schema accepts (papaia.audit/1 #/$defs/subject).
_MAX_PERSON = 255
_PROFILES_WITH_SETTING: Final = frozenset({"standard"})


def four_eyes_setting(catalog: Catalog | None) -> FourEyes:
    """Value in effect for the installation: ``on`` in ``kritis`` and whenever in doubt."""
    if not isinstance(catalog, Catalog):
        return "on"
    data = catalog.data
    profile = data.get("security_profile", "standard")
    if profile not in _PROFILES_WITH_SETTING:
        return "on"
    approvals = data.get("approvals", {})
    if not isinstance(approvals, Mapping):
        return "on"
    value = approvals.get("four_eyes", FOUR_EYES_DEFAULT)
    # Compare by type as well: a str subclass or a look-alike must not pass as "off".
    return "off" if type(value) is str and value == "off" else "on"


def four_eyes_required(catalog: Catalog | None) -> bool:
    """``True`` when an approval needs a second person (profile ``kritis`` or setting ``on``)."""
    return four_eyes_setting(catalog) == "on"


@dataclass(frozen=True, slots=True)
class ReviewDecision:
    """Outcome of the person rule for one approval.

    ``allowed`` is ``False`` only for an approval by the submitter while four
    eyes are on; the module then answers with ``error_code``
    (``PK-REVIEW-SELF`` or its module alias). ``audit_detail`` is merged into
    the ``detail`` of the approval's audit row.
    """

    allowed: bool
    self_approval: bool
    error_code: str | None
    audit_detail: Mapping[str, bool] = field(
        default_factory=lambda: MappingProxyType({}), compare=False
    )


def review_decision(catalog: Catalog | None, *, submitter: str, approver: str) -> ReviewDecision:
    """Apply the four-eyes rule to an approval of ``submitter``'s object by ``approver``.

    ``submitter`` and ``approver`` are the ``sub`` values of both persons as
    the module took them from the verified tokens. Raises :class:`ValueError`
    for a value that is not a non-empty string of at most 255 characters.
    """
    _check_person(submitter, "submitter")
    _check_person(approver, "approver")
    if submitter != approver:
        return ReviewDecision(allowed=True, self_approval=False, error_code=None)
    if four_eyes_required(catalog):
        return ReviewDecision(allowed=False, self_approval=False, error_code=SELF_REVIEW_CODE)
    return ReviewDecision(
        allowed=True,
        self_approval=True,
        error_code=None,
        audit_detail=MappingProxyType({SELF_APPROVAL_FLAG: True}),
    )


def _check_person(value: object, name: str) -> None:
    if type(value) is not str or not 1 <= len(value) <= _MAX_PERSON:
        raise ValueError(f"{name} must be a non-empty string of at most {_MAX_PERSON} characters")
