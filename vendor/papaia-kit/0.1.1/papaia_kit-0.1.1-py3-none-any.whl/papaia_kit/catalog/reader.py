"""Read the mounted catalog files with last-good fallback and change detection.

Consumer rules (architecture V-02, contract/platform-services.md section 4):

- A missing file before the first valid read is normal operation without a
  catalog (a module running stand-alone): no error, ``status.absent`` is true and
  the reader logs it once at INFO.
- An invalid, unreadable or vanished file keeps the last valid state in use; the
  error is logged once per distinct failure and kept in :attr:`Reader.status`
  for ``doctor``. Any exception from the check counts as invalid, so a defect
  in the check can never take the last valid state away.
- New entries are reported as ``added`` ("offered", never active), entries
  whose ``content_hash`` changed as ``changed`` (approvals bound to the old hash
  rest), vanished entries as ``removed`` (class ``upstream_unavailable``, cause
  "connection removed"); see :mod:`papaia_kit.catalog.approval`.
- :meth:`Reader.get` checks the file at most every 30 s (``max_age``) and only
  reads it again when its size, modification time or inode changed, so a change
  reaches every module within 60 s.

The reader never writes the files; they are mounted read-only.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from papaia_kit.catalog.document import (
    MAX_BYTES,
    Catalog,
    CatalogError,
    GroupList,
    parse_groups,
    parse_services,
)

__all__ = [
    "INTERNAL_CHECK_ERROR",
    "MAX_AGE_SECONDS",
    "Changes",
    "GroupsReader",
    "Reader",
    "ReaderStatus",
    "ServicesReader",
    "diff",
]

# Longest time a module serves a cached catalog without looking at the file.
MAX_AGE_SECONDS = 30.0
# Status error for an exception the check did not expect; never its text.
INTERNAL_CHECK_ERROR = "file: rejected (internal check error)"

LOG = logging.getLogger("papaia_kit.catalog")


@dataclass(frozen=True)
class Changes:
    """Entry ids that appeared, changed their ``content_hash`` or vanished."""

    added: tuple[str, ...] = ()
    changed: tuple[str, ...] = ()
    removed: tuple[str, ...] = ()

    def __bool__(self) -> bool:
        return bool(self.added or self.changed or self.removed)


def diff(old: Catalog | None, new: Catalog) -> Changes:
    """Changes from ``old`` to ``new``; with no ``old`` every entry is added."""
    before = {} if old is None else {e.id: e.content_hash for e in old.entries.values()}
    after = {e.id: e.content_hash for e in new.entries.values()}
    return Changes(
        added=tuple(sorted(after.keys() - before.keys())),
        changed=tuple(sorted(i for i in after.keys() & before.keys() if after[i] != before[i])),
        removed=tuple(sorted(before.keys() - after.keys())),
    )


@dataclass(frozen=True)
class ReaderStatus:
    """What ``doctor`` reports for one catalog file.

    ``ok``: a valid version is in use, or the file is ``absent`` (never present
    since the start, stand-alone) and nothing failed. ``error``: the current
    failure, place and rule only. ``digest``: the version in use.
    """

    path: Path
    ok: bool
    error: str | None
    digest: str | None
    checked_at: float | None
    absent: bool = False


_Stamp = tuple[int, int, int, int]


class Reader[T: (Catalog, GroupList)]:
    """Last-good reader for one catalog file. Safe to share between threads."""

    def __init__(
        self,
        path: os.PathLike[str] | str,
        parse: Callable[[bytes], T],
        *,
        max_age: float = MAX_AGE_SECONDS,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if not 0 < max_age <= MAX_AGE_SECONDS:
            raise ValueError(f"max_age must be in (0, {MAX_AGE_SECONDS}] seconds")
        self.path = Path(path)
        self._parse: Callable[[bytes], T] = parse
        self._max_age = max_age
        self._clock = clock
        self._lock = threading.RLock()
        self._current: T | None = None
        self._stamp: _Stamp | None = None
        self._error: str | None = None
        self._absent = False
        self._checked_at: float | None = None

    def get(self) -> T | None:
        """The last valid content, checking the file if the cache is older than ``max_age``."""
        with self._lock:
            if self._checked_at is None or self._clock() - self._checked_at >= self._max_age:
                self._refresh()
            return self._current

    def refresh(self) -> T | None:
        """Check the file now (file watch callback, ``doctor``) and return the valid content."""
        with self._lock:
            self._refresh()
            return self._current

    @property
    def status(self) -> ReaderStatus:
        with self._lock:
            return ReaderStatus(
                path=self.path,
                ok=self._error is None and (self._current is not None or self._absent),
                error=self._error,
                digest=None if self._current is None else self._current.digest,
                checked_at=self._checked_at,
                absent=self._absent,
            )

    def _refresh(self) -> None:
        self._checked_at = self._clock()
        read = self._read_checked()
        if read is None:
            return
        stamp, data = read
        self._absent = False
        if stamp == self._stamp and self._error is None:
            return
        parsed = self._parse_checked(stamp, data)
        if parsed is None:
            return
        if self._error is not None:
            LOG.info("catalog %s: valid again", self.path.name)
        self._error = None
        if self._current is None or parsed.digest != self._current.digest:
            previous, self._current = self._current, parsed
            self._accepted(previous, parsed)

    def _read_checked(self) -> tuple[_Stamp, bytes] | None:
        """The file's stamp and bytes, or ``None`` after recording why not."""
        try:
            return self._read()
        except FileNotFoundError:
            if self._current is None:
                self._not_present()
            else:
                self._fail("cannot read the file (No such file or directory)")
        except OSError as exc:
            self._fail(f"cannot read the file ({exc.strerror or type(exc).__name__})")
        except CatalogError as exc:
            self._fail(str(exc))
        return None

    def _parse_checked(self, stamp: _Stamp, data: bytes) -> T | None:
        """The checked content, or ``None`` after recording the failure.

        The stamp is stored either way, so an unchanged invalid file is not
        taken for a new version.
        """
        self._stamp = stamp
        try:
            return self._parse(data)
        except CatalogError as exc:
            self._fail(str(exc))
        except Exception:  # noqa: BLE001 - last line of defence, see the module docstring
            self._fail(INTERNAL_CHECK_ERROR)
        return None

    def _read(self) -> tuple[_Stamp, bytes]:
        # The core replaces the file by rename, so the open descriptor always
        # sees one complete version; the stamp is taken from that descriptor.
        with self.path.open("rb") as handle:
            info = os.fstat(handle.fileno())
            stamp = (info.st_size, info.st_mtime_ns, info.st_ino, info.st_dev)
            if stamp == self._stamp and self._error is None:
                return stamp, b""
            data = handle.read(MAX_BYTES + 1)
        if len(data) > MAX_BYTES:
            raise CatalogError([f"file: larger than {MAX_BYTES} bytes"])
        return stamp, data

    def _not_present(self) -> None:
        if not self._absent:
            LOG.info("catalog %s: not present, running without a catalog", self.path.name)
        self._absent = True
        self._error = None
        self._stamp = None

    def _fail(self, error: str) -> None:
        self._absent = False
        if error != self._error:
            kept = "no valid state yet" if self._current is None else "last valid state kept"
            LOG.warning("catalog %s invalid, %s: %s", self.path.name, kept, error)
        self._error = error

    def _accepted(self, previous: T | None, current: T) -> None:
        """Hook for subclasses: a new valid version replaced ``previous``."""


class ServicesReader(Reader[Catalog]):
    """Reader of ``platform/services.json`` that also reports entry changes."""

    def __init__(
        self,
        path: os.PathLike[str] | str,
        *,
        max_age: float = MAX_AGE_SECONDS,
        clock: Callable[[], float] = time.monotonic,
        on_change: Callable[[Catalog, Changes], None] | None = None,
    ) -> None:
        super().__init__(path, parse_services, max_age=max_age, clock=clock)
        self._on_change = on_change
        self._changes = Changes()

    @property
    def last_changes(self) -> Changes:
        """Changes of the most recent accepted version against the one before."""
        with self._lock:
            return self._changes

    def _accepted(self, previous: Catalog | None, current: Catalog) -> None:
        self._changes = diff(previous, current)
        if self._changes:
            LOG.info(
                "catalog %s: %d added, %d changed, %d removed",
                self.path.name,
                len(self._changes.added),
                len(self._changes.changed),
                len(self._changes.removed),
            )
        if self._on_change is not None:
            self._on_change(current, self._changes)


class GroupsReader(Reader[GroupList]):
    """Reader of ``platform/groups.json``."""

    def __init__(
        self,
        path: os.PathLike[str] | str,
        *,
        max_age: float = MAX_AGE_SECONDS,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        super().__init__(path, parse_groups, max_age=max_age, clock=clock)
