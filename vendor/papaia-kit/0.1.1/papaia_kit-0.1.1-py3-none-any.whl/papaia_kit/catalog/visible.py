"""Which modules a person sees in the switcher, and how a link to a module looks.

The rule is the same in every module and in the TypeScript package
(oberflaeche 2.2, shared vectors ``contract/vectors/visible_modules.json``)::

    visible_modules(catalog, roles) =
      sort_by(order, then id) [ e in catalog.ui
          | e.state == "running"
          and (e.visible_for_roles == [] or roles ∩ e.visible_for_roles ≠ ∅) ]

``roles`` is the ``roles`` claim of the ID token of the module's own client.
Visibility is display only: every target checks rights server-side on every
request, so nothing here grants or withholds access.
"""

from __future__ import annotations

from collections.abc import Iterable
from enum import StrEnum

from papaia_kit.catalog.document import Catalog, Surface

__all__ = ["LinkState", "link_state", "visible_modules"]


class LinkState(StrEnum):
    """How another module shows a link to a module (oberflaeche 2.4)."""

    OPEN = "open"
    """Installed, running, visible to the person: a normal link."""
    LOCKED = "locked"
    """Installed but stopped: a disabled link with "<module> is not reachable right now"."""
    HIDDEN = "hidden"
    """Installed, but not for the person's roles: no link."""
    ABSENT = "absent"
    """Not installed: no link; dependent places show the "not set up" sentence."""


def visible_modules(catalog: Catalog, roles: Iterable[str]) -> tuple[Surface, ...]:
    """Switcher surfaces for ``roles``, ordered by ``order`` and then ``id``."""
    held = _roles(roles)
    return tuple(
        sorted(
            (s for s in catalog.surfaces if s.running and _for_roles(s, held)),
            key=lambda s: (s.order, s.id),
        )
    )


def link_state(catalog: Catalog, surface_id: str, roles: Iterable[str]) -> LinkState:
    """State of a link to the module with switcher id ``surface_id``."""
    held = _roles(roles)
    surface = catalog.surface(surface_id)
    if surface is None:
        return LinkState.ABSENT
    if not _for_roles(surface, held):
        return LinkState.HIDDEN
    return LinkState.OPEN if surface.running else LinkState.LOCKED


def _for_roles(surface: Surface, held: frozenset[str]) -> bool:
    return not surface.visible_for_roles or not held.isdisjoint(surface.visible_for_roles)


def _roles(roles: Iterable[str]) -> frozenset[str]:
    # A single role passed as a string would otherwise be read as its characters.
    if isinstance(roles, str | bytes):
        raise TypeError("roles must be a collection of role names, not a single string")
    held = frozenset(roles)
    if not all(isinstance(role, str) for role in held):
        raise TypeError("every role must be a string")
    return held
