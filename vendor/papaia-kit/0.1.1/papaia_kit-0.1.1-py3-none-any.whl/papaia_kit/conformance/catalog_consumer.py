"""Catalog-consumer suite: the shared reader vectors against a module's catalog reader.

The suite writes each file version of ``contract/vectors/catalog_reader.json`` to
one path, asks the reader to refresh and compares what it reports with the
vector (accepted or not, stand-alone, catalog in use, entries added, changed
and removed, switcher and link states). It then serves the catalog of
``contract/vectors/visible_modules.json`` and checks every switcher and link case.

A Python module runs the suite with the kit's reader (``KitReaderDriver``). A
module with its own reader in another language wraps it in a driver command
that speaks the line protocol of ``CommandDriver`` (see ``contract/conformance.md``).
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import queue
import subprocess
import tempfile
import threading
import time
from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Any, Protocol

from papaia_kit._resources import contract_dir
from papaia_kit.catalog import (
    Catalog,
    Changes,
    ServicesReader,
    link_state,
    visible_modules,
)
from papaia_kit.conformance.result import Case, SuiteResult, case

SUITE = "catalog-consumer"
READER_VECTORS = "catalog_reader.json"
VISIBLE_VECTORS = "visible_modules.json"
_READER_FORMAT = "papaia.vectors.catalog-reader/1"
_VISIBLE_FORMAT = "papaia.vectors.visible-modules/1"
_MAX_REPLY_BYTES = 1024 * 1024


@dataclass(frozen=True, slots=True)
class Observation:
    """What a reader reports after one refresh."""

    ok: bool
    absent: bool
    error: str | None
    serving: str | None
    changes: Changes


class DriverError(RuntimeError):
    """The reader under test cannot be driven any further."""


class ReaderDriver(Protocol):
    """A catalog reader under test, bound to one file path."""

    def refresh(self) -> Observation: ...

    def visible(self, roles: Sequence[str]) -> list[str]: ...

    def link(self, surface: str, roles: Sequence[str]) -> str: ...

    def close(self) -> None: ...


DriverFactory = Callable[[Path], ReaderDriver]


class KitReaderDriver:
    """The kit's own reader (``papaia_kit.catalog.ServicesReader``)."""

    def __init__(self, path: Path) -> None:
        self._reader = ServicesReader(path)
        self._current: Catalog | None = None

    def refresh(self) -> Observation:
        before = self._reader.status.digest
        self._current = self._reader.refresh()
        status = self._reader.status
        changes = self._reader.last_changes if status.digest != before else Changes()
        serving = self._current.generated_at if self._current is not None else None
        return Observation(status.ok, status.absent, status.error, serving, changes)

    def visible(self, roles: Sequence[str]) -> list[str]:
        return [s.id for s in visible_modules(self._serving(), roles)]

    def link(self, surface: str, roles: Sequence[str]) -> str:
        return str(link_state(self._serving(), surface, roles))

    def close(self) -> None:
        return None

    def _serving(self) -> Catalog:
        if self._current is None:
            raise DriverError("reader serves no catalog")
        return self._current


class CommandDriver:
    """A driver command speaking one JSON object per line on stdin and stdout.

    The command is started once per catalog path with the path as its last
    argument. Requests: ``{"op": "refresh"}``, ``{"op": "visible", "roles": [...]}``,
    ``{"op": "link", "surface": "...", "roles": [...]}``. Replies:
    ``{"ok", "absent", "error", "serving", "changes": {"added", "changed", "removed"}}``,
    ``{"visible": [...]}`` and ``{"link": "open" | "locked" | "hidden" | "absent"}``.
    """

    def __init__(self, command: Sequence[str], *, timeout: float = 10.0) -> None:
        if not command or not all(command):
            raise ValueError("driver command must be a non-empty list of arguments")
        self.command = tuple(command)
        self.timeout = timeout

    def __call__(self, path: Path) -> ReaderDriver:
        return _CommandSession(self.command, path, self.timeout)


class _CommandSession:
    def __init__(self, command: Sequence[str], path: Path, timeout: float) -> None:
        self._timeout = timeout
        self._broken: str | None = None
        self._replies: queue.Queue[bytes | None] = queue.Queue()
        try:
            # The command is the module's own CI configuration, run without a shell.
            self._process: subprocess.Popen[bytes] | None = subprocess.Popen(  # noqa: S603
                [*command, str(path)],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
        except OSError as exc:
            self._process = None
            self._broken = f"driver could not start ({exc.strerror or type(exc).__name__})"
            return
        stdout = self._process.stdout
        if stdout is None:  # pragma: no cover - Popen with PIPE always sets it
            raise DriverError("driver has no output")
        threading.Thread(target=self._pump, args=(stdout,), daemon=True).start()

    def _pump(self, stream: IO[bytes]) -> None:
        for line in iter(lambda: stream.readline(_MAX_REPLY_BYTES + 1), b""):
            self._replies.put(line)
        self._replies.put(None)

    def _ask(self, request: dict[str, Any], fields: dict[str, type | tuple[type, ...]]) -> Any:
        if self._broken is not None:
            raise DriverError(self._broken)
        process = self._process
        if process is None or process.stdin is None:  # pragma: no cover - set together
            raise DriverError("driver is not running")
        try:
            process.stdin.write(json.dumps(request).encode() + b"\n")
            process.stdin.flush()
            line = self._replies.get(timeout=self._timeout)
        except (OSError, ValueError):
            line = None
        except queue.Empty:
            self._broken = f"driver did not answer within {self._timeout:g} s"
            raise DriverError(self._broken) from None
        if line is None:
            self._broken = "driver ended before answering"
            raise DriverError(self._broken)
        try:
            return _parse_reply(line, fields)
        except DriverError as exc:
            self._broken = str(exc)
            raise

    def refresh(self) -> Observation:
        reply = self._ask(
            {"op": "refresh"},
            {
                "ok": bool,
                "absent": bool,
                "error": (str, type(None)),
                "serving": (str, type(None)),
                "changes": dict,
            },
        )
        changes = reply["changes"]
        if set(changes) != {"added", "changed", "removed"} or not all(
            _strings(v) for v in changes.values()
        ):
            self._broken = "driver reply has a malformed 'changes'"
            raise DriverError(self._broken)
        return Observation(
            reply["ok"],
            reply["absent"],
            reply["error"],
            reply["serving"],
            Changes(tuple(changes["added"]), tuple(changes["changed"]), tuple(changes["removed"])),
        )

    def visible(self, roles: Sequence[str]) -> list[str]:
        reply = self._ask({"op": "visible", "roles": list(roles)}, {"visible": list})
        shown = reply["visible"]
        if not _strings(shown):
            self._broken = "driver reply has a malformed 'visible'"
            raise DriverError(self._broken)
        return list(shown)

    def link(self, surface: str, roles: Sequence[str]) -> str:
        reply = self._ask({"op": "link", "surface": surface, "roles": list(roles)}, {"link": str})
        return str(reply["link"])

    def close(self) -> None:
        process = self._process
        if process is None:
            return
        if process.stdin is not None:
            with contextlib.suppress(OSError):
                process.stdin.close()
        try:
            process.wait(timeout=self._timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()


def _strings(value: object) -> bool:
    return isinstance(value, list) and all(isinstance(item, str) for item in value)


def _parse_reply(line: bytes, fields: dict[str, type | tuple[type, ...]]) -> dict[str, Any]:
    """The reply as a mapping with exactly ``fields`` of the given types."""
    if len(line) > _MAX_REPLY_BYTES:
        raise DriverError("driver reply is larger than 1 MiB")
    try:
        reply = json.loads(line)
    except ValueError:
        raise DriverError("driver reply is not JSON") from None
    if not isinstance(reply, dict):
        raise DriverError("driver reply is not a JSON object")
    unknown = sorted(set(reply) - set(fields))
    if unknown:
        raise DriverError(f"driver reply has unknown field {unknown[0]!r}")
    for name, kind in fields.items():
        if name not in reply:
            raise DriverError(f"driver reply lacks field {name!r}")
        value = reply[name]
        # bool is an int in Python; JSON keeps them apart.
        if not isinstance(value, kind) or (isinstance(value, bool) and kind is not bool):
            raise DriverError(f"driver reply has a malformed {name!r}")
    return reply


# --- suite --------------------------------------------------------------------


def _vectors(name: str, expected_format: str) -> dict[str, Any]:
    data = json.loads((contract_dir() / "vectors" / name).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("format") != expected_format:
        raise ValueError(f"{name}: expected format {expected_format}")
    return data


def _write(path: Path, file: dict[str, Any] | None) -> None:
    """Replace the file the way the core does: temporary file, then rename."""
    if file is None:
        path.unlink(missing_ok=True)
        return
    text = file["text"] if "text" in file else json.dumps(file["json"], ensure_ascii=False)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    os.replace(temporary, path)


def _compare(observed: Observation, expect: dict[str, Any]) -> list[str]:
    valid = expect["valid"]
    failures = []
    if observed.ok is not valid:
        failures.append(f"ok: expected {valid}, got {observed.ok}")
    if (observed.error is None) is not valid:
        failures.append("error: expected none" if valid else "error: expected an error message")
    absent = expect.get("absent", False)
    if observed.absent is not absent:
        failures.append(f"absent: expected {absent}, got {observed.absent}")
    if observed.serving != expect["serving"]:
        failures.append(f"serving: expected {expect['serving']!r}, got {observed.serving!r}")
    wanted = expect["changes"]
    expected = Changes(tuple(wanted["added"]), tuple(wanted["changed"]), tuple(wanted["removed"]))
    if expect["serving"] is not None and observed.changes != expected:
        failures.append(f"changes: expected {_changes(expected)}, got {_changes(observed.changes)}")
    return failures


def _changes(changes: Changes) -> str:
    return (
        f"added {list(changes.added)}, changed {list(changes.changed)}, "
        f"removed {list(changes.removed)}"
    )


def _reader_cases(factory: DriverFactory, workdir: Path) -> list[Case]:
    vectors = _vectors(READER_VECTORS, _READER_FORMAT)
    path = workdir / "services.json"
    cases: list[Case] = []
    driver: ReaderDriver | None = None
    broken: str | None = None
    try:
        driver = factory(path)
        for step in vectors["steps"]:
            name, expect = step["name"], step["expect"]
            if broken is not None:
                cases.append(case(SUITE, "catalog_reader", name, [broken]))
                continue
            try:
                _write(path, step["file"])
                failures = _compare(driver.refresh(), expect)
                if "visible" in expect and expect["serving"] is not None:
                    shown = driver.visible(expect["visible"]["roles"])
                    if shown != expect["visible"]["expect"]:
                        failures.append(
                            f"visible: expected {expect['visible']['expect']}, got {shown}"
                        )
                for link in expect.get("links", []):
                    state = driver.link(link["surface"], link["roles"])
                    if state != link["expect"]:
                        failures.append(
                            f"link {link['surface']}: expected {link['expect']!r}, got {state!r}"
                        )
            except DriverError as exc:
                broken = str(exc)
                failures = [broken]
            cases.append(case(SUITE, "catalog_reader", name, failures))
    finally:
        if driver is not None:
            driver.close()
    return cases


def _visible_cases(factory: DriverFactory, workdir: Path) -> list[Case]:
    vectors = _vectors(VISIBLE_VECTORS, _VISIBLE_FORMAT)
    path = workdir / "visible.json"
    _write(path, {"json": vectors["catalog"]})
    probes: list[tuple[str, Callable[[ReaderDriver], list[str]]]] = []
    for item in vectors["visible"]:
        probes.append((item["name"], _visible_probe(item)))
    for item in vectors["links"]:
        probes.append((item["name"], _link_probe(item)))
    cases: list[Case] = []
    driver: ReaderDriver | None = None
    broken: str | None = None
    try:
        driver = factory(path)
        observed = driver.refresh()
        if not observed.ok or observed.serving != vectors["catalog"]["generated_at"]:
            broken = "reader did not accept the catalog of visible_modules.json"
    except DriverError as exc:
        broken = str(exc)
    try:
        for name, probe in probes:
            if broken is not None or driver is None:
                cases.append(case(SUITE, "visible_modules", name, [broken or "driver missing"]))
                continue
            try:
                failures = probe(driver)
            except DriverError as exc:
                broken = str(exc)
                failures = [broken]
            cases.append(case(SUITE, "visible_modules", name, failures))
    finally:
        if driver is not None:
            driver.close()
    return cases


def _visible_probe(item: dict[str, Any]) -> Callable[[ReaderDriver], list[str]]:
    def probe(driver: ReaderDriver) -> list[str]:
        shown = driver.visible(item["roles"])
        return [] if shown == item["expect"] else [f"expected {item['expect']}, got {shown}"]

    return probe


def _link_probe(item: dict[str, Any]) -> Callable[[ReaderDriver], list[str]]:
    def probe(driver: ReaderDriver) -> list[str]:
        state = driver.link(item["surface"], item["roles"])
        return [] if state == item["expect"] else [f"expected {item['expect']!r}, got {state!r}"]

    return probe


@contextlib.contextmanager
def _quiet_reader_log() -> Iterator[None]:
    """Keep the kit reader's log of the deliberately invalid vector files out of the CI log."""
    log = logging.getLogger("papaia_kit.catalog")
    previous = log.disabled
    log.disabled = True
    try:
        yield
    finally:
        log.disabled = previous


def run_catalog_consumer(
    factory: DriverFactory = KitReaderDriver, *, workdir: Path | None = None
) -> SuiteResult:
    """Run every shared catalog vector against the reader that ``factory`` binds to a path."""
    started = time.monotonic()
    with _quiet_reader_log(), tempfile.TemporaryDirectory(prefix="papaia-kit-catalog-") as scratch:
        base = Path(workdir) if workdir is not None else Path(scratch)
        cases = _reader_cases(factory, base) + _visible_cases(factory, base)
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started)
