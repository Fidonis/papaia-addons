"""Halt suite: the shared platform halt vectors against a module's halt check.

The suite plays ``contract/vectors/halt.json`` step by step into one state
folder, the way the host command changes it (temporary file, then rename),
and after each step attempts every guarded action plus a read of own data at
once, without waiting for a poll. One long-lived driver serves the whole run,
so a module that caches its answer, fails open on an unusable file or halts
only some actions fails the steps that show it.

A Python module runs the suite with the kit guard (``KitHaltDriver``) or with
its own adapter around ``papaia_kit.halt.HaltGuard``. A module written in
another language wraps its halt check in a driver command that speaks the line
protocol of ``HaltCommandDriver`` (see ``contract/conformance.md``).
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
import time
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import Any, Final, Protocol

from papaia_kit._resources import contract_dir
from papaia_kit.conformance.catalog_consumer import DriverError, _CommandSession
from papaia_kit.conformance.result import Case, SuiteResult, case
from papaia_kit.halt import HALT_FILE, Action, HaltGuard

SUITE: Final = "halt"
VECTORS: Final = "halt.json"
_FORMAT: Final = "papaia.vectors.halt/1"
#: Every guarded action, then the read of own data that a halt never stops.
HALT_ACTIONS: Final = (*(a.value for a in Action), "read")


class HaltDriver(Protocol):
    """A module's halt check under test, bound to one state folder."""

    def attempt(self, action: str) -> bool:
        """Whether the module would carry out ``action`` now."""
        ...

    def close(self) -> None: ...


HaltDriverFactory = Callable[[Path], HaltDriver]


class KitHaltDriver:
    """The kit's own guard (``papaia_kit.halt.HaltGuard``)."""

    def __init__(self, folder: Path) -> None:
        self._guard = HaltGuard(folder)

    def attempt(self, action: str) -> bool:
        if action == "read":
            return True
        Action(action)
        return not self._guard.halted()

    def close(self) -> None:
        return None


class HaltCommandDriver:
    """A driver command speaking one JSON object per line on stdin and stdout.

    The command is started once with the state folder as its last argument.
    Request: ``{"op": "attempt", "action": "<action>"}``; reply:
    ``{"acted": true | false}``.
    """

    def __init__(self, command: Sequence[str], *, timeout: float = 10.0) -> None:
        if not command or not all(part.strip() for part in command):
            raise ValueError("driver command must be a non-empty list of arguments")
        self.command = tuple(command)
        self.timeout = timeout

    def __call__(self, folder: Path) -> HaltDriver:
        return _HaltSession(self.command, folder, self.timeout)


class _HaltSession(_CommandSession):
    def attempt(self, action: str) -> bool:
        reply = self._ask({"op": "attempt", "action": action}, {"acted": bool})
        return bool(reply["acted"])


def _vectors() -> list[dict[str, Any]]:
    data = json.loads((contract_dir() / "vectors" / VECTORS).read_text(encoding="utf-8"))
    if not isinstance(data, dict) or data.get("format") != _FORMAT:
        raise ValueError(f"{VECTORS}: expected format {_FORMAT}")
    return list(data["steps"])


def _content(file: dict[str, Any]) -> bytes:
    if "json" in file:
        data = json.dumps(file["json"], sort_keys=True, separators=(",", ":")).encode()
    elif "hex" in file:
        data = bytes.fromhex(file["hex"].replace(" ", ""))
    else:
        data = file["text"].encode("utf-8")
    pad_to = file.get("pad_to")
    if pad_to is not None:
        data += b" " * (pad_to - len(data))
    return data


def _clear(path: Path) -> None:
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def _apply(folder: Path, state: dict[str, Any]) -> None:
    """Change the state folder as the step says."""
    path = folder / HALT_FILE
    if state.get("folder") == "missing":
        shutil.rmtree(folder, ignore_errors=True)
        return
    folder.mkdir(mode=0o755, exist_ok=True)
    special = state.get("special")
    if special is not None:
        _clear(path)
        if special == "symlink":
            outside = folder.parent / "outside.json"
            outside.write_bytes(b'{"active":false,"by":"host:ops","reason":"","since":0}')
            path.symlink_to(outside)
        elif special == "directory":
            path.mkdir()
        elif special == "fifo":
            os.mkfifo(path)
        else:
            raise ValueError(f"{VECTORS}: unknown special {special!r}")
        return
    file = state["file"]
    if file is None:
        _clear(path)
        return
    data = _content(file)
    temporary = folder / ".halt.tmp"
    temporary.write_bytes(data)
    if file.get("keep_stat"):
        old = os.stat(path, follow_symlinks=False)
        if old.st_size != len(data):
            raise ValueError(f"{VECTORS}: keep_stat needs a file of the same size")
        os.utime(temporary, ns=(old.st_atime_ns, old.st_mtime_ns))
    elif path.is_dir() and not path.is_symlink():
        _clear(path)
    os.replace(temporary, path)


def _attempt_all(driver: HaltDriver, halted: bool) -> list[str]:
    failures = []
    for action in HALT_ACTIONS:
        acted = driver.attempt(action)
        expected = action == "read" or not halted
        if acted is not expected:
            want, got = ("acted", "refused") if expected else ("refused", "acted")
            failures.append(f"{action}: expected {want}, {got}")
    return failures


def _run(factory: HaltDriverFactory, workdir: Path) -> list[Case]:
    folder = workdir / "state"
    folder.mkdir(mode=0o755)
    cases: list[Case] = []
    broken: str | None = None
    driver: HaltDriver | None = None
    try:
        try:
            driver = factory(folder)
        except DriverError as exc:
            broken = str(exc)
        for step in _vectors():
            name = step["name"]
            if broken is not None or driver is None:
                cases.append(case(SUITE, "halt", name, [broken or "driver missing"]))
                continue
            _apply(folder, step["state"])
            try:
                failures = _attempt_all(driver, step["expect"]["halted"])
            except DriverError as exc:
                broken = str(exc)
                failures = [broken]
            cases.append(case(SUITE, "halt", name, failures))
    finally:
        if driver is not None:
            driver.close()
    return cases


def run_halt_suite(factory: HaltDriverFactory, *, workdir: Path | None = None) -> SuiteResult:
    """Run the halt vectors against the halt check ``factory`` builds for a state folder."""
    started = time.monotonic()
    if workdir is not None:
        cases = _run(factory, workdir)
    else:
        with tempfile.TemporaryDirectory(prefix="pk-halt-") as tmp:
            cases = _run(factory, Path(tmp))
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started)
