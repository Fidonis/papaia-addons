"""me-v2 suite: a running personal-area module API against its declaration (V-09, ME-19).

The suite reads the module's declaration (``personal_settings:``, contract
version 2, ``contract/me-contract.md``) and talks HTTP to the module API
``{base}`` with person tokens of the kit test issuer for the module's audience.
It changes the test person's state (one settings write, one deletion), so it
runs against a test instance only. Checks, one case each, in this order:

- ``declaration``: the declaration against ``me-contract.v2``; when it fails,
  no request is sent and every other case fails as not run;
- ``unauthorized``: reading without a token answers ``401 unauthorized``;
- ``read``: ``GET {base}`` answers ``read_response`` for the declared module
  and groups;
- ``precondition``: a write without ``If-Match`` answers
  ``428 precondition_required``;
- ``stale``: a write with an old ETag answers ``412 stale`` with the current ETag;
- ``idempotency``: a write without ``Idempotency-Key`` answers
  ``400 malformed_request``; the repeat with the same key and body answers the
  first answer again (status, ``operation_id``, ETag); the same key with another
  body answers ``409 conflict``;
- ``field-errors``: an undeclared key and a read-only key answer ``422 invalid``
  with the field errors ``unknown_key`` and ``read_only`` at their pointers;
- ``fresh-login``: a write or export that needs a fresh sign-in, sent with a
  sign-in older than 300 s, answers ``403 step_up_required`` with ``max_age``;
- ``deletion-receipt``: ``delete_all`` (or deleting a data category) answers a
  receipt, and its repeat with the same key answers the same receipt.

Every answer must carry ``Cache-Control: no-store``. A module that declares
nothing for ``fresh-login`` or ``deletion-receipt`` passes that case and the
result names it in the property ``not_applicable.<check>``.

With a ``Provider`` (``record_me_v2_suite``, CLI ``--record``) the run is
written as a provider recording (``papaia.conformance-recording/1``) without
credentials, only when every check passed. Messages name groups, keys,
statuses and codes, never a token or a value of the person.
"""

from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
import uuid
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from functools import cache
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlsplit

from jsonschema import Draft202012Validator

from papaia_kit import __version__, data_classes
from papaia_kit._resources import schemas_dir
from papaia_kit.conformance.manifest import ManifestError, _load_yaml
from papaia_kit.conformance.recording import (
    RECORDING_FORMAT,
    RecordingError,
    dump_recording,
    schema_version,
)
from papaia_kit.conformance.result import Case, SuiteResult, case
from papaia_kit.conformance.server import (
    DEFAULT_SUBJECT,
    MAX_EXCHANGES,
    MAX_RESPONSE_BYTES,
    RECORDING_CHECK,
    Provider,
    ServerSuiteError,
    TransportError,
    _NoRedirect,
    check_url,
)
from papaia_kit.correlation import CORRELATION_HEADER, new_correlation_id

SUITE = "me-v2"
ME_V2_CHECKS = (
    "declaration",
    "unauthorized",
    "read",
    "precondition",
    "stale",
    "idempotency",
    "field-errors",
    "fresh-login",
    "deletion-receipt",
)
DECLARATION_SCHEMA = "me-contract.v2.schema.json"
ME_CLIENT = "papaia-me"
FRESH_MAX_AGE = 300
STALE_AUTH_AGE = 600  # seconds: well beyond the 300 s of the contract
STALE_ETAG = '"papaia-kit-stale"'
UNKNOWN_KEY = "papaia_kit_unknown_field"
RECORDED_REQUEST_HEADERS = (
    "content-type",
    "accept",
    "if-match",
    "idempotency-key",
    "x-papaia-correlation-id",
)
RECORDED_RESPONSE_HEADERS = ("content-type", "cache-control", "etag", "location", "retry-after")
PROBLEM_TYPE = "application/problem+json"
HTTP_OK = 200
HTTP_ACCEPTED = 202
HTTP_PRECONDITION_FAILED = 412
MAX_SHOWN_CODE = 40
_NAME = re.compile(r"[a-z][a-z0-9-]{0,62}")
_SUBJECT = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:@|+-]{0,127}")
_DECLARATION_BROKEN = "not run: the declaration fails the schema"
_NO_READ = "not run: the read of all groups failed"
Json = dict[str, Any]


class MeV2SuiteError(ValueError):
    """Unusable input of the suite (URL, names, declaration file): exit code 2."""


class _NotRunError(Exception):
    """A case cannot run; the message says why."""


class PersonTokens(Protocol):
    """Issues person tokens; ``auth_age`` puts the sign-in that many seconds in the past."""

    def token(
        self, *, sub: str, azp: str, aud: str | list[str], roles: Any, auth_age: int = 0
    ) -> str: ...


def load_me_declaration(path: Path) -> Json:
    """The value of ``personal_settings:`` of a manifest or ``personal-settings.yaml``."""
    try:
        document = _load_yaml(path)
    except ManifestError as exc:
        raise MeV2SuiteError(f"declaration {path.name}: {exc}") from None
    value = document.get("personal_settings") if isinstance(document, dict) else None
    if not isinstance(value, dict):
        raise MeV2SuiteError(f"declaration {path.name}: no personal_settings: mapping")
    return value


@dataclass(frozen=True)
class MeTarget:
    """The module API under test and what the suite needs to drive it."""

    url: str
    declaration: Mapping[str, Any]
    tokens: PersonTokens
    audience: str
    azp: str = ME_CLIENT
    subject: str = DEFAULT_SUBJECT
    roles: tuple[str, ...] = ()
    timeout: float = 10.0

    def __post_init__(self) -> None:
        try:
            check_url(self.url, "module URL")
        except ServerSuiteError as exc:
            raise MeV2SuiteError(str(exc)) from None
        if urlsplit(self.url).query:
            raise MeV2SuiteError("module URL must not carry a query")
        if not _NAME.fullmatch(self.audience):
            raise MeV2SuiteError("audience must be a registered name such as papaia-studio-me")
        if not _NAME.fullmatch(self.azp):
            raise MeV2SuiteError("azp must be a client name such as papaia-me")
        if not _SUBJECT.fullmatch(self.subject):
            raise MeV2SuiteError("subject must be 1 to 128 characters [A-Za-z0-9._:@|+-]")
        if not isinstance(self.declaration, Mapping):
            raise MeV2SuiteError("the declaration must be a mapping")

    @property
    def base(self) -> str:
        return urlsplit(self.url).path.rstrip("/")

    @property
    def origin(self) -> str:
        parts = urlsplit(self.url)
        return f"{parts.scheme}://{parts.netloc}"

    @property
    def catalog_id(self) -> str:
        exposes = self.declaration.get("exposes")
        return exposes if isinstance(exposes, str) else "unknown"


@dataclass(frozen=True)
class _Reply:
    status: int
    headers: Mapping[str, str]
    body: bytes

    def json(self) -> Any:
        try:
            return json.loads(self.body.decode("utf-8"))
        except (UnicodeDecodeError, ValueError, RecursionError):
            return None

    @property
    def content_type(self) -> str:
        return self.headers.get("content-type", "").partition(";")[0].strip().lower()


class Http:
    """HTTP over urllib without proxies of the environment and without redirects."""

    def __init__(self) -> None:
        self._opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoRedirect)

    def send(
        self, method: str, url: str, body: bytes | None, headers: Mapping[str, str], timeout: float
    ) -> _Reply:
        request = urllib.request.Request(  # noqa: S310 - scheme checked by check_url
            url, data=body, method=method, headers=dict(headers)
        )
        try:
            with self._opener.open(request, timeout=timeout) as response:
                return self._reply(response.status, response.headers, response)
        except urllib.error.HTTPError as error:
            return self._reply(error.code, error.headers, error)
        except (urllib.error.URLError, OSError) as error:
            raise TransportError(
                f"no answer from {urlsplit(url).netloc}: {type(error).__name__}"
            ) from None

    @staticmethod
    def _reply(status: int, headers: Any, stream: Any) -> _Reply:
        raw = stream.read(MAX_RESPONSE_BYTES + 1)
        if len(raw) > MAX_RESPONSE_BYTES:
            raise TransportError("answer is larger than 1 MiB")
        lowered = {str(k).lower(): str(v) for k, v in headers.items()} if headers else {}
        return _Reply(status, lowered, raw)


@cache
def _schema() -> Json:
    loaded: Json = json.loads((schemas_dir() / DECLARATION_SCHEMA).read_text(encoding="utf-8"))
    return loaded


@cache
def _validator(definition: str | None = None) -> Draft202012Validator:
    schema = _schema()
    if definition is None:
        return Draft202012Validator(schema)
    return Draft202012Validator({"$ref": f"#/$defs/{definition}", "$defs": schema["$defs"]})


def _shape(value: object, definition: str | None, what: str) -> list[str]:
    """Schema failures of ``value`` as places and keywords, never values."""
    return [
        f"{what}: {'/'.join(str(p) for p in e.absolute_path) or '(root)'} fails {e.validator}"
        for e in sorted(
            _validator(definition).iter_errors(value), key=lambda e: [str(p) for p in e.path]
        )
    ][:10]


@dataclass
class _Run:
    target: MeTarget
    http: Http
    exchanges: list[Json] = field(default_factory=list)
    issued: list[str] = field(default_factory=list)
    read: Json | None = None
    etags: dict[str, str] = field(default_factory=dict)
    not_applicable: list[tuple[str, str]] = field(default_factory=list)
    _tokens: dict[int, str] = field(default_factory=dict)

    @property
    def groups(self) -> dict[str, Json]:
        listed = self.target.declaration.get("groups")
        return {g["id"]: g for g in listed or [] if isinstance(g, dict) and "id" in g}

    def token(self, auth_age: int = 0) -> str:
        if auth_age not in self._tokens:
            t = self.target
            value = t.tokens.token(
                sub=t.subject, azp=t.azp, aud=t.audience, roles=list(t.roles), auth_age=auth_age
            )
            self._tokens[auth_age] = value
            self.issued.append(value)
        return self._tokens[auth_age]

    def call(  # noqa: PLR0913 - one request with its parts
        self,
        name: str,
        method: str,
        path: str,
        *,
        token: str | None,
        body: object = None,
        if_match: str | None = None,
        key: str | None = None,
    ) -> _Reply:
        headers = {"Accept": "application/json", CORRELATION_HEADER: new_correlation_id()}
        data = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if token is not None:
            headers["Authorization"] = f"Bearer {token}"
        if if_match is not None:
            headers["If-Match"] = if_match
        if key is not None:
            headers["Idempotency-Key"] = key
        try:
            reply = self.http.send(
                method, self.target.origin + path, data, headers, self.target.timeout
            )
        except TransportError as exc:
            raise _NotRunError(str(exc)) from None
        self._record(name, method, path, headers=headers, body=body, reply=reply)
        if reply.status // 100 == HTTP_OK // 100 or reply.status == HTTP_PRECONDITION_FAILED:
            answer = reply.json()
            etag = answer.get("etag") if isinstance(answer, dict) else None
            group = path.removeprefix(self.target.base + "/")
            if isinstance(etag, str) and group in self.etags:
                self.etags[group] = etag
        return reply

    def _record(
        self,
        name: str,
        method: str,
        path: str,
        *,
        headers: Mapping[str, str],
        body: object,
        reply: _Reply,
    ) -> None:
        sent = {k.lower(): v for k, v in headers.items() if k.lower() in RECORDED_REQUEST_HEADERS}
        request: Json = {"transport": "http", "method": method, "path": path, "headers": sent}
        if body is not None:
            request["body"] = body
        got = {k: v[:1024] for k, v in reply.headers.items() if k in RECORDED_RESPONSE_HEADERS}
        response: Json = {"status": reply.status, "headers": got}
        if reply.content_type in ("application/json", PROBLEM_TYPE) and reply.body:
            response["body"] = reply.json()
        self.exchanges.append({"name": name[:200], "request": request, "response": response})


# -- helpers of the checks ----------------------------------------------------


def _new_key() -> str:
    return str(uuid.uuid4())


def _no_store(reply: _Reply, what: str) -> list[str]:
    directives = {d.strip().lower() for d in reply.headers.get("cache-control", "").split(",")}
    return [] if "no-store" in directives else [f"{what}: answer without Cache-Control: no-store"]


def _expect_error(reply: _Reply, status: int, code: str, what: str) -> list[str]:
    """``status`` with the contract error ``code`` (``application/problem+json``)."""
    answer = reply.json()
    got = answer.get("code") if isinstance(answer, dict) else None
    if reply.status != status or got != code:
        shown = got if isinstance(got, str) and len(got) <= MAX_SHOWN_CODE else "no code"
        return [f"{what}: expected {status} {code}, got {reply.status} {shown}"]
    problems = _shape(answer, "error", what)
    if reply.content_type != PROBLEM_TYPE:
        problems.append(f"{what}: error body is not {PROBLEM_TYPE}")
    return problems + _no_store(reply, what)


def _expect_ok(reply: _Reply, status: int, definition: str, what: str) -> list[str]:
    if reply.status != status:
        return [f"{what}: expected {status}, got {reply.status}"]
    return _shape(reply.json(), definition, what) + _no_store(reply, what)


def _editable(field_spec: Mapping[str, Any]) -> bool:
    return field_spec.get("editable", True) is not False and field_spec.get("type") != "provenance"


def _values_of(state: Mapping[str, Any]) -> Mapping[str, Any]:
    values = state.get("values")
    return values if isinstance(values, dict) else {}


def _values(run: _Run, group_id: str) -> Mapping[str, Any]:
    """The values the read answered for a settings group; empty when it answered none."""
    groups = run.read.get("groups") if run.read else None
    state = groups.get(group_id) if isinstance(groups, dict) else None
    return _values_of(state) if isinstance(state, dict) else {}


def _settings_body(run: _Run, group: Mapping[str, Any]) -> Json:
    """Every editable key with its current value (or default): a write that changes nothing."""
    values = _values(run, group["id"])
    body: Json = {}
    for spec in group.get("settings", []):
        if not _editable(spec):
            continue
        if spec["key"] in values:
            body[spec["key"]] = values[spec["key"]]
        elif "default" in spec:
            body[spec["key"]] = spec["default"]
        else:
            raise _NotRunError(f"group {group['id']}: no current value or default for a key")
    return body


def _write_group(run: _Run, *, sensitive: bool) -> Mapping[str, Any]:
    """A readable settings group with an editable key (``sensitive`` as asked)."""
    if run.read is None:
        raise _NotRunError(_NO_READ)
    for group in run.groups.values():
        if (
            group.get("kind", "settings") == "settings"
            and bool(group.get("sensitive")) is sensitive
            and group["id"] in run.etags
            and any(_editable(s) for s in group.get("settings", []))
        ):
            return group
    if sensitive:
        raise _NotRunError("no sensitive settings group")
    raise _NotRunError("no settings group with an editable key that the test person can read")


def _put(run: _Run, name: str, group: str, **kwargs: Any) -> _Reply:
    return run.call(name, "PUT", f"{run.target.base}/{group}", **kwargs)


def _other_body(group: Mapping[str, Any], body: Json) -> Json:
    """``body`` with one value changed to another valid value, else with an extra key."""
    for spec in group.get("settings", []):
        key = spec["key"]
        if key not in body:
            continue
        if spec.get("type") == "boolean" and isinstance(body[key], bool):
            return {**body, key: not body[key]}
        options = spec.get("options")
        if spec.get("type") == "choice" and isinstance(options, list):
            for option in options:
                if option.get("value") != body[key]:
                    return {**body, key: option.get("value")}
    return {**body, UNKNOWN_KEY: True}


# -- checks -------------------------------------------------------------------


def _check_declaration(run: _Run) -> list[str]:
    return _shape(dict(run.target.declaration), None, "declaration")


def _check_unauthorized(run: _Run) -> list[str]:
    reply = run.call("unauthorized: read without a token", "GET", run.target.base, token=None)
    return _expect_error(reply, 401, "unauthorized", "read without a token")


def _check_read(run: _Run) -> list[str]:
    reply = run.call("read: all groups", "GET", run.target.base, token=run.token())
    problems = _expect_ok(reply, HTTP_OK, "read_response", "read")
    answer = reply.json()
    if reply.status != HTTP_OK or not isinstance(answer, dict):
        return problems
    groups = answer.get("groups")
    if not isinstance(groups, dict):
        return problems
    declared = run.groups
    module = run.target.declaration.get("module")
    if "module" in answer and answer["module"] != module:
        problems.append("read: module differs from the declaration")
    for group_id, state in groups.items():
        spec = declared.get(group_id)
        if spec is None:
            problems.append(f"read: group {group_id[:64]} is not declared")
            continue
        if not isinstance(state, dict):
            continue
        settings = spec.get("kind", "settings") == "settings"
        if settings != ("values" in state):
            problems.append(f"read: group {group_id} does not answer in the shape of its kind")
        keys = {s.get("key") for s in spec.get("settings", [])}
        if unknown := sorted(str(k)[:64] for k in _values_of(state) if k not in keys):
            problems.append(f"read: group {group_id} has undeclared keys {unknown}")
        if isinstance(state.get("etag"), str):
            run.etags[group_id] = state["etag"]
    run.read = answer
    return problems


def _check_precondition(run: _Run) -> list[str]:
    group = _write_group(run, sensitive=False)
    reply = _put(
        run,
        f"precondition: replace {group['id']} without If-Match",
        group["id"],
        token=run.token(),
        body=_settings_body(run, group),
        key=_new_key(),
    )
    return _expect_error(reply, 428, "precondition_required", "write without If-Match")


def _check_stale(run: _Run) -> list[str]:
    group = _write_group(run, sensitive=False)
    reply = _put(
        run,
        f"stale: replace {group['id']} with an old ETag",
        group["id"],
        token=run.token(),
        body=_settings_body(run, group),
        if_match=STALE_ETAG,
        key=_new_key(),
    )
    problems = _expect_error(reply, 412, "stale", "write with an old ETag")
    answer = reply.json()
    etag = answer.get("etag") if isinstance(answer, dict) else None
    if not problems and (not isinstance(etag, str) or etag == STALE_ETAG):
        problems.append("write with an old ETag: 412 does not name the current etag")
    return problems


def _check_idempotency(run: _Run) -> list[str]:
    group = _write_group(run, sensitive=False)
    gid, body, token = group["id"], _settings_body(run, group), run.token()
    etag = run.etags[gid]
    reply = _put(
        run, f"idempotency: replace {gid} without key", gid, token=token, body=body, if_match=etag
    )
    problems = _expect_error(reply, 400, "malformed_request", "write without Idempotency-Key")
    key = _new_key()
    first = _put(
        run, f"idempotency: replace {gid}", gid, token=token, body=body, if_match=etag, key=key
    )
    problems += _expect_ok(first, 200, "settings_write_result", "write")
    answer = first.json() if first.status == HTTP_OK else None
    if isinstance(answer, dict) and first.headers.get("etag") != answer.get("etag"):
        problems.append("write: ETag header differs from etag of the body")
    again = _put(
        run,
        f"idempotency: repeat of replace {gid}",
        gid,
        token=token,
        body=body,
        if_match=etag,
        key=key,
    )
    repeated = again.json()
    if (
        again.status != first.status
        or not isinstance(repeated, dict)
        or not isinstance(answer, dict)
    ):
        problems.append(f"repeat with the same key: got {again.status}, first {first.status}")
    else:
        for name in ("operation_id", "etag"):
            if repeated.get(name) != answer.get(name):
                problems.append(f"repeat with the same key: {name} differs from the first answer")
    other = _put(
        run,
        f"idempotency: same key, other body for {gid}",
        gid,
        token=token,
        body=_other_body(group, body),
        if_match=etag,
        key=key,
    )
    return problems + _expect_error(other, 409, "conflict", "same key with another body")


def _check_field_errors(run: _Run) -> list[str]:
    group = _write_group(run, sensitive=False)
    body = _settings_body(run, group)
    body[UNKNOWN_KEY] = True
    expected = {(f"/{UNKNOWN_KEY}", "unknown_key")}
    values = _values(run, group["id"])
    for spec in group.get("settings", []):
        if not _editable(spec) and (spec["key"] in values or "default" in spec):
            body[spec["key"]] = values.get(spec["key"], spec.get("default"))
            expected.add((f"/{spec['key']}", "read_only"))
            break
    reply = _put(
        run,
        f"field-errors: replace {group['id']} with undeclared and read-only keys",
        group["id"],
        token=run.token(),
        body=body,
        if_match=run.etags[group["id"]],
        key=_new_key(),
    )
    problems = _expect_error(reply, 422, "invalid", "write with undeclared and read-only keys")
    answer = reply.json()
    listed = answer.get("errors") if isinstance(answer, dict) else None
    got = {(e.get("pointer"), e.get("code")) for e in listed or [] if isinstance(e, dict)}
    for pointer, code in sorted(expected - got):
        problems.append(f"field errors: no {code} at {pointer}")
    return problems


@dataclass(frozen=True)
class _Route:
    """One request of ``fresh-login`` or ``deletion-receipt``."""

    what: str
    method: str
    path: str
    body: object = None
    etag_of: str | None = None  # group whose current ETag goes into If-Match
    status: int = HTTP_OK
    answer: str = "delete_result"

    def send(self, run: _Run, name: str, token: str, key: str | None) -> _Reply:
        if_match = run.etags[self.etag_of] if self.etag_of is not None else None
        return run.call(
            name, self.method, self.path, token=token, body=self.body, if_match=if_match, key=key
        )


def _delete_all_routes(run: _Run) -> list[_Route]:
    return [
        _Route(f"delete_all of {gid}", "POST", f"{run.target.base}/{gid}/delete_all", etag_of=gid)
        for gid, group in run.groups.items()
        if group.get("delete_all") is True and gid in run.etags
    ]


def _category_routes(run: _Run, mode: str) -> list[_Route]:
    data = run.target.declaration.get("data")
    categories = data.get("categories", []) if isinstance(data, dict) else []
    body: Json = {} if mode == "self" else {"kind": "erasure"}
    status = HTTP_OK if mode == "self" else HTTP_ACCEPTED
    return [
        _Route(
            f"deleting category {c.get('id')}",
            "POST",
            str(c.get("erasure_endpoint")),
            body=body,
            status=status,
            answer="erasure_receipt",
        )
        for c in categories
        if isinstance(c, dict) and c.get("erasure") == mode
    ]


def _fresh_route(run: _Run) -> _Route | None:
    """A request that needs a fresh sign-in, the least destructive first."""
    try:
        group = _write_group(run, sensitive=True)
        gid = str(group["id"])
        return _Route(
            f"PUT {run.target.base}/{gid} (sensitive group)",
            "PUT",
            f"{run.target.base}/{gid}",
            body=_settings_body(run, group),
            etag_of=gid,
        )
    except _NotRunError:
        pass
    data = run.target.declaration.get("data")
    export = data.get("export") if isinstance(data, dict) else None
    classes = [g.get("data_class") for g in run.groups.values()]
    if isinstance(export, str) and any(
        c in data_classes.ids() and data_classes.compare(c, "personal") >= 0 for c in classes
    ):
        return _Route(f"GET {export} (export)", "GET", export)
    routes = _delete_all_routes(run) + _category_routes(run, "self")
    return routes[0] if routes else None


def _check_fresh_login(run: _Run) -> list[str]:
    if run.read is None:
        raise _NotRunError(_NO_READ)
    route = _fresh_route(run)
    if route is None:
        run.not_applicable.append(
            (
                "fresh-login",
                "no group, export, delete_all or category the person deletes needs a fresh sign-in",
            )
        )
        return []
    key = None if route.method == "GET" else _new_key()
    reply = route.send(run, f"fresh-login: {route.what}", run.token(STALE_AUTH_AGE), key)
    label = f"{route.what} with a sign-in older than {FRESH_MAX_AGE} s"
    problems = _expect_error(reply, 403, "step_up_required", label)
    answer = reply.json()
    max_age = answer.get("max_age") if isinstance(answer, dict) else None
    if not problems and (not isinstance(max_age, int) or not 0 <= max_age <= FRESH_MAX_AGE):
        problems.append(f"{label}: max_age missing or above {FRESH_MAX_AGE}")
    return problems


def _check_deletion_receipt(run: _Run) -> list[str]:
    if run.read is None:
        raise _NotRunError(_NO_READ)
    routes = (
        _delete_all_routes(run) + _category_routes(run, "self") + _category_routes(run, "request")
    )
    if not routes:
        run.not_applicable.append(
            ("deletion-receipt", "no delete_all and no category with a deletion route")
        )
        return []
    route, key = routes[0], _new_key()
    first = route.send(run, f"deletion-receipt: {route.what}", run.token(), key)
    problems = _expect_ok(first, route.status, route.answer, route.what)
    # The repeat carries the same If-Match and key, as a retry of the browser would.
    again = route.send(run, f"deletion-receipt: repeat of {route.what}", run.token(), key)
    if again.status != first.status or again.json() != first.json():
        problems.append(f"repeat of {route.what} with the same key: receipt differs from the first")
    return problems


_CHECKS: tuple[Callable[[_Run], list[str]], ...] = (
    _check_declaration,
    _check_unauthorized,
    _check_read,
    _check_precondition,
    _check_stale,
    _check_idempotency,
    _check_field_errors,
    _check_fresh_login,
    _check_deletion_receipt,
)


def _execute(run: _Run) -> list[Case]:
    group = run.target.catalog_id
    declaration = _check_declaration(run)
    cases = [case(SUITE, group, ME_V2_CHECKS[0], declaration)]
    for name, check in zip(ME_V2_CHECKS[1:], _CHECKS[1:], strict=True):
        if declaration:
            failures = [_DECLARATION_BROKEN]
        else:
            try:
                failures = check(run)
            except _NotRunError as exc:
                failures = [f"not run: {exc}" if not str(exc).startswith("not run") else str(exc)]
            except TransportError as exc:
                failures = [f"not run: {exc}"]
        cases.append(case(SUITE, group, name, failures))
    return cases


def run_me_v2_suite(target: MeTarget, *, http: Http | None = None) -> SuiteResult:
    """Run every check of the suite against the module API of ``target``."""
    started = time.monotonic()
    run = _Run(target, http or Http())
    cases = _execute(run)
    properties = tuple((f"not_applicable.{k}", v) for k, v in run.not_applicable)
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started, properties)


def record_me_v2_suite(
    target: MeTarget, provider: Provider, *, http: Http | None = None
) -> tuple[SuiteResult, bytes | None]:
    """Run the suite and record it; the recording only when every check passed."""
    started = time.monotonic()
    run = _Run(target, http or Http())
    cases = _execute(run)
    data: bytes | None = None
    failed = sum(1 for c in cases if not c.ok)
    if failed:
        problems = [f"not written: {failed} check(s) of the suite failed"]
    elif len(run.exchanges) > MAX_EXCHANGES:
        problems = [f"not written: {len(run.exchanges)} exchanges, at most {MAX_EXCHANGES}"]
    else:
        described: Json = {"catalog_id": target.catalog_id}
        if provider.image is not None:
            described["image"] = provider.image
        described["image_digest"] = provider.image_digest
        document = {
            "format": RECORDING_FORMAT,
            "kit_version": __version__,
            "suite": SUITE,
            "schema_version": schema_version(DECLARATION_SCHEMA),
            "provider": described,
            "recorded_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "exchanges": run.exchanges,
        }
        try:
            data = dump_recording(document, secrets=run.issued)
            problems = []
        except RecordingError as exc:
            problems = [f"not written: {problem}" for problem in exc.problems]
    cases.append(case(SUITE, target.catalog_id, RECORDING_CHECK, problems))
    properties = tuple((f"not_applicable.{k}", v) for k, v in run.not_applicable)
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started, properties), data
