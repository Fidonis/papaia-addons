"""Static suite: no generated code runs on the server, scopes and models come from the kit.

``papaia-kit conformance static`` reads the server code of a module (Python
through its syntax tree, JavaScript and TypeScript through a lexer, see
``static_js``) and reports:

- ``code-exec``: evaluation functions, dynamic imports, unsafe deserialization
  and subprocesses whose command is not a literal (PLT-63);
- ``query-build``: query text assembled from other text (PLT-63);
- ``scope-build``: an ``aud-`` scope built from strings instead of
  ``papaia_kit.names.exchange_scope`` (PLT-12);
- ``model-name``: a hard-coded model or provider name (PLT-41).

Each finding names the function or class it is in. A finding passes only
through an entry of the repository's ``static-exceptions.toml`` that names
that place (file, enclosing function or class, subject and how many findings
it holds), a reason, an expiry date and who approved it. Tests, examples,
dependencies and build output are not read; the suite counts what it leaves
out. See ``contract/conformance.md``.
"""

from __future__ import annotations

import ast
import os
import re
import time
import tomllib
from collections import Counter
from collections.abc import Iterable, Iterator, Sequence
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from pathlib import Path, PurePosixPath

from papaia_kit.conformance.result import SuiteResult, case
from papaia_kit.conformance.static_js import scan_script
from papaia_kit.conformance.static_patterns import (
    HOLE,
    MODEL,
    MODULE,
    SCOPE_PREFIX,
    Finding,
    TextBoundError,
    TextBudget,
    is_query,
)

__all__ = [
    "BUILD_DIRS",
    "DEPENDENCY_DIRS",
    "EXCEPTION_INPUTS",
    "SKIPPABLE_DIRS",
    "SKIP_REASONS",
    "STATIC_RULES",
    "TEST_DIRS",
    "Finding",
    "Sources",
    "StaticException",
    "StaticExceptionError",
    "collect_sources",
    "load_static_exceptions",
    "run_static",
    "scan_source",
]

SUITE = "static"
EXCEPTIONS_GROUP = "static-exceptions"
STATIC_RULES = ("code-exec", "query-build", "scope-build", "model-name")
# Where an excepted call takes its input from. A person, an event or a model is
# never an allowed source (PLT-63-A1), so the list has no value for them.
EXCEPTION_INPUTS = ("fixed", "operator-config")

MAX_SOURCE_BYTES = 2 * 1024 * 1024
MAX_EXCEPTIONS_BYTES = 64 * 1024
MAX_EXCEPTION_COUNT = 50
PY_SUFFIXES = frozenset({".py"})
JS_SUFFIXES = frozenset({".js", ".mjs", ".cjs", ".jsx", ".ts", ".mts", ".cts", ".tsx"})
# Directories that are not server code. Tests, examples and dependencies are
# left out at any depth; build output only directly under a path the suite is
# given, so that a server package named like it is still read. A module reads
# any of them with ``include_dirs`` (``--include-dir``), for example
# ``site-packages`` for the code installed into an image.
TEST_DIRS = frozenset({"tests", "test", "testing", "__tests__", "fixtures", "examples", "example"})
DEPENDENCY_DIRS = frozenset({"node_modules", "site-packages", "venv", "__pycache__"})
BUILD_DIRS = frozenset({"dist", "build"})
SKIPPABLE_DIRS = TEST_DIRS | DEPENDENCY_DIRS | BUILD_DIRS
# Why a file was not read; the suite reports the count per reason.
SKIP_REASONS = ("tests", "dependencies", "build-output", "generated", "hidden", "symlinks")
_TEST_FILE = re.compile(r"test_.*\.py|.*_test\.py|conftest\.py|.*\.(?:test|spec)\.[cm]?[jt]sx?")
_GENERATED_FILE = re.compile(r".*\.min\.[cm]?js|.*\.d\.[cm]?ts")
_PENDING = re.compile(r"\bpending\b", re.IGNORECASE)
_APPROVER = re.compile(r"\bsecurity officer\b", re.IGNORECASE)
_WITHIN = re.compile(r"<module>|[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*")

# Python callables, by the dotted name they are imported under.
_ALWAYS = frozenset(
    {
        "eval",
        "exec",
        "compile",
        "builtins.eval",
        "builtins.exec",
        "builtins.compile",
        "pickle.load",
        "pickle.loads",
        "marshal.load",
        "marshal.loads",
        "runpy.run_path",
        "runpy.run_module",
        "code.interact",
        "yaml.unsafe_load",
        "yaml.unsafe_load_all",
    }
)
_IMPORTS = frozenset(
    {"__import__", "builtins.__import__", "importlib.import_module", "importlib.__import__"}
)
_OS_PROCESS = (
    "system popen execl execle execlp execlpe execv execve execvp execvpe spawnl spawnle "
    "spawnlp spawnlpe spawnv spawnve spawnvp spawnvpe posix_spawn posix_spawnp startfile"
)
_SUBPROCESS = "run call check_call check_output Popen getoutput getstatusoutput"
_PROCESS = frozenset(
    [f"os.{n}" for n in _OS_PROCESS.split()]
    + [f"subprocess.{n}" for n in _SUBPROCESS.split()]
    + ["asyncio.create_subprocess_exec", "asyncio.create_subprocess_shell", "pty.spawn"]
)
_EVAL_NAMES = frozenset({"eval", "exec", "compile", "__import__"})
_RISKY_MODULES = frozenset({"builtins", "os", "subprocess", "importlib", "pickle", "marshal"})
_YAML_LOAD = frozenset({"yaml.load", "yaml.load_all"})
_SAFE_LOADERS = frozenset({"yaml.SafeLoader", "yaml.CSafeLoader", "yaml.BaseLoader"})
# Calls that send their first argument to a database as query text.
_QUERY_METHODS = frozenset(
    {"execute", "executemany", "executescript", "exec_driver_sql", "fetchrow", "fetchval", "raw"}
)
_QUERY_FUNCTIONS = frozenset(
    {"sqlalchemy.text", "sqlalchemy.sql.text", "sqlalchemy.sql.expression.text"}
)
# The kit's own scope prefix. Only the naming register defines it; importing or
# reading it elsewhere is the first step of building a scope outside
# ``exchange_scope()``.
_KIT_PREFIX_MODULES = frozenset({"papaia_kit.names.rules", "papaia_kit.names"})
_KIT_PREFIX = frozenset(f"{m}.AUD_PREFIX" for m in _KIT_PREFIX_MODULES)
_GETATTR = frozenset({"getattr", "builtins.getattr"})
# Mappings that hold the builtins, read by subscript (``builtins.__dict__["eval"]``)
# or with ``.get("eval")``.
_BUILTIN_MAPPINGS = frozenset({"builtins", "builtins.__dict__"})
_VARS = frozenset({"vars", "builtins.vars"})


class StaticExceptionError(ValueError):
    """The exception list cannot be used."""


@dataclass(frozen=True, slots=True)
class StaticException:
    rule: str
    path: str
    within: str
    subject: str
    input: str
    reason: str
    expires: date
    approved_by: str
    count: int = 1

    @property
    def key(self) -> tuple[str, str, str, str]:
        return self.rule, self.path, self.within, self.subject


@dataclass(frozen=True, slots=True)
class Sources:
    """The files the suite reads, and how many it left out per reason."""

    files: tuple[Path, ...]
    skipped: dict[str, int] = field(default_factory=dict)


# --- Python ------------------------------------------------------------------


def _aliases(tree: ast.AST) -> dict[str, str]:
    names: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.asname:
                    names[alias.asname] = alias.name
                else:
                    head = alias.name.split(".")[0]
                    names[head] = head
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            for alias in node.names:
                names[alias.asname or alias.name] = f"{node.module}.{alias.name}"
    return names


def _body_constants(bodies: Iterable[list[ast.stmt]]) -> dict[str, str]:
    """String constants assigned once in the statement lists, by name."""
    found: dict[str, str] = {}
    twice: set[str] = set()
    for body in bodies:
        for node in body:
            target, value = None, None
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target, value = node.targets[0], node.value
            elif isinstance(node, ast.AnnAssign):
                target, value = node.target, node.value
            if isinstance(target, ast.Name) and isinstance(value, ast.Constant):
                if target.id in found:
                    twice.add(target.id)
                if isinstance(value.value, str):
                    found[target.id] = value.value
    return {k: v for k, v in found.items() if k not in twice}


def _classes(tree: ast.Module) -> list[ast.ClassDef]:
    return [n for n in tree.body if isinstance(n, ast.ClassDef)]


def _constants(tree: ast.Module) -> dict[str, str]:
    """String constants assigned once at module or class level, by bare name."""
    return _body_constants([tree.body, *(c.body for c in _classes(tree))])


def _class_constants(tree: ast.Module) -> tuple[dict[str, dict[str, str]], dict[int, str]]:
    """String constants of each top-level class, and the class every node inside it belongs to."""
    constants: dict[str, dict[str, str]] = {}
    owners: dict[int, str] = {}
    for node in _classes(tree):
        constants[node.name] = _body_constants([node.body])
        owners.update((id(inner), node.name) for inner in ast.walk(node))
    return constants, owners


def _walk(tree: ast.AST) -> Iterator[tuple[ast.AST, str]]:
    """Every node with the dotted name of the function or class around it."""
    stack: list[tuple[ast.AST, str]] = [(tree, MODULE)]
    while stack:
        node, within = stack.pop()
        yield node, within
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef):
            within = node.name if within == MODULE else f"{within}.{node.name}"
        stack.extend((child, within) for child in reversed(list(ast.iter_child_nodes(node))))


def _dotted(node: ast.expr, aliases: dict[str, str]) -> str | None:
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if not isinstance(node, ast.Name):
        return None
    head = "builtins" if node.id == "__builtins__" else node.id
    return ".".join([aliases.get(node.id, head), *reversed(parts)])


def _is_literal(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, ast.List | ast.Tuple):
        return all(isinstance(e, ast.Constant) for e in node.elts)
    return False


class _Texts:
    """Literal text of Python expressions.

    String constants count as literal text: module and class constants by bare
    name, class constants through ``self``, ``cls`` or the class name inside
    that class, and the kit's scope prefix under any name it is imported as,
    read with ``getattr(rules, "AUD_PREFIX")`` (also with a name put together
    from literals) or taken in by a star import. Constant text pasted at its
    uses is bounded per file (``TextBudget``).
    """

    def __init__(self, tree: ast.Module, aliases: dict[str, str]) -> None:
        self.constants = _constants(tree)
        self.classes, self.owners = _class_constants(tree)
        self.aliases = aliases
        self.star_prefix = any(_imports_kit_prefix(n, "*") for n in ast.walk(tree))
        self.budget = TextBudget()

    def text(self, node: ast.expr) -> str | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.Name | ast.Attribute) and self.is_kit_prefix(node):
            return SCOPE_PREFIX
        if isinstance(node, ast.Call) and self.is_kit_getattr(node):
            return SCOPE_PREFIX
        value = None
        if isinstance(node, ast.Name):
            value = self.constants.get(node.id)
        elif isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
            owner = node.value.id
            if owner in {"self", "cls"}:
                owner = self.owners.get(id(node), "")
            value = self.classes.get(owner, {}).get(node.attr)
        return None if value is None else self.budget.spend(value)

    def static(self, node: ast.expr) -> str | None:
        """Text known before the code runs: ``text``, also joined with ``+`` or in an f-string."""
        if (text := self.text(node)) is not None:
            return text
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left, right = self.static(node.left), self.static(node.right)
            return None if left is None or right is None else left + right
        if isinstance(node, ast.JoinedStr):
            values = [self._value(v) for v in node.values]
            return None if None in values else "".join(v or "" for v in values)
        return None

    def is_kit_prefix(self, node: ast.Name | ast.Attribute) -> bool:
        if isinstance(node, ast.Name) and node.id not in self.aliases:
            return self.star_prefix and node.id == "AUD_PREFIX"
        return _dotted(node, self.aliases) in _KIT_PREFIX

    def is_kit_getattr(self, node: ast.Call) -> bool:
        """``getattr(rules, "AUD_PREFIX")`` on a module that holds the kit prefix."""
        return (
            _dotted(node.func, self.aliases) in _GETATTR
            and len(node.args) >= 2  # noqa: PLR2004 - getattr(object, name)
            and self.static(node.args[1]) == "AUD_PREFIX"
            and _dotted(node.args[0], self.aliases) in _KIT_PREFIX_MODULES
        )

    def piece(self, node: ast.expr) -> str:
        if (text := self.text(node)) is not None:
            return text
        if isinstance(node, ast.JoinedStr):
            return "".join(self._value(v) or HOLE for v in node.values)
        return HOLE

    def _value(self, node: ast.expr) -> str | None:
        """The text of one part of an f-string: literal text or a plain constant, else None."""
        if isinstance(node, ast.Constant):
            return self.text(node)
        if isinstance(node, ast.FormattedValue) and node.conversion == -1 and not node.format_spec:
            return self.text(node.value)
        return None

    def template(self, node: ast.expr) -> str | None:
        """The text of a string assembled at runtime, with a hole per runtime value, or None."""
        if isinstance(node, ast.JoinedStr):
            if all(self._value(v) is not None for v in node.values):
                return None
            return self.piece(node)
        if isinstance(node, ast.BinOp):
            return self._binop(node)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            return self._method(node, node.func)
        return None

    def _method(self, node: ast.Call, func: ast.Attribute) -> str | None:
        """``.format(...)``, ``.format_map({...})`` and ``sep.join([...])`` with a runtime value."""
        owner = self.text(func.value)
        if owner is None:
            return None
        if func.attr == "format" and (node.args or node.keywords):
            return self._format(owner, node.args, _named(node.keywords))
        if func.attr == "format_map" and len(node.args) == 1 and isinstance(node.args[0], ast.Dict):
            return self._format(owner, [], _entries(node.args[0]))
        items = _items(node.args[0]) if func.attr == "join" and len(node.args) == 1 else None
        if items is not None and any(self.text(e) is None for e in items):
            return owner.join(self.piece(e) for e in items)
        return None

    def _format(
        self, owner: str, args: list[ast.expr], named: list[tuple[str | None, ast.expr]]
    ) -> str | None:
        """``owner.format(...)`` with literal and constant arguments filled in.

        ``named`` holds the keyword arguments, with the entries of a dict display
        passed as ``**{...}`` or to ``format_map``; a name of None is a mapping
        known only at runtime.
        """
        values = [*args, *(value for _, value in named)]
        if all(self.text(v) is not None for v in values):
            return None
        if any(isinstance(a, ast.Starred) for a in args) or any(n is None for n, _ in named):
            return owner
        try:
            return owner.format(
                *(self.piece(a) for a in args),
                **{n: self.piece(v) for n, v in named if n is not None},
            )
        except (IndexError, KeyError, ValueError, AttributeError, TypeError):
            return owner

    def _percent(self, node: ast.BinOp) -> str | None:
        """``left % right`` with literal and constant values filled in."""
        left = self.text(node.left)
        if left is None:
            return None
        if isinstance(node.right, ast.Dict):
            return self._percent_mapping(left, node.right)
        values = node.right.elts if isinstance(node.right, ast.Tuple) else [node.right]
        if all(self.text(v) is not None for v in values):
            return None
        pieces = tuple(self.piece(v) for v in values)
        try:
            return left % (pieces if isinstance(node.right, ast.Tuple) else pieces[0])
        except (KeyError, ValueError, TypeError):
            return left

    def _percent_mapping(self, left: str, mapping: ast.Dict) -> str | None:
        """``"%(a)s" % {"a": ...}`` with literal and constant values filled in."""
        if all(self.text(v) is not None for v in mapping.values):
            return None
        keys = [k.value if isinstance(k, ast.Constant) else None for k in mapping.keys]
        if any(not isinstance(k, str) for k in keys):
            return left
        try:
            return left % {k: self.piece(v) for k, v in zip(keys, mapping.values, strict=True)}
        except (KeyError, ValueError, TypeError):
            return left

    def _binop(self, node: ast.BinOp) -> str | None:
        if isinstance(node.op, ast.Mod):
            return self._percent(node)
        if not isinstance(node.op, ast.Add):
            return None
        parts: list[ast.expr] = []
        pending: list[ast.expr] = [node]
        while pending:  # operands of a chain of ``+``, left to right
            current = pending.pop()
            if isinstance(current, ast.BinOp) and isinstance(current.op, ast.Add):
                pending += [current.right, current.left]
            else:
                parts.append(current)
        if all(self.text(p) is not None for p in parts):
            return None
        return "".join(self.piece(p) for p in parts)


def _entries(mapping: ast.Dict) -> list[tuple[str | None, ast.expr]]:
    """(key, value) of a dict display; the key is None unless it is a string literal."""
    return [
        (key.value if isinstance(key, ast.Constant) and isinstance(key.value, str) else None, value)
        for key, value in zip(mapping.keys, mapping.values, strict=True)
    ]


def _named(keywords: list[ast.keyword]) -> list[tuple[str | None, ast.expr]]:
    """Keyword arguments by name, a ``**{...}`` display taken apart into its entries."""
    named: list[tuple[str | None, ast.expr]] = []
    for keyword in keywords:
        if keyword.arg is None and isinstance(keyword.value, ast.Dict):
            named += _entries(keyword.value)
        else:
            named.append((keyword.arg, keyword.value))
    return named


def _items(node: ast.expr) -> list[ast.expr] | None:
    """The elements of a list or tuple, also of lists joined with ``+``; else None."""
    if isinstance(node, ast.List | ast.Tuple):
        return list(node.elts)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left, right = _items(node.left), _items(node.right)
        return None if left is None or right is None else left + right
    return None


def _imports_kit_prefix(node: ast.AST, name: str) -> bool:
    """``from papaia_kit.names.rules import <name>`` (or from ``papaia_kit.names``)."""
    return (
        isinstance(node, ast.ImportFrom)
        and node.module in _KIT_PREFIX_MODULES
        and any(alias.name == name for alias in node.names)
    )


def _builtin_lookup(mapping: ast.expr, key: ast.expr, aliases: dict[str, str]) -> str | None:
    """``builtins.eval`` when ``key`` names an evaluation function of a builtins mapping."""
    if not isinstance(key, ast.Constant) or key.value not in _EVAL_NAMES:
        return None
    if isinstance(mapping, ast.Call) and _dotted(mapping.func, aliases) in _VARS:
        mapping = mapping.args[0] if len(mapping.args) == 1 else mapping
    if _dotted(mapping, aliases) not in _BUILTIN_MAPPINGS:
        return None
    return f"builtins.{key.value}"


def _subscript_finding(node: ast.Subscript, aliases: dict[str, str]) -> tuple[str, str] | None:
    """``builtins.__dict__["eval"]``, ``vars(builtins)["eval"]`` and ``__builtins__["eval"]``."""
    target = _builtin_lookup(node.value, node.slice, aliases)
    return (target, f"{target} is looked up by subscript and runs code") if target else None


def _get_finding(node: ast.Call, aliases: dict[str, str]) -> tuple[str, str] | None:
    """``builtins.__dict__.get("eval")``, ``vars(builtins).get("eval")``, ``__builtins__.get``."""
    func = node.func
    if not isinstance(func, ast.Attribute) or func.attr != "get" or not node.args:
        return None
    target = _builtin_lookup(func.value, node.args[0], aliases)
    return (target, f"{target} is looked up with get() and runs code") if target else None


def _getattr_finding(node: ast.Call, aliases: dict[str, str]) -> tuple[str, str] | None:
    if len(node.args) < 2:  # noqa: PLR2004 - getattr(object, name)
        return None
    owner = _dotted(node.args[0], aliases)
    name = node.args[1]
    if isinstance(name, ast.Constant) and isinstance(name.value, str):
        target = f"{owner}.{name.value}" if owner else name.value
        if target in _ALWAYS | _IMPORTS | _PROCESS or (
            owner in _RISKY_MODULES and name.value in _EVAL_NAMES
        ):
            return target, f"{target} is looked up with getattr() and runs code"
        return None
    if owner in _RISKY_MODULES:
        return f"getattr({owner})", f"getattr({owner}, ...) looks up a callable named at runtime"
    return None


def _safe_loaders(tree: ast.Module, aliases: dict[str, str]) -> frozenset[str]:
    """The safe YAML loaders, with the module's own classes derived from one."""
    safe = set(_SAFE_LOADERS)
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and any(_dotted(b, aliases) in safe for b in node.bases):
            safe.add(node.name)
    return frozenset(safe)


def _call_finding(
    node: ast.Call, aliases: dict[str, str], safe_loaders: frozenset[str] = _SAFE_LOADERS
) -> tuple[str, str] | None:
    name = _dotted(node.func, aliases)
    if name is None:
        return None
    if name in _GETATTR:
        return _getattr_finding(node, aliases)
    if name in _ALWAYS:
        return name, f"{name}() evaluates code"
    if name in _YAML_LOAD:
        loader = next((k.value for k in node.keywords if k.arg == "Loader"), None)
        loader = loader or (node.args[1] if len(node.args) > 1 else None)
        if loader is None or _dotted(loader, aliases) not in safe_loaders:
            return name, f"{name}() without a safe loader can construct objects"
        return None
    return _runtime_finding(name, node)


def _runtime_finding(name: str, node: ast.Call) -> tuple[str, str] | None:
    """Imports and processes that take a module name or a command built at runtime."""
    args = [*node.args, *(k.value for k in node.keywords if k.arg in {"args", "name", "cmd"})]
    if name in _IMPORTS and not all(_is_literal(a) for a in args[:1] or [node.func]):
        return name, f"{name}() imports a module named at runtime"
    if name not in _PROCESS:
        return None
    if any(
        k.arg == "shell" and not (isinstance(k.value, ast.Constant) and not k.value.value)
        for k in node.keywords
    ):
        return name, f"{name}() runs a shell"
    if not args or not all(_is_literal(a) for a in args):
        return name, f"{name}() runs a command built at runtime"
    return None


def _query_sink(node: ast.Call, aliases: dict[str, str], texts: _Texts) -> bool:
    """A database call whose query text is assembled at runtime, whatever its shape."""
    if not node.args:
        return False
    method = node.func.attr if isinstance(node.func, ast.Attribute) else None
    if method not in _QUERY_METHODS and _dotted(node.func, aliases) not in _QUERY_FUNCTIONS:
        return False
    template = texts.template(node.args[0])
    # Query-shaped text is reported where it is assembled; this catches the rest.
    return template is not None and not is_query(template)


class _PythonScan:
    """The findings of one Python file, collected in one walk over its syntax tree."""

    def __init__(self, text: str, path: str) -> None:
        try:
            self.tree = ast.parse(text, filename=path)
        except MemoryError as exc:  # the parser's stack overflow on deep nesting
            raise SyntaxError(f"too complex to parse: {exc}") from None
        self.path = path
        self.aliases = _aliases(self.tree)
        self.texts = _Texts(self.tree, self.aliases)
        self.safe_loaders = _safe_loaders(self.tree, self.aliases)
        self.prose = {
            id(n.value)
            for n in ast.walk(self.tree)
            if isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)
        }
        # Parts of text already reported as assembled; they are not reported again.
        self.covered: set[int] = set()
        # The left operand of ``a + b`` when it is itself a ``+``: its text is the
        # start of the outer chain, so only the outer chain is read (linear time).
        self.links = {
            id(n.left)
            for n in ast.walk(self.tree)
            if isinstance(n, ast.BinOp)
            and isinstance(n.op, ast.Add)
            and isinstance(n.left, ast.BinOp)
            and isinstance(n.left.op, ast.Add)
        }
        self.findings: list[Finding] = []
        self.within = MODULE

    def add(self, node: ast.AST, rule: str, subject: str, message: str, offset: int = 0) -> None:
        line = getattr(node, "lineno", 0)
        column = getattr(node, "col_offset", 0) + offset
        self.findings.append(Finding(self.path, line, rule, subject, message, self.within, column))

    def run(self) -> list[Finding]:
        for node, within in _walk(self.tree):
            self.within = within
            self.statement(node)
            if (
                isinstance(node, ast.expr)
                and id(node) not in self.covered
                and id(node) not in self.links
            ):
                self.text(node)
        self.texts.budget.check()  # an overflow caught on the way still fails the file
        return self.findings

    def statement(self, node: ast.AST) -> None:
        """Imports of the kit prefix, calls that run code or queries, builtins by subscript."""
        if _imports_kit_prefix(node, "AUD_PREFIX") or _imports_kit_prefix(node, "*"):
            message = "imports the scope prefix; use exchange_scope()"
            self.add(node, "scope-build", SCOPE_PREFIX, message)
        if isinstance(node, ast.Call):
            hit = _call_finding(node, self.aliases, self.safe_loaders)
            if hit := hit or _get_finding(node, self.aliases):
                self.add(node, "code-exec", *hit)
            if _query_sink(node, self.aliases, self.texts):
                self.add(node, "query-build", "query", "query text built at runtime is run")
        if isinstance(node, ast.Subscript) and (hit := _subscript_finding(node, self.aliases)):
            self.add(node, "code-exec", *hit)

    def text(self, node: ast.expr) -> None:
        """Assembled query or scope text, the scope prefix and model names."""
        if (template := self.texts.template(node)) is not None:
            reported = False
            if is_query(template):
                self.add(node, "query-build", "query", "query text assembled at runtime")
                reported = True
            if template.startswith(SCOPE_PREFIX):
                self.add(node, "scope-build", SCOPE_PREFIX, "scope built from strings")
                reported = True
            if reported:
                self.covered.update(id(inner) for inner in ast.walk(node) if inner is not node)
        if (isinstance(node, ast.Attribute) and self.texts.is_kit_prefix(node)) or (
            isinstance(node, ast.Call) and self.texts.is_kit_getattr(node)
        ):
            message = "kit scope prefix; use exchange_scope()"
            self.add(node, "scope-build", SCOPE_PREFIX, message)
        if not isinstance(node, ast.Constant) or not isinstance(node.value, str):
            return
        if id(node) in self.prose:
            return
        if node.value == SCOPE_PREFIX:
            message = "bare scope prefix; use exchange_scope()"
            self.add(node, "scope-build", SCOPE_PREFIX, message)
        for match in MODEL.finditer(node.value):
            name = match.group(0)
            self.add(node, "model-name", name, f"hard-coded model name {name!r}", match.start())


def _scan_python(text: str, path: str) -> list[Finding]:
    return _PythonScan(text, path).run()


def scan_source(text: str, path: str) -> list[Finding]:
    """Findings in one source file, by line; ``SyntaxError`` for Python that does not parse."""
    suffix = PurePosixPath(path).suffix
    found = _scan_python(text, path) if suffix in PY_SUFFIXES else scan_script(text, path)
    # One finding per place: a rule and subject at one line and column.
    unique = {(f.line, f.column, f.rule, f.subject): f for f in found}
    return sorted(unique.values(), key=lambda f: (f.line, f.column, f.rule, f.subject))


# --- Files and exceptions --------------------------------------------------------


def _relative(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _is_code(name: str) -> bool:
    return PurePosixPath(name).suffix in PY_SUFFIXES | JS_SUFFIXES


def _count_code(directory: Path) -> int:
    return sum(
        1 for _current, _dirs, files in os.walk(directory) for name in files if _is_code(name)
    )


def collect_sources(paths: Iterable[Path], include_dirs: Iterable[str] = ()) -> Sources:
    """Server source files under the paths, and the files left out per reason."""
    included = frozenset(include_dirs)
    if unknown := sorted(included - SKIPPABLE_DIRS):
        raise ValueError(f"--include-dir {', '.join(unknown)}: not a skipped directory name")
    found: list[Path] = []
    skipped = Counter(dict.fromkeys(SKIP_REASONS, 0))
    for start in paths:
        if start.is_symlink() or not start.exists():
            raise ValueError(f"{start}: not a file or directory")
        if start.is_file():
            if _is_code(start.name):
                found.append(start)
            continue
        for current, dirs, files in os.walk(start):
            dirs[:] = _kept_dirs(Path(current), dirs, start, included, skipped)
            for name in sorted(files):
                path = Path(current) / name
                if not _is_code(name):
                    continue
                if path.is_symlink():
                    skipped["symlinks"] += 1
                elif _TEST_FILE.fullmatch(name):
                    skipped["tests"] += 1
                elif _GENERATED_FILE.fullmatch(name):
                    skipped["generated"] += 1
                else:
                    found.append(path)
    return Sources(tuple(found), dict(skipped))


def _kept_dirs(
    current: Path, dirs: list[str], start: Path, included: frozenset[str], skipped: Counter[str]
) -> list[str]:
    kept = []
    for name in sorted(dirs):
        reason = _skipped_dir(name, at_root=current == start, included=included)
        if (current / name).is_symlink():
            skipped["symlinks"] += 1
        elif reason:
            skipped[reason] += _count_code(current / name)
        else:
            kept.append(name)
    return kept


def _skipped_dir(name: str, *, at_root: bool, included: frozenset[str]) -> str | None:
    if name.startswith("."):
        return "hidden"
    if name in included:
        return None
    if name in TEST_DIRS:
        return "tests"
    if name in DEPENDENCY_DIRS:
        return "dependencies"
    if name in BUILD_DIRS and at_root:
        return "build-output"
    return None


def _string(entry: dict[str, object], key: str, low: int, high: int) -> str:
    value = entry.get(key)
    if not isinstance(value, str) or not low <= len(value) <= high:
        raise StaticExceptionError(f"{key} must be a string of {low} to {high} characters")
    if any(ord(c) < 32 or ord(c) == 127 for c in value):  # noqa: PLR2004 - control characters
        raise StaticExceptionError(f"{key} contains a control character")
    return value


def _exception(entry: object) -> StaticException:
    if not isinstance(entry, dict):
        raise StaticExceptionError("[[exception]] must be a table")
    fields = set(StaticException.__dataclass_fields__)
    if unknown := sorted(set(entry) - fields):
        raise StaticExceptionError(f"unknown field(s) {', '.join(unknown)}")
    if missing := sorted(fields - {"count"} - set(entry)):
        raise StaticExceptionError(f"missing field(s) {', '.join(missing)}")
    rule = _string(entry, "rule", 1, 40)
    if rule not in STATIC_RULES:
        raise StaticExceptionError(f"rule {rule!r} is not one of {', '.join(STATIC_RULES)}")
    path = _string(entry, "path", 1, 512)
    parts = PurePosixPath(path).parts
    if path.startswith("/") or "\\" in path or ".." in parts or "." in path.split("/"):
        raise StaticExceptionError(f"path {path!r} must be relative to the repository root")
    within = _string(entry, "within", 1, 200)
    if not _WITHIN.fullmatch(within):
        raise StaticExceptionError(
            f"within {within!r} must be {MODULE} or the dotted name of a function or class"
        )
    source = _string(entry, "input", 1, 40)
    if source not in EXCEPTION_INPUTS:
        raise StaticExceptionError(
            f"input {source!r} is not one of {', '.join(EXCEPTION_INPUTS)}; a value a person, "
            "an event or a model can feed is never an exception"
        )
    count = entry.get("count", 1)
    if isinstance(count, bool) or not isinstance(count, int):
        raise StaticExceptionError("count must be an integer")
    if not 1 <= count <= MAX_EXCEPTION_COUNT:
        raise StaticExceptionError(f"count must be between 1 and {MAX_EXCEPTION_COUNT}")
    expires = entry["expires"]
    if not isinstance(expires, date) or isinstance(expires, datetime):
        raise StaticExceptionError("expires must be a TOML date such as 2027-06-30")
    return StaticException(
        rule=rule,
        path=path,
        within=within,
        subject=_string(entry, "subject", 1, 200),
        input=source,
        reason=_string(entry, "reason", 20, 1000),
        expires=expires,
        approved_by=_string(entry, "approved_by", 3, 200),
        count=count,
    )


def _unapproved(entry: StaticException) -> bool:
    return bool(_PENDING.search(entry.approved_by)) or not _APPROVER.search(entry.approved_by)


def load_static_exceptions(
    path: Path | None, *, require_approved: bool = False
) -> tuple[StaticException, ...]:
    """Read ``static-exceptions.toml``; raises ``StaticExceptionError`` naming the file.

    With ``require_approved`` an entry whose ``approved_by`` does not name the
    security officer, or still says "pending", makes the list unusable (the
    check of the joint acceptance). This is a check of the wording only; the
    joint acceptance still reads every entry to confirm the countersignature.
    """
    if path is None:
        return ()
    try:
        data = path.read_bytes()
        if len(data) > MAX_EXCEPTIONS_BYTES:
            raise StaticExceptionError(f"larger than {MAX_EXCEPTIONS_BYTES} bytes")
        document = tomllib.loads(data.decode("utf-8"))
        if unknown := sorted(set(document) - {"version", "exception"}):
            raise StaticExceptionError(f"unknown key(s) {', '.join(unknown)}")
        if document.get("version") != 1:
            raise StaticExceptionError("version must be 1")
        entries = document.get("exception", [])
        if not isinstance(entries, list):
            raise StaticExceptionError("exception must be an array of tables")
        loaded = tuple(_exception(e) for e in entries)
        if require_approved and (pending := [" ".join(e.key) for e in loaded if _unapproved(e)]):
            raise StaticExceptionError(
                "approval pending (approved_by must name the security officer and must not "
                f"say pending) for: {'; '.join(pending)}"
            )
    except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError, StaticExceptionError) as exc:
        raise StaticExceptionError(f"{path}: {exc}") from exc
    keys = [e.key for e in loaded]
    if len(set(keys)) != len(keys):
        raise StaticExceptionError(f"{path}: an entry is listed twice")
    return loaded


def _rule_failures(
    rel: str,
    findings: Sequence[Finding],
    active: dict[tuple[str, str, str, str], StaticException],
    matched: Counter[tuple[str, str, str, str]],
) -> list[str]:
    """Failures of one file and rule; an exception covers at most its ``count`` findings."""
    by_key: dict[tuple[str, str, str, str], list[Finding]] = {}
    for finding in findings:
        by_key.setdefault((finding.rule, rel, finding.within, finding.subject), []).append(finding)
    failures: list[tuple[int, str]] = []
    for key, group in by_key.items():
        entry = active.get(key)
        if entry is not None:
            matched[key] += len(group)
            if len(group) <= entry.count:
                continue
        note = f" ({len(group)} found, {entry.count} excepted in {key[2]})" if entry else ""
        failures += [(f.line, f"{rel}:{f.line}: {f.message}{note}") for f in group]
    return [message for _, message in sorted(failures)]


def run_static(
    paths: Sequence[Path],
    *,
    root: Path,
    exceptions: Sequence[StaticException] = (),
    today: date | None = None,
    include_dirs: Iterable[str] = (),
) -> SuiteResult:
    """One case per file and rule, plus one per exception (expired, unused or miscounted fails).

    The result's properties count the files left out per reason (``skipped.<reason>``).
    """
    started = time.monotonic()
    today = today or datetime.now(UTC).date()
    sources = collect_sources(paths, include_dirs)
    if not sources.files:
        raise ValueError(f"no source files under {', '.join(str(p) for p in paths)}")
    active = {e.key: e for e in exceptions if e.expires >= today}
    matched: Counter[tuple[str, str, str, str]] = Counter()
    cases = []
    for path in sources.files:
        rel = _relative(path, root)
        try:
            data = path.read_bytes()
            if len(data) > MAX_SOURCE_BYTES:
                raise ValueError(f"larger than {MAX_SOURCE_BYTES} bytes")
            findings = scan_source(data.decode("utf-8"), rel)
        except (OSError, ValueError, SyntaxError, RecursionError, TextBoundError) as exc:
            cases.append(case(SUITE, rel, "load", [f"{rel}: cannot be checked: {exc}"]))
            continue
        for rule in STATIC_RULES:
            of_rule = [f for f in findings if f.rule == rule]
            cases.append(case(SUITE, rel, rule, _rule_failures(rel, of_rule, active, matched)))
    for entry in exceptions:
        problems = []
        found = matched[entry.key]
        if entry.expires < today:
            problems.append(f"expired on {entry.expires.isoformat()}; review it again or remove it")
        elif found == 0:
            problems.append("matches no finding; remove the entry")
        elif found < entry.count:
            problems.append(f"covers {entry.count} places but matches {found}; lower count")
        cases.append(case(SUITE, EXCEPTIONS_GROUP, " ".join(entry.key), problems))
    properties = tuple((f"skipped.{k}", str(sources.skipped[k])) for k in SKIP_REASONS)
    return SuiteResult(SUITE, tuple(cases), time.monotonic() - started, properties)
