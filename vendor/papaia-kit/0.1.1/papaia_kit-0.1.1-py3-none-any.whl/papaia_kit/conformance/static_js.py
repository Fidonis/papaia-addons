"""JavaScript and TypeScript scanner of the static suite.

A small lexer walks the whole file once and separates code from comments,
quoted strings, template literals (with their ``${...}`` holes, nested to any
depth) and regular expression literals, across lines. The rules then run on
the code with comments and string contents blanked out, and on the string
literals themselves. Line breaks are kept, so every finding names its line.

String constants declared by a ``const`` at file level (every declarator, any
type annotation, ``as const`` or ``satisfies T``, a ``+`` chain of literals and
earlier constants as the value) count as literal text where ``${NAME}``,
``+``, ``.concat(...)`` or ``[NAME, ...].join(...)`` uses them, so a scope or
query built from a constant is reported where it is built. A ``+`` chain is
read as one text with a hole per runtime value; its operands are literals,
constants, ``${...}`` templates (a literal or constant in a hole counts as
text), ``.concat(...)`` calls and ``[...].join(sep)`` with a literal or
constant separator, also inside grouping parentheses, so
``"aud" + ("-" + x)`` is one place. A chain that starts with a runtime value
is also read from each operand that starts a scope (``a + ("aud-" + b)``,
``a + `aud-${b}```, ``a + "aud-".concat(b)``, the bare prefix literal), and a
join that builds a scope is one place, not also its prefix element.

Every pass is linear in the size of the file, also on unbalanced or otherwise
invalid input: brackets and their top-level commas are matched once, an element
is read only up to its first token, the declarations of file-level constants
are read left to right without going back, and names of enclosing functions are
looked up only for findings. Constant text pasted at its uses is bounded per
file (``TextBudget``); a file over the bound fails ``load``.

Known limits: text between JSX tags is read as code (a quote in it opens a
string up to the end of the line), and a ``/`` after a closing parenthesis is
always read as division. A function header with a type annotation longer than
200 characters on the line before ``{`` is not named.
"""

from __future__ import annotations

import bisect
import re
from collections import Counter
from collections.abc import Iterable, Iterator
from dataclasses import dataclass, field

from papaia_kit.conformance.static_patterns import (
    MODEL,
    MODULE,
    SCOPE_PREFIX,
    Finding,
    TextBudget,
    text_hits,
)

# ``eval`` anywhere as a name: called, called optionally, or passed on as a value
# (``(0, eval)(x)``, ``const e = eval``), but not a property or object key.
_EVAL = re.compile(r"(?<![\w$.])eval(?![\w$])")
_KEY_BEFORE = frozenset("{,;")
_EXEC = (
    (
        re.compile(r"(?<![\w$.])(?:globalThis|window|self|global)\s*\??\.\s*eval(?![\w$])"),
        "eval",
    ),
    (
        re.compile(
            r"(?<![\w$.])(?:new\s+)?(?:(?:globalThis|window|self|global)\s*\??\.\s*)?"
            r"Function\s*(?:\?\.\s*)?\("
        ),
        "Function",
    ),
    (re.compile(r"(?<![\w$.])Function\s*\)\s*(?:\?\.\s*)?\("), "Function"),
    (re.compile(r"(?<![\w$.])import\s*\(\s*(?![\"'][^\"'`]*[\"']\s*[,)])"), "import()"),
    (re.compile(r"(?<![\w$.])require\s*\(\s*(?![\"'][^\"'`]*[\"']\s*\))"), "require()"),
    (re.compile(r"(?<![\w$.])set(?:Timeout|Interval|Immediate)\s*\(\s*[\"'`]"), "timer with text"),
)
_PROCESS_MODULE = re.compile(r"(?:node:)?(child_process|vm|worker_threads)")
_REGEX_AFTER = frozenset("(,=:[!&|?{};+-*%<>~^")
_REGEX_KEYWORDS = frozenset(
    [
        "return",
        "typeof",
        "case",
        "do",
        "else",
        "in",
        "of",
        "new",
        "delete",
        "void",
        "throw",
        "yield",
        "await",
        "instanceof",
    ]
)
_WORD = re.compile(r"[\w$]+")
_TEMPLATE_TEXT = re.compile(r"[^\\`$]+")
_NAME = r"[A-Za-z_$][\w$]*"
_BLOCK_NAMES = (
    re.compile(rf"\bclass\s+({_NAME})"),
    re.compile(rf"\bfunction\s*\*?\s*({_NAME})"),
    # Names start at a word boundary and return types are bounded to 200
    # characters, so no header is matched in quadratic time.
    re.compile(
        rf"(?<![\w$])({_NAME})\s*[:=]\s*(?:async\s+)?(?:function\b|(?:\([^()]*\)|{_NAME})\s*"
        rf"(?::[^=;{{}}]{{0,200}}?)?=>\s*$|\([^()]*$)"
    ),
    re.compile(
        r"(?:^|[\s;,}*])(?!(?:if|for|while|switch|catch|function|return|with)\b)"
        rf"({_NAME})\s*(?:<[^<>]*>)?\s*\([^()]*\)\s*(?::[^{{}}=;]{{0,200}})?$"
    ),
)
_CONTINUED_HEADER = re.compile(r"^[^(]*\)[^(]*$")
_CONST = re.compile(r"(?<![\w$.])const\s+")
# One declarator up to its ``=``, with a type annotation of one line and at most
# 200 characters (``=>`` of a function type is skipped); the bound keeps the
# scan linear.
_DECLARATOR = re.compile(rf"({_NAME})\s*(?::(?:=>|[^=;\n]){{0,200}}?)?=(?![=>])")
_IDENT = re.compile(_NAME)
# A name used as a value: not a property (``o.P``) and not part of a longer name.
_USE = re.compile(rf"(?<![\w$.]){_NAME}")
_TYPE_SUFFIX = re.compile(r"(?:as|satisfies)(?![\w$])")
_JOIN = re.compile(r"\]\s*\.\s*join\s*(\()")
_CONCAT = re.compile(r"\s*\.\s*concat\s*\(")
# A member access or call right after a value: the value is no operand of ``+``.
_MEMBER = re.compile(r"\s*(?:\?\.|[.\[(])")


@dataclass(slots=True)
class _Literal:
    start: int
    quote: str
    parts: list[str] = field(default_factory=lambda: [""])
    end: int = 0
    # Offsets of the code inside each ``${...}`` of a template literal.
    holes: list[tuple[int, int]] = field(default_factory=list)


@dataclass(slots=True)
class _Hole:
    """An open ``${`` of a template literal and the braces opened inside it."""

    literal: _Literal
    start: int
    depth: int = 0


class _Lexer:
    """Blanks comments and string contents in ``code``; collects the string literals."""

    def __init__(self, text: str) -> None:
        self.text = text
        self.code = list(text)
        self.literals: list[_Literal] = []
        self.open_holes: list[_Hole] = []
        self.last = ""

    def blank(self, start: int, end: int) -> None:
        for k in range(start, end):
            if self.code[k] != "\n":
                self.code[k] = " "

    def run(self) -> str:
        text, i = self.text, 0
        while i < len(text):
            c = text[i]
            if text.startswith("//", i):
                end = text.find("\n", i)
                end = len(text) if end < 0 else end
                self.blank(i, end)
                i = end
            elif text.startswith("/*", i):
                end = text.find("*/", i + 2)
                end = len(text) if end < 0 else end + 2
                self.blank(i, end)
                i = end
            elif c in "\"'":
                i = self._quoted(i)
            elif c == "`":
                literal = _Literal(i, "`")
                self.literals.append(literal)
                i = self._template(i + 1, literal)
            elif c == "/" and (
                not self.last or self.last in _REGEX_AFTER or self.last in _REGEX_KEYWORDS
            ):
                i = self._regex(i)
            elif c.isspace():
                i += 1
            elif match := _WORD.match(text, i):
                self.last = match.group()
                i = match.end()
            else:
                i = self._punctuator(i, c)
        return "".join(self.code)

    def _punctuator(self, i: int, c: str) -> int:
        if self.open_holes:
            hole = self.open_holes[-1]
            if c == "{":
                hole.depth += 1
            elif c == "}" and hole.depth == 0:
                self.open_holes.pop()
                hole.literal.holes.append((hole.start, i))
                self.blank(i, i + 1)
                return self._template(i + 1, hole.literal)
            elif c == "}":
                hole.depth -= 1
        self.last = c
        return i + 1

    def _quoted(self, i: int) -> int:
        text, quote, j = self.text, self.text[i], i + 1
        body: list[str] = []
        while j < len(text) and text[j] not in (quote, "\n"):
            step = 2 if text[j] == "\\" else 1
            body.append(text[j : j + step])
            j += step
        end = j + 1 if j < len(text) and text[j] == quote else j
        self.literals.append(_Literal(i, quote, ["".join(body)], end))
        self.blank(i + 1, min(j, len(text)))
        self.last = "string"
        return end

    def _template(self, j: int, literal: _Literal) -> int:
        text, start = self.text, j
        chunks: list[str] = []  # joined once, so a long template stays linear
        while j < len(text):
            if text[j] == "\\":
                chunks.append(text[j : j + 2])
                j += 2
            elif text[j] == "`":
                self.blank(start, j)
                literal.parts[-1] += "".join(chunks)
                literal.end = j + 1
                self.last = "string"
                return j + 1
            elif text.startswith("${", j):
                self.blank(start, j + 2)
                literal.parts[-1] += "".join(chunks)
                literal.parts.append("")
                self.open_holes.append(_Hole(literal, j + 2))
                self.last = "{"
                return j + 2
            else:
                chunk = _TEMPLATE_TEXT.match(text, j)
                end = chunk.end() if chunk else j + 1
                chunks.append(text[j:end])
                j = end
        self.blank(start, len(text))
        literal.parts[-1] += "".join(chunks)
        literal.end = len(text)
        return len(text)

    def _regex(self, i: int) -> int:
        text, j, in_class = self.text, i + 1, False
        while j < len(text) and text[j] != "\n":
            if text[j] == "\\":
                j += 2
                continue
            if text[j] == "/" and not in_class:
                break
            in_class = (in_class or text[j] == "[") and text[j] != "]"
            j += 1
        j = min(j, len(text))
        self.blank(i + 1, j)
        end = j + 1 if j < len(text) and text[j] == "/" else j
        while end < len(text) and text[end].isalpha():
            end += 1
        self.last = "regex"
        return end


def _block_name(header: str) -> str | None:
    best: tuple[int, str] | None = None
    for pattern in _BLOCK_NAMES:
        for match in pattern.finditer(header):
            if best is None or match.start(1) > best[0]:
                best = (match.start(1), match.group(1))
    return best[1] if best else None


@dataclass(frozen=True, slots=True)
class _Anchors:
    """Where the enclosing named function or class changes, as a tree of blocks.

    ``blocks`` holds (parent, name) of every named block, the file itself first;
    the dotted name of a block is put together only for a finding in it.
    """

    offsets: list[int]
    at: list[int]  # the innermost named block from each offset on
    blocks: list[tuple[int, str]]

    def within(self, offset: int) -> str:
        block = self.at[bisect.bisect_right(self.offsets, offset) - 1]
        names = []
        while block > 0:
            block, name = self.blocks[block]
            names.append(name)
        return ".".join(reversed(names)) or MODULE


def _anchors(code: str) -> _Anchors:
    blocks: list[tuple[int, str]] = [(-1, MODULE)]
    stack: list[tuple[int, str | None]] = []  # (innermost named block, own name) per brace
    offsets, at = [0], [0]
    boundary, closed = 0, None
    for match in re.finditer(r"[{};]", code):
        position = match.start()
        current = stack[-1][0] if stack else 0
        if match.group() == "{":
            header = code[boundary:position]
            name = _block_name(header)
            if name is None and closed is not None and _CONTINUED_HEADER.match(header):
                name = closed  # the body after a parameter list that held a type literal
            if name:
                blocks.append((current, name))
                current = len(blocks) - 1
            stack.append((current, name))
            closed = None
        elif match.group() == "}":
            closed = stack.pop()[1] if stack else None
            current = stack[-1][0] if stack else 0
        else:
            closed = None
        offsets.append(position + 1)
        at.append(current)
        boundary = position + 1
    return _Anchors(offsets, at, blocks)


def _next_code(code: str, position: int, step: int) -> str:
    while 0 <= position < len(code) and code[position].isspace():
        position += step
    return code[position] if 0 <= position < len(code) else ""


def _plus_at(code: str, k: int) -> bool:
    """Whether a binary ``+`` (not ``++`` or ``+=``) starts at the offset."""
    return code[k : k + 1] == "+" and code[k : k + 2] not in ("++", "+=")


def _depths(code: str) -> tuple[list[int], list[int]]:
    """Offsets of the braces of the code and the brace depth after each one."""
    offsets, depths, depth = [], [], 0
    for match in re.finditer(r"[{}]", code):
        depth += 1 if match.group() == "{" else -1
        offsets.append(match.start())
        depths.append(depth)
    return offsets, depths


def _skip(code: str, position: int) -> tuple[int, bool]:
    """The next offset that is not white space, and whether a line break was passed."""
    start = position
    while position < len(code) and code[position].isspace():
        position += 1
    return position, "\n" in code[start:position]


def _declarator_end(code: str, position: int) -> int:
    """Offset of the ``,``, ``;`` or line break that ends a declarator, outside brackets."""
    level = 0
    while position < len(code):
        c = code[position]
        if c in "([{":
            level += 1
        elif c in ")]}":
            if level == 0:
                break
            level -= 1
        elif level == 0 and c in ",;\n":
            break
        position += 1
    return position


def _initializer(
    code: str,
    position: int,
    literals: dict[int, _Literal],
    constants: dict[str, str],
    budget: TextBudget,
) -> tuple[str | None, int]:
    """The text of a ``+`` chain of literals and constants, and where the declarator ends.

    ``as const``, ``as T`` and ``satisfies T`` after the chain keep it a constant;
    any other value is a runtime value (None).
    """
    position, _ = _skip(code, position)
    value: list[str] = []
    while True:
        literal = literals.get(position)
        name = _IDENT.match(code, position)
        if literal is not None and len(literal.parts) == 1:
            value.append(literal.parts[0])
            after = literal.end
        elif name is not None and name.group() in constants:
            value.append(budget.spend(constants[name.group()]))
            after = name.end()
        else:
            return None, _declarator_end(code, position)
        following, broke = _skip(code, after)
        if code[following : following + 1] == "+" and _plus_at(code, following):
            position, _ = _skip(code, following + 1)
            continue
        break
    if _TYPE_SUFFIX.match(code, following):
        return "".join(value), _declarator_end(code, following)
    if broke or following >= len(code) or code[following] in ",;}":
        return "".join(value), following
    return None, _declarator_end(code, following)


def _constants(code: str, literals: dict[int, _Literal], budget: TextBudget) -> dict[str, str]:
    """String constants declared once by ``const`` at file level, by name.

    Every declarator of a ``const`` counts (``const A = "x", B = 1``), with any
    type annotation, and its value may be a ``+`` chain of literals and earlier
    constants, followed by ``as const`` or ``satisfies T``. Declarations are read
    left to right and a ``const`` inside text already read is skipped, so no
    stretch of code is read twice, even when a declarator runs to the end of the
    line or, with an unbalanced bracket, of the file.
    """
    offsets, depths = _depths(code)
    found: dict[str, str] = {}
    seen: Counter[str] = Counter()
    read_to = 0
    for match in _CONST.finditer(code):
        if match.start() < read_to:
            continue
        k = bisect.bisect_left(offsets, match.start())
        if k and depths[k - 1]:
            continue
        position = match.end()
        while declarator := _DECLARATOR.match(code, position):
            name = declarator.group(1)
            seen[name] += 1
            value, position = _initializer(code, declarator.end(), literals, found, budget)
            if value is not None:
                found[name] = value
            if code[position : position + 1] != ",":
                break
            position, _ = _skip(code, position + 1)
        read_to = position
    return {k: v for k, v in found.items() if seen[k] == 1}


@dataclass(frozen=True, slots=True)
class _Groups:
    """Matching brackets of the code, found in one pass."""

    opening: dict[int, int]  # offset of the opening bracket, by the closing one
    closing: dict[int, int]  # offset of the closing bracket, by the opening one
    commas: dict[int, list[int]]  # top-level commas inside, by the opening bracket

    def spans(self, open_at: int) -> list[tuple[int, int]]:
        """The element spans between a bracket pair, split at its top-level commas."""
        bounds = [open_at, *self.commas.get(open_at, []), self.closing[open_at]]
        return [(bounds[i] + 1, bounds[i + 1]) for i in range(len(bounds) - 1)]


def _groups(code: str) -> _Groups:
    opening: dict[int, int] = {}
    commas: dict[int, list[int]] = {}
    stack: list[int] = []
    for match in re.finditer(r"[\[\](){},]", code):
        c, position = match.group(), match.start()
        if c in "[({":
            stack.append(position)
            commas[position] = []
        elif c == ",":
            if stack:
                commas[stack[-1]].append(position)
        elif stack:
            opening[position] = stack.pop()
    return _Groups(opening, {o: c for c, o in opening.items()}, commas)


@dataclass(frozen=True, slots=True)
class _Scan:
    """The literals, constants and bracket groups of one file, shared by the text rules."""

    text: str
    code: str
    literals: dict[int, _Literal]
    constants: dict[str, str]
    groups: _Groups
    budget: TextBudget

    def constant(self, name: str) -> str | None:
        value = self.constants.get(name)
        return None if value is None else self.budget.spend(value)

    def grouping(self, open_at: int) -> bool:
        """Whether the ``(`` at the offset groups an expression (not a call or a header)."""
        k = open_at - 1
        while k >= 0 and self.code[k].isspace():
            k -= 1
        if k < 0 or not (self.code[k].isalnum() or self.code[k] in "_$)]"):
            return True
        end = k + 1
        while k >= 0 and (self.code[k].isalnum() or self.code[k] in "_$"):
            k -= 1
        return self.code[k + 1 : end] in _REGEX_KEYWORDS

    def opened(self, k: int) -> int:
        """The first offset from k on past white space and opening grouping parentheses."""
        while True:
            k, _ = _skip(self.code, k)
            if self.code[k : k + 1] == "(" and k in self.groups.closing and self.grouping(k):
                k += 1
                continue
            return k

    def closed(self, k: int) -> int:
        """The first offset from k on past white space and closing grouping parentheses."""
        while True:
            k, _ = _skip(self.code, k)
            o = self.groups.opening.get(k)
            if o is not None and self.code[o] == "(" and self.code[k] == ")" and self.grouping(o):
                k += 1
                continue
            return k

    def plus_before(self, k: int) -> bool:
        """Whether a binary ``+`` ends before k, past white space and grouping ``(``."""
        k -= 1
        while k >= 0 and (
            self.code[k].isspace()
            or (self.code[k] == "(" and k in self.groups.closing and self.grouping(k))
        ):
            k -= 1
        return k >= 0 and self.code[k] == "+" and (k == 0 or self.code[k - 1] != "+")


def _resolved(scan: _Scan, literal: _Literal) -> list[str]:
    """The pieces of a template literal; a literal or constant in a ``${...}`` is text."""
    pieces: list[list[str]] = [[literal.parts[0]]]
    for hole, after in zip(literal.holes, literal.parts[1:], strict=False):
        value = _static(scan, hole)
        if value is None:
            pieces.append([after])
        else:
            pieces[-1] += [value, after]
    return ["".join(piece) for piece in pieces]


def _static(scan: _Scan, span: tuple[int, int]) -> str | None:
    """The literal text of one element, argument or ``${...}``, or None for a runtime value.

    The work is bounded by the element's first token, so nested arrays stay linear.
    """
    start, end = span
    start, _ = _skip(scan.code, start)
    literal = scan.literals.get(start)
    if literal is not None and len(literal.parts) == 1:
        after, value = literal.end, literal.parts[0]
    elif (name := _IDENT.match(scan.code, start, end)) and name.group() in scan.constants:
        after, value = name.end(), name.group()
        if _skip(scan.code, after)[0] < end:
            return None
        return scan.constant(value)
    else:
        return None
    return value if _skip(scan.code, after)[0] >= end else None


def _concatenated(items: Iterable[list[str] | None]) -> list[str]:
    """Pieces of text put together from items; None is a runtime value (a hole)."""
    pieces: list[list[str]] = [[]]
    for item in items:
        if item is None:
            pieces.append([])
        else:
            pieces[-1].append(item[0])
            pieces.extend([p] for p in item[1:])
    return ["".join(piece) for piece in pieces]


def _arguments(scan: _Scan, open_at: int) -> list[list[str] | None]:
    """Literal text of each element between a bracket pair, None for a runtime value."""
    spans = scan.groups.spans(open_at)
    if len(spans) == 1 and _skip(scan.code, spans[0][0])[0] >= spans[0][1]:
        return []  # no elements at all
    return [None if (v := _static(scan, span)) is None else [v] for span in spans]


@dataclass(frozen=True, slots=True)
class _Atom:
    """An operand of ``+``: a literal, a constant, a ``.concat(...)`` or a ``[...].join(...)``."""

    start: int
    end: int
    items: list[list[str] | None]  # its own text, None for a runtime value
    constant: bool
    base: _Atom | None = None  # the operand a ``.concat(...)`` is called on

    def pieces(self) -> list[str]:
        """The text with holes; a ``.concat`` chain is put together once, from its base on."""
        parts: list[list[list[str] | None]] = []
        atom: _Atom | None = self
        while atom is not None:
            parts.append(atom.items)
            atom = atom.base
        return _concatenated(item for items in reversed(parts) for item in items)


def _joins(scan: _Scan, elements: set[int]) -> Iterator[_Atom]:
    """``[a, b].join(sep)`` with a literal or constant separator (``","`` when left out).

    The offsets of the literal elements of a join that is a scope on its own go
    into ``elements``: the join is the one place, not also its prefix element.
    """
    for match in _JOIN.finditer(scan.code):
        open_at = scan.groups.opening.get(match.start(), -1)
        call = match.start(1)
        if scan.code[open_at : open_at + 1] != "[" or call not in scan.groups.closing:
            continue
        separator = _arguments(scan, call)
        if separator == []:
            separator = [[","]]
        if len(separator) != 1 or (sep := separator[0]) is None:
            continue
        items = _arguments(scan, open_at)
        spaced = [x for item in items for x in (sep, item)][1:]
        joined = _concatenated(spaced)
        if joined[0].startswith(SCOPE_PREFIX) and (len(joined) > 1 or joined == [SCOPE_PREFIX]):
            elements.update(_skip(scan.code, start)[0] for start, _ in scan.groups.spans(open_at))
        yield _Atom(open_at, scan.groups.closing[call] + 1, spaced, False)


def _atoms(scan: _Scan, elements: set[int]) -> list[_Atom]:
    """Every operand, the calls ``.concat(...)`` on an operand included, in one list.

    ``elements`` receives the literal elements of joins that are a scope on their own.
    """
    atoms = [
        _Atom(literal.start, literal.end, [_resolved(scan, literal)], False)
        for literal in scan.literals.values()
    ]
    if scan.constants:
        for match in _USE.finditer(scan.code):
            if (value := scan.constant(match.group())) is not None:
                atoms.append(_Atom(match.start(), match.end(), [[value]], True))
    atoms.extend(_joins(scan, elements))
    for atom in atoms:  # grows while it is read: ``.concat(...).concat(...)``
        call = _CONCAT.match(scan.code, atom.end)
        if call is None or (call.end() - 1) not in scan.groups.closing:
            continue
        items = _arguments(scan, call.end() - 1)
        end = scan.groups.closing[call.end() - 1] + 1
        atoms.append(_Atom(atom.start, end, items, False, atom))
    return atoms


def _operand_scopes(
    scan: _Scan, chain: list[_Atom], before: bool, after: bool
) -> Iterator[tuple[int, list[str], bool]]:
    """Scopes that start at an operand inside a chain that does not start with one.

    ``a + ("aud-" + b)``, ``a + `aud-${b}``` and ``a + "aud-".concat(b)`` build a
    scope in an operand after a runtime value; the chain as a whole starts with
    that value. An operand counts when it opens a grouping parenthesis, holds a
    runtime value of its own (a template, ``.concat(...)`` or join) or is the
    bare prefix literal. Its text is read from the end of the chain backwards,
    keeping only the first few characters, so the work stays linear.
    """
    keep = len(SCOPE_PREFIX) + 1
    head, built = "", after
    starts: list[tuple[str, bool]] = []
    for atom in reversed(chain):
        pieces = atom.pieces()
        if len(pieces) > 1:
            head, built = pieces[0][:keep], True
        else:
            head = (pieces[0][:keep] + head)[:keep]
        starts.append((head, built))
    starts.reverse()
    for index, (atom, (text, has_hole)) in enumerate(zip(chain, starts, strict=True)):
        if index == 0 and not before:
            continue  # the chain itself starts here
        own = atom.pieces()
        grouped = _grouped_before(scan, atom.start)
        if not (grouped or len(own) > 1 or (own == [SCOPE_PREFIX] and not atom.constant)):
            continue
        if has_hole and text.startswith(SCOPE_PREFIX):
            yield atom.start, [text, ""], True
        elif not has_hole and (text == SCOPE_PREFIX or own == [SCOPE_PREFIX]):
            yield atom.start, [SCOPE_PREFIX], False


def _grouped_before(scan: _Scan, start: int) -> bool:
    """Whether a grouping ``(`` comes right before the offset, past white space."""
    k = start - 1
    while k >= 0 and scan.code[k].isspace():
        k -= 1
    return k >= 0 and scan.code[k] == "(" and k in scan.groups.closing and scan.grouping(k)


def _chains(
    scan: _Scan, atoms: list[_Atom], elements: set[int]
) -> Iterator[tuple[int, list[str], bool]]:
    """Operands joined with ``+``, taken as one text with holes for the rest.

    Grouping parentheses are looked through, so ``"aud" + ("-" + x)`` is one
    chain and one place; parentheses of a call are not. A chain that does not
    start with a scope is also read from each operand that starts one
    (``_operand_scopes``). A literal element of a join that is a scope on its
    own is not read again (``elements``).
    """
    operands = sorted(
        (atom for atom in atoms if not _MEMBER.match(scan.code, atom.end)),
        key=lambda atom: (atom.start, atom.end),
    )
    by_start = {atom.start: atom for atom in operands}  # the widest operand at each offset
    operands = list(by_start.values())
    following: dict[int, _Atom] = {}
    for atom in operands:
        k = scan.closed(atom.end)
        if _plus_at(scan.code, k) and (target := by_start.get(scan.opened(k + 1))) is not None:
            following[atom.start] = target
    linked = {atom.start for atom in following.values()}
    for head in operands:
        if head.start in linked:
            continue
        chain = [head]
        while (nxt := following.get(chain[-1].start)) is not None:
            chain.append(nxt)
        before = scan.plus_before(head.start)
        after = _plus_at(scan.code, scan.closed(chain[-1].end))
        alone = len(chain) == 1 and not (before or after)
        if alone and (head.constant or head.start in elements):
            # A constant used as a whole is reported where it is declared; a
            # join element where its join is.
            continue
        items = [None] * before + [atom.pieces() for atom in chain] + [None] * after
        pieces = _concatenated(items)
        yield head.start, pieces, len(pieces) > 1
        if not pieces[0].startswith(SCOPE_PREFIX):
            yield from _operand_scopes(scan, chain, before, after)


def _eval_names(code: str) -> Iterator[int]:
    """Offsets of ``eval`` used as a name, leaving out object keys (``{ eval: ... }``)."""
    for match in _EVAL.finditer(code):
        k = match.end()
        while k < len(code) and code[k].isspace():
            k += 1
        k += code[k : k + 1] == "?"
        if code[k : k + 1] == ":" and _next_code(code, match.start() - 1, -1) in _KEY_BEFORE:
            continue
        yield match.start()


def _hits(text: str, code: str, literals: list[_Literal]) -> Iterator[tuple[int, str, str, str]]:
    for start in _eval_names(code):
        yield start, "code-exec", "eval", "eval runs code given at runtime"
    for pattern, subject in _EXEC:
        for match in pattern.finditer(code):
            yield match.start(), "code-exec", subject, f"{subject} runs code given at runtime"
    for literal in literals:
        if literal.quote != "`" and (module := _PROCESS_MODULE.fullmatch(literal.parts[0])):
            name = module.group(1)
            yield literal.start, "code-exec", name, f"module {name} runs code or processes"
        for piece in literal.parts:
            for match in MODEL.finditer(piece):
                model = match.group(0)
                yield literal.start, "model-name", model, f"hard-coded model name {model!r}"
    by_start = {literal.start: literal for literal in literals}
    budget = TextBudget()
    constants = _constants(code, by_start, budget)
    scan = _Scan(text, code, by_start, constants, _groups(code), budget)
    elements: set[int] = set()
    atoms = _atoms(scan, elements)
    for start, pieces, built in _chains(scan, atoms, elements):
        for rule, subject, message in text_hits(
            pieces, built=built, exchange="exchangeScope", models=False
        ):
            yield start, rule, subject, message
    budget.check()


def scan_script(text: str, path: str) -> list[Finding]:
    """Findings in one JavaScript or TypeScript file."""
    lexer = _Lexer(text)
    code = lexer.run()
    breaks = [k for k, ch in enumerate(text) if ch == "\n"]
    anchors = _anchors(code)
    findings = []
    for offset, rule, subject, message in _hits(text, code, lexer.literals):
        line = bisect.bisect_left(breaks, offset)
        column = offset - (breaks[line - 1] + 1 if line else 0)
        within = anchors.within(offset)
        findings.append(Finding(path, line + 1, rule, subject, message, within, column))
    return findings
