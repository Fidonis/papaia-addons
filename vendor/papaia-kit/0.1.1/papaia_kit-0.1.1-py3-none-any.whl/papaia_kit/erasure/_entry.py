"""Journal entry format, input checks and the installation key."""

from __future__ import annotations

import hashlib
import hmac
import json
import re
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import ClassVar, NoReturn

JOURNAL_SCHEMA = "erasure-journal-entry.v1.schema.json"

MAX_LINE_BYTES = 4096
MAX_SEQ = 2**53 - 1  # exact in every JSON reader

_MODULE = re.compile(r"[a-z][a-z0-9-]{0,39}")
# An object reference names an object; it never carries content. Whitespace is
# refused so that free text cannot slip in as a reference.
_OBJECT_REF = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:@+#=-]{0,255}")
_REASON = re.compile(r"[a-z][a-z0-9_.-]{0,63}")
_SUBJECT_REF = re.compile(r"[0-9a-f]{64}")
_UUID4 = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}")
_AT = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z")
_CONTROL = re.compile(r"[\x00-\x1f\x7f-\x9f]")
_KEY_FILE = re.compile(rb"([0-9A-Fa-f]+)(?:\r?\n)?")
_MAX_SUB = 255


class JournalError(Exception):
    """Base class of every erasure journal error."""


class JournalCorruptError(JournalError):
    """A journal line is not a valid entry of the expected module."""


class JournalConflictError(JournalError):
    """Two entries share one sequence number, or one entry id differs between sources."""


class JournalGapError(JournalError):
    """A sequence number is missing between the applied state and the journal end."""


class JournalUnavailableError(JournalError):
    """The local copy (or a source that must be read) cannot be accessed."""


class Kind(StrEnum):
    """Entry kinds (sicherheit §4.9).

    ``erase`` removes one object, ``erase_subject`` every object of one person,
    ``delivery`` marks a reminder as delivered so that a restored reminder is not
    sent twice, ``revoke`` revokes a delegation at its holder again. The core
    sources write the account, role, session, credential and key kinds in the
    same format; :func:`kinds_for` names the kinds of each journal.
    """

    ERASE = "erase"
    ERASE_SUBJECT = "erase_subject"
    DELIVERY = "delivery"
    # revocation of a delegation at its holder; erasure-replay revokes it again
    REVOKE = "revoke"
    # core source "identity" (papaia-lifecycle), applied again by the core start gate
    ACCOUNT_DISABLE = "account_disable"
    ACCOUNT_DELETE = "account_delete"
    ROLE_REVOKE = "role_revoke"
    SESSION_REVOKE = "session_revoke"
    CREDENTIAL_RESET = "credential_reset"
    # core source "model-gateway": a virtual key revoked or rotated (key id only)
    KEY_REVOKE = "key_revoke"


IDENTITY_SOURCE = "identity"
CHAT_SOURCE = "core-chat"
GATEWAY_SOURCE = "model-gateway"
CORE_SOURCES = (IDENTITY_SOURCE, CHAT_SOURCE, GATEWAY_SOURCE)

_IDENTITY_KINDS = frozenset(
    {
        Kind.ACCOUNT_DISABLE,
        Kind.ACCOUNT_DELETE,
        Kind.ROLE_REVOKE,
        Kind.SESSION_REVOKE,
        Kind.CREDENTIAL_RESET,
    }
)
_KINDS_BY_SOURCE: dict[str, frozenset[Kind]] = {
    IDENTITY_SOURCE: _IDENTITY_KINDS,
    CHAT_SOURCE: frozenset({Kind.ERASE, Kind.ERASE_SUBJECT}),
    GATEWAY_SOURCE: frozenset({Kind.ERASE, Kind.ERASE_SUBJECT, Kind.KEY_REVOKE}),
}
_MODULE_KINDS = frozenset({Kind.ERASE, Kind.ERASE_SUBJECT, Kind.DELIVERY, Kind.REVOKE})


def kinds_for(module: str) -> frozenset[Kind]:
    """Kinds the journal of ``module`` may hold.

    The core sources ``identity``, ``core-chat`` and ``model-gateway`` hold the
    kinds the core start gate applies again; every other journal is a module's
    and holds ``erase``, ``erase_subject``, ``delivery`` and ``revoke``. A
    reader refuses a line of another kind, so an account or key entry cannot be
    planted in a module journal (or the other way round).
    """
    return _KINDS_BY_SOURCE.get(check_module(module), _MODULE_KINDS)


def check_module(module: object) -> str:
    if not isinstance(module, str) or not _MODULE.fullmatch(module):
        raise ValueError("module must match [a-z][a-z0-9-]{0,39}")
    return module


def check_kind(kind: object, module: str | None = None) -> Kind:
    checked: Kind | None = None
    if isinstance(kind, Kind):
        checked = kind
    elif isinstance(kind, str):
        checked = next((k for k in Kind if k.value == kind), None)
    if checked is None:
        raise ValueError("kind must be one of " + ", ".join(k.value for k in Kind))
    if module is not None and checked not in kinds_for(module):
        raise ValueError(f"kind {checked.value} is not allowed in the journal of {module}")
    return checked


def check_object_ref(object_ref: object) -> str:
    if not isinstance(object_ref, str) or not _OBJECT_REF.fullmatch(object_ref):
        raise ValueError("object_ref must be an identifier of 1 to 256 characters without spaces")
    return object_ref


def check_reason(reason: object) -> str:
    if not isinstance(reason, str) or not _REASON.fullmatch(reason):
        raise ValueError("reason must be a short code matching [a-z][a-z0-9_.-]{0,63}")
    return reason


def format_at(moment: datetime) -> str:
    if moment.tzinfo is None or moment.utcoffset() is None:
        raise ValueError("clock must return a timezone-aware datetime")
    utc = moment.astimezone(UTC)
    return f"{utc:%Y-%m-%dT%H:%M:%S}.{utc.microsecond // 1000:03d}Z"


class ErasureKey:
    """Installation key ``erasure-hmac``.

    The journal never holds a person's ``sub``; it holds
    ``subject_ref = HMAC-SHA256(key, sub)``. Without the key a reference cannot
    be linked to a person, not even by guessing over known subjects. The key
    lives in the encrypted backup, never next to the journal.
    """

    __slots__ = ("_key",)

    MIN_BYTES = 32
    MAX_BYTES = 1024

    def __init__(self, key: bytes) -> None:
        if not isinstance(key, bytes):
            raise TypeError("erasure key must be bytes")
        if not self.MIN_BYTES <= len(key) <= self.MAX_BYTES:
            raise ValueError("erasure key needs at least 32 bytes and at most 1024 bytes")
        self._key = key

    @classmethod
    def from_file(cls, path: Path) -> ErasureKey:
        """Read the key from a file secret.

        The file holds the key as hexadecimal text (at least 64 digits, so at
        least 32 bytes), optionally followed by one line break. Every component
        that reads ``erasure-hmac`` decodes it the same way; raw binary content
        is refused instead of being cut at a byte that looks like a line break.
        """
        match = _KEY_FILE.fullmatch(Path(path).read_bytes())
        if match is None or len(match.group(1)) % 2:
            raise ValueError("erasure key file must hold the key as hex text")
        digits = match.group(1)
        if not 2 * cls.MIN_BYTES <= len(digits) <= 2 * cls.MAX_BYTES:
            raise ValueError("erasure key file must hold 64 to 2048 hex digits")
        return cls(bytes.fromhex(digits.decode("ascii")))

    def subject_ref(self, sub: str) -> str:
        """The journal reference of ``sub``."""
        value: object = sub  # checked at run time: callers are not always typed
        if (
            not isinstance(value, str)
            or not 0 < len(value) <= _MAX_SUB
            or _CONTROL.search(value) is not None
        ):
            raise ValueError("subject must be 1 to 255 characters without control characters")
        return hmac.new(self._key, value.encode("utf-8"), hashlib.sha256).hexdigest()

    def matches(self, sub: str, subject_ref: str) -> bool:
        """Whether ``subject_ref`` belongs to ``sub`` (constant-time comparison)."""
        value: object = subject_ref
        if not isinstance(value, str) or not _SUBJECT_REF.fullmatch(value):
            return False
        return hmac.compare_digest(self.subject_ref(sub), value)

    def __repr__(self) -> str:
        return "ErasureKey(<redacted>)"

    __str__ = __repr__

    def __reduce__(self) -> NoReturn:
        raise TypeError("erasure key cannot be serialised")


@dataclass(frozen=True, slots=True)
class JournalEntry:
    """One journal line. It carries references only, never content.

    ``id`` identifies the entry; ``seq`` is its place in the journal. An entry
    handed out while the backup target was not usable may reach the target
    under a later ``seq`` (the local copy was older than the target); that line
    then carries ``provisional_seq``, the number first handed out.
    """

    FIELDS: ClassVar[tuple[str, ...]] = (
        "id",
        "module",
        "seq",
        "kind",
        "object_ref",
        "subject_ref",
        "at",
        "reason",
    )
    OPTIONAL: ClassVar[tuple[str, ...]] = ("provisional_seq",)

    id: str
    module: str
    seq: int
    kind: Kind
    object_ref: str
    subject_ref: str
    at: str
    reason: str
    provisional_seq: int | None = None

    def same_entry(self, other: JournalEntry) -> bool:
        """Whether both lines describe one entry, whatever ``seq`` they carry."""
        return replace(self, seq=0, provisional_seq=None) == replace(
            other, seq=0, provisional_seq=None
        )

    def to_line(self) -> str:
        record: dict[str, object] = {
            "id": self.id,
            "module": self.module,
            "seq": self.seq,
            "kind": self.kind.value,
            "object_ref": self.object_ref,
            "subject_ref": self.subject_ref,
            "at": self.at,
            "reason": self.reason,
        }
        if self.provisional_seq is not None:
            record["provisional_seq"] = self.provisional_seq
        return json.dumps(record, ensure_ascii=True, separators=(",", ":")) + "\n"

    @classmethod
    def from_record(cls, record: object, module: str) -> JournalEntry:
        """Validate one decoded line; unknown or missing fields are refused."""
        if not isinstance(record, dict):
            raise ValueError("entry is not an object")
        if set(record) - set(cls.OPTIONAL) != set(cls.FIELDS) or not set(record) <= set(
            cls.FIELDS + cls.OPTIONAL
        ):
            raise ValueError("entry has unknown or missing fields")
        if record["module"] != module:
            raise ValueError("entry belongs to another module")
        seq = record["seq"]
        if type(seq) is not int or not 0 < seq <= MAX_SEQ:
            raise ValueError("seq must be a positive integer")
        provisional_seq = record.get("provisional_seq")
        if "provisional_seq" in record and (
            type(provisional_seq) is not int
            or not 0 < provisional_seq <= MAX_SEQ
            or provisional_seq == seq
        ):
            raise ValueError("provisional_seq must be a positive integer other than seq")
        entry_id = record["id"]
        if not isinstance(entry_id, str) or not _UUID4.fullmatch(entry_id):
            raise ValueError("id must be a UUID v4")
        subject_ref = record["subject_ref"]
        if not isinstance(subject_ref, str) or not _SUBJECT_REF.fullmatch(subject_ref):
            raise ValueError("subject_ref must be 64 lower-case hex digits")
        at = record["at"]
        if not isinstance(at, str) or not _AT.fullmatch(at):
            raise ValueError("at must be a UTC timestamp with milliseconds")
        try:
            datetime.strptime(at, "%Y-%m-%dT%H:%M:%S.%fZ")  # pattern above fixes UTC
        except ValueError:
            raise ValueError("at is not a valid date") from None
        return cls(
            id=entry_id,
            module=module,
            seq=seq,
            kind=check_kind(record["kind"], module),
            object_ref=check_object_ref(record["object_ref"]),
            subject_ref=subject_ref,
            at=at,
            reason=check_reason(record["reason"]),
            provisional_seq=provisional_seq if type(provisional_seq) is int else None,
        )
