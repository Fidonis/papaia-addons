"""Replay of the journal into a restored module (module action ``erasure-replay``)."""

from __future__ import annotations

from collections import Counter
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from enum import StrEnum

from papaia_kit.erasure._entry import (
    JournalConflictError,
    JournalEntry,
    JournalError,
    JournalGapError,
)


class ReplayTrigger(StrEnum):
    """The only callers of ``erasure-replay``; no module replays on its own.

    ``restore`` and ``rollback`` of ``papaia-ctl`` (RE-06), ``recover-snapshot``
    after a state returned without ``restore`` and the core start gate through
    ``/internal/lifecycle`` (RE-65, RE-99).
    """

    RESTORE = "restore"
    ROLLBACK = "rollback"
    RECOVER_SNAPSHOT = "recover-snapshot"
    LIFECYCLE = "lifecycle"


class ReplayError(JournalError):
    """The handler failed; entries up to ``last_seq`` are applied."""

    def __init__(self, *, last_seq: int, failed_seq: int) -> None:
        super().__init__(f"replay stopped at seq {failed_seq}; applied up to seq {last_seq}")
        self.last_seq = last_seq
        self.failed_seq = failed_seq


@dataclass(frozen=True)
class ReplayResult:
    """Outcome for the audit event ``erasure_replayed`` and the operator output.

    ``replayed_from`` is the seq after which entries were applied: the module's
    applied seq, or lower when the journal holds an entry that was renumbered
    after that seq was handed out. ``journal_end`` is the highest seq in the
    journal; ``journal_behind`` flags a journal shorter than the module state
    (for example a target replaced by an older copy), for the audit event and
    ``doctor``.
    """

    trigger: ReplayTrigger
    applied: int
    last_seq: int
    by_kind: dict[str, int] = field(default_factory=dict)
    replayed_from: int = 0
    journal_end: int = 0

    @property
    def journal_behind(self) -> bool:
        return self.journal_end < self.last_seq


def replay(
    entries: Iterable[JournalEntry],
    *,
    applied_seq: int,
    handler: Callable[[JournalEntry], object],
    trigger: ReplayTrigger,
) -> ReplayResult:
    """Apply every entry after ``applied_seq`` in order.

    ``handler`` deletes the object (``erase``), every object of the person
    (``erase_subject``; resolve the person with :meth:`ErasureKey.matches`) or
    marks the reminder delivered (``delivery``). It must be idempotent and should
    store ``entry.seq`` as the module's applied seq in the same transaction.

    An entry delivered under a later seq than first handed out
    (``provisional_seq``) may have been stored by the module as its applied seq
    while the target held another entry under that number. If
    ``provisional_seq`` is not above ``applied_seq``, the run starts behind it,
    so that entry of the target applies too; handlers are idempotent.

    The run refuses to start when a seq between that start and the end of the
    journal is missing: a partial journal must not look complete.
    """
    if not isinstance(trigger, ReplayTrigger):
        raise TypeError("trigger must be a ReplayTrigger")
    if type(applied_seq) is not int or applied_seq < 0:
        raise ValueError("applied_seq must be a non-negative integer")

    ordered = sorted(entries, key=lambda e: e.seq)
    if len({e.module for e in ordered}) > 1:
        raise ValueError("entries of more than one module")
    for before, after in zip(ordered, ordered[1:], strict=False):
        if before.seq == after.seq and before != after:
            raise JournalConflictError(f"different entries for seq {after.seq}")

    start = min(
        [applied_seq]
        + [
            e.provisional_seq - 1
            for e in ordered
            if e.provisional_seq is not None and e.provisional_seq <= applied_seq
        ]
    )
    pending: list[JournalEntry] = []
    for entry in ordered:
        if entry.seq <= start or (pending and entry.seq == pending[-1].seq):
            continue
        expected = (pending[-1].seq if pending else start) + 1
        if entry.seq != expected:
            raise JournalGapError(f"journal is missing seq {expected}")
        pending.append(entry)

    kinds: Counter[str] = Counter()
    last_seq = start
    for entry in pending:
        try:
            handler(entry)
        except Exception as exc:
            raise ReplayError(last_seq=last_seq, failed_seq=entry.seq) from exc
        kinds[entry.kind.value] += 1
        last_seq = entry.seq
    return ReplayResult(
        trigger=trigger,
        applied=len(pending),
        last_seq=last_seq if pending else applied_seq,
        by_kind=dict(kinds),
        replayed_from=start,
        journal_end=ordered[-1].seq if ordered else 0,
    )
