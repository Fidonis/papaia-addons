"""Module code mapping and display texts after pattern 8 (interface spec 3.5)."""

from __future__ import annotations

import functools
import json
import re
from collections.abc import Collection, Mapping
from dataclasses import dataclass
from typing import Any

from papaia_kit._resources import contract_dir
from papaia_kit.errors._classes import (
    GENERIC_CODE,
    MODULE_PREFIXES,
    ErrorClass,
    is_well_formed_code,
)
from papaia_kit.errors._patterns import (
    CatalogError,
    find_forbidden_patterns,
    has_hidden_characters,
    read_yaml,
    require_keys,
)

LANGUAGES = ("de", "en")

# Placeholders a text may use, with the shape a value must have. Control,
# format and separator characters are rejected separately (has_hidden_characters).
_PLACEHOLDER_VALUE = {
    "contact": re.compile(r"[^{}]{1,120}"),
    "role": re.compile(r"[^{}]{1,60}"),
    "step": re.compile(r"[^{}]{1,80}"),
    "n": re.compile(r"[0-9]{1,4}"),
}
# Part 1 ("what") and part 2 ("todo") may only use placeholders that always
# have a default, so rendering a known code never fails. Consequence sentences
# may use the others; without a value they fall back (see consequence_text).
_DEFAULTED = frozenset({"contact", "role"})
_UNNAMED_SUFFIX = "_unnamed"
_PLACEHOLDER = re.compile(r"\{([a-z]+)\}")
_MAX_TEXT = 300

# One sentence: ends with ".", "!" or "?" (a closing quote may follow) and has
# no sentence end followed by further text inside. Part 1 ("what") and part 2
# ("todo") and every consequence sentence must be exactly one sentence, so a
# consequence can only reach part 1 by its id from the closed list.
_SENTENCE_END = re.compile(r"[.!?][\"“”»«’)]*$")
_INNER_SENTENCE_END = re.compile(r"[.!?][\"“”»«’)]*\s+\S")

# Register of the closed consequence list: the kit minor version in which each
# id was added. The list grows only with a kit minor version (RE-70).
REGISTER_FILE = "messages/consequences.register.json"
_CONSEQUENCE_ID = re.compile(r"[a-z][a-z0-9_]{0,47}")
_MINOR = re.compile(r"(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})")
_MAX_REGISTER_BYTES = 64 * 1024


@dataclass(frozen=True)
class CodeText:
    """Texts of one code in one language; ``consequence`` is a key of the consequence list."""

    what: str
    todo: str
    consequence: str | None = None


@dataclass(frozen=True)
class Catalog:
    generic_code: str
    classes: Mapping[str, ErrorClass]
    aliases: Mapping[str, str]
    texts: Mapping[str, Mapping[str, CodeText]]
    consequences: Mapping[str, Mapping[str, str]]
    titles: Mapping[str, Mapping[ErrorClass, str]]
    reference_label: Mapping[str, str]
    contact_default: Mapping[str, str]
    role_default: Mapping[str, str]
    review_roles: Mapping[str, Mapping[str, str]]
    class_codes: Mapping[ErrorClass, str]


@dataclass(frozen=True)
class DisplayText:
    """Message for a person: part 1 (what happened, consequence), part 2 (todo), part 3."""

    code: str
    what: str
    consequence: str | None
    todo: str
    reference: str

    @property
    def part1(self) -> str:
        return self.what if self.consequence is None else f"{self.what} {self.consequence}"

    def parts(self) -> tuple[str, str, str]:
        return (self.part1, self.todo, self.reference)


def _placeholders(text: str) -> set[str]:
    return set(_PLACEHOLDER.findall(text))


def _check_text(where: str, text: object, allowed: frozenset[str] | None = None) -> str:
    if not isinstance(text, str) or not text.strip() or len(text) > _MAX_TEXT:
        raise CatalogError(f"{where}: expected a non-empty text of at most {_MAX_TEXT} characters")
    if has_hidden_characters(text):
        raise CatalogError(f"{where}: control or format character")
    names = set(_PLACEHOLDER_VALUE) if allowed is None else allowed
    if unknown := _placeholders(text) - names:
        raise CatalogError(f"{where}: placeholders {sorted(unknown)} not allowed here")
    return text


def _is_one_sentence(text: str) -> bool:
    return bool(_SENTENCE_END.search(text)) and not _INNER_SENTENCE_END.search(text)


def _check_sentence(where: str, part: str, text: str) -> str:
    if not _is_one_sentence(text):
        raise CatalogError(f"{where}: {part} must be exactly one sentence")
    return text


def _invalid_value(key: str, value: object) -> str | None:
    """Why a placeholder value is rejected, or ``None`` when it is fine."""
    shape = _PLACEHOLDER_VALUE.get(key)
    if shape is None:
        return f"unknown placeholder {key!r}"
    if not isinstance(value, str) or not shape.fullmatch(value):
        return f"invalid value for placeholder {key!r}"
    if has_hidden_characters(value):
        return f"value for placeholder {key!r} contains a control or format character"
    if find_forbidden_patterns(value):
        return f"value for placeholder {key!r} contains a forbidden pattern"
    return None


def _check_value(where: str, key: str, value: object) -> str:
    if (reason := _invalid_value(key, value)) is not None:
        raise CatalogError(f"{where}: {reason}")
    assert isinstance(value, str)  # noqa: S101 - narrowed by _invalid_value
    return value


def _class_codes(classes: Mapping[str, ErrorClass]) -> dict[ErrorClass, str]:
    """First ``PK-`` code per class in file order: its texts stand for the class."""
    out: dict[ErrorClass, str] = {}
    for code, cls in classes.items():
        if code.startswith("PK-"):
            out.setdefault(cls, code)
    if missing := set(ErrorClass) - set(out):
        raise CatalogError(f"errors.yaml: no kit code for {sorted(c.value for c in missing)}")
    return out


def _load_mapping() -> tuple[str, dict[str, ErrorClass], dict[str, str]]:
    data = read_yaml("errors.yaml")
    require_keys("errors.yaml", data, {"version", "generic_code", "codes"}, {"aliases"})
    classes: dict[str, ErrorClass] = {}
    codes = data["codes"]
    if not isinstance(codes, dict) or not codes:
        raise CatalogError("errors.yaml: codes must be a non-empty mapping")
    for code, cls in codes.items():
        if not is_well_formed_code(code):
            raise CatalogError(f"errors.yaml: malformed code {code!r}")
        try:
            classes[code] = ErrorClass(cls)
        except ValueError as exc:
            raise CatalogError(f"errors.yaml: {code} has unknown class {cls!r}") from exc
    generic = data["generic_code"]
    if generic != GENERIC_CODE or classes.get(generic) is not ErrorClass.INTERNAL_ERROR:
        raise CatalogError(f"errors.yaml: generic_code must be {GENERIC_CODE} (internal_error)")
    aliases: dict[str, str] = {}
    for alias, target in (data.get("aliases") or {}).items():
        if not is_well_formed_code(alias) or alias in classes or target not in classes:
            raise CatalogError(f"errors.yaml: bad alias {alias!r} -> {target!r}")
        aliases[alias] = target
    return generic, classes, aliases


def _load_consequences(lang: str) -> dict[str, str]:
    name = f"messages/consequences.{lang}.yaml"
    data = read_yaml(name)
    require_keys(name, data, {"version", "lang", "consequences"}, set())
    if data["lang"] != lang or not isinstance(data["consequences"], dict):
        raise CatalogError(f"{name}: wrong language or no consequences")
    out: dict[str, str] = {}
    for key, value in data["consequences"].items():
        if not isinstance(key, str) or not _CONSEQUENCE_ID.fullmatch(key):
            raise CatalogError(f"{name}: malformed id {key!r}")
        out[key] = _check_sentence(
            f"{name} {key}", "a consequence", _check_text(f"{name} {key}", value)
        )
    for key in out:
        if key.endswith(_UNNAMED_SUFFIX) and key.removesuffix(_UNNAMED_SUFFIX) not in out:
            raise CatalogError(f"{name} {key}: no sentence it stands in for")
    return out


def _check_entry(where: str, entry: object, consequences: Mapping[str, str]) -> CodeText:
    """Texts of one code after pattern 8.

    Part 1 is one sentence (``what``) plus an optional ``consequence``, which
    must be an id of the closed list; free consequence text is rejected. Part 2
    (``todo``) is exactly one action as one sentence. Unknown fields are rejected.
    """
    require_keys(where, entry, {"what", "todo"}, {"consequence"})
    assert isinstance(entry, dict)  # noqa: S101 - narrowed by require_keys
    consequence = entry.get("consequence")
    if "consequence" in entry and not isinstance(consequence, str):
        raise CatalogError(f"{where}: consequence must be an id of the consequence list")
    if consequence is not None and consequence not in consequences:
        raise CatalogError(f"{where}: unknown consequence {consequence!r}")
    what = _check_text(where, entry["what"], _DEFAULTED)
    todo = _check_text(where, entry["todo"], _DEFAULTED)
    return CodeText(
        what=_check_sentence(where, "part 1", what),
        todo=_check_sentence(where, "part 2", todo),
        consequence=consequence,
    )


def _minor_key(minor: str) -> tuple[int, int]:
    major, _, rest = minor.partition(".")
    return int(major), int(rest)


def check_consequence_register(
    data: object, ids: Collection[str], kit_version: str
) -> dict[str, tuple[str, ...]]:
    """Validate the register of the consequence list; return ``{minor: ids}``.

    ``ids`` are the ids of the language files. Every id must be named exactly
    once, under the kit minor version (``"major.minor"``) that added it, and no
    minor may be later than ``kit_version``: an id for the next minor can only
    ship with that minor. Raises ``CatalogError``.
    """
    where = REGISTER_FILE
    require_keys(where, data, {"version", "minors"}, set())
    assert isinstance(data, dict)  # noqa: S101 - narrowed by require_keys
    if data["version"] != 1 or isinstance(data["version"], bool):
        raise CatalogError(f"{where}: expected version 1")
    minors = data["minors"]
    if not isinstance(minors, dict) or not minors:
        raise CatalogError(f"{where}: minors must be a non-empty mapping")
    kit = _MINOR.match(kit_version)
    if kit is None:
        raise CatalogError(f"{where}: malformed kit version {kit_version!r}")
    current = (int(kit.group(1)), int(kit.group(2)))
    out: dict[str, tuple[str, ...]] = {}
    seen: set[str] = set()
    for minor, listed in minors.items():
        if not isinstance(minor, str) or not _MINOR.fullmatch(minor):
            raise CatalogError(f"{where}: malformed minor {minor!r} (expected major.minor)")
        if _minor_key(minor) > current:
            raise CatalogError(
                f"{where}: minor {minor} is later than the kit version {kit_version}"
            )
        if not isinstance(listed, list) or not listed:
            raise CatalogError(f"{where}: minor {minor} must list at least one id")
        for item in listed:
            if not isinstance(item, str) or not _CONSEQUENCE_ID.fullmatch(item):
                raise CatalogError(f"{where}: malformed id {item!r} under {minor}")
            if item in seen:
                raise CatalogError(f"{where}: {item} is named more than once")
            seen.add(item)
        out[minor] = tuple(listed)
    if missing := set(ids) - seen:
        raise CatalogError(f"{where}: {sorted(missing)} not in the register")
    if extra := seen - set(ids):
        raise CatalogError(f"{where}: {sorted(extra)} not in the language files")
    return out


def _no_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in pairs:
        if key in out:
            raise CatalogError(f"{REGISTER_FILE}: key {key!r} appears twice")
        out[key] = value
    return out


def _load_register(ids: Collection[str]) -> dict[str, tuple[str, ...]]:
    from papaia_kit import __version__  # noqa: PLC0415 - the package imports this module

    path = contract_dir() / REGISTER_FILE
    if path.stat().st_size > _MAX_REGISTER_BYTES:
        raise CatalogError(f"{REGISTER_FILE}: larger than {_MAX_REGISTER_BYTES} bytes")
    try:
        data = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_no_duplicate_keys)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise CatalogError(f"{REGISTER_FILE}: not valid JSON") from exc
    return check_consequence_register(data, ids, __version__)


@dataclass(frozen=True)
class _LangTexts:
    texts: dict[str, CodeText]
    titles: dict[ErrorClass, str]
    reference_label: str
    contact_default: str
    role_default: str
    review_roles: dict[str, str]


def _load_texts(
    lang: str, classes: Mapping[str, ErrorClass], consequences: Mapping[str, str]
) -> _LangTexts:
    name = f"messages/codes.{lang}.yaml"
    data = read_yaml(name)
    require_keys(
        name,
        data,
        {
            "version",
            "lang",
            "reference_label",
            "contact_default",
            "role_default",
            "review_roles",
            "titles",
            "codes",
        },
        set(),
    )
    if data["lang"] != lang:
        raise CatalogError(f"{name}: lang is not {lang}")
    titles_raw = data["titles"]
    if not isinstance(titles_raw, dict) or set(titles_raw) != {c.value for c in ErrorClass}:
        raise CatalogError(f"{name}: titles must name every class exactly once")
    titles = {
        ErrorClass(k): _check_text(f"{name} title {k}", v, frozenset())
        for k, v in titles_raw.items()
    }
    codes_raw = data["codes"]
    if not isinstance(codes_raw, dict) or set(codes_raw) != set(classes):
        raise CatalogError(f"{name}: codes differ from errors.yaml")
    texts = {
        code: _check_entry(f"{name} {code}", entry, consequences)
        for code, entry in codes_raw.items()
    }
    roles_raw = data["review_roles"]
    if not isinstance(roles_raw, dict) or not set(roles_raw) <= set(MODULE_PREFIXES):
        raise CatalogError(f"{name}: review_roles must map module prefixes to roles")
    return _LangTexts(
        texts=texts,
        titles=titles,
        reference_label=_check_text(
            f"{name} reference_label", data["reference_label"], frozenset()
        ),
        contact_default=_check_value(name, "contact", data["contact_default"]),
        role_default=_check_value(name, "role", data["role_default"]),
        review_roles={str(k): _check_value(f"{name} {k}", "role", v) for k, v in roles_raw.items()},
    )


@functools.cache
def load_catalog() -> Catalog:
    """Mapping, texts and consequence sentences from ``contract/``, checked for completeness."""
    generic, classes, aliases = _load_mapping()
    consequences = {lang: _load_consequences(lang) for lang in LANGUAGES}
    if list(consequences["de"]) != list(consequences["en"]):
        raise CatalogError("consequence lists differ between languages")
    _load_register(consequences["de"])
    per_lang = {lang: _load_texts(lang, classes, consequences[lang]) for lang in LANGUAGES}
    return Catalog(
        generic_code=generic,
        classes=classes,
        aliases=aliases,
        texts={lang: t.texts for lang, t in per_lang.items()},
        consequences=consequences,
        titles={lang: t.titles for lang, t in per_lang.items()},
        reference_label={lang: t.reference_label for lang, t in per_lang.items()},
        contact_default={lang: t.contact_default for lang, t in per_lang.items()},
        role_default={lang: t.role_default for lang, t in per_lang.items()},
        review_roles={lang: t.review_roles for lang, t in per_lang.items()},
        class_codes=_class_codes(classes),
    )


def check_code_text(entry: object, *, lang: str = "de") -> CodeText:
    """Validate the texts of one module code against the message schema of pattern 8.

    ``entry`` has the shape of one item of ``codes.<lang>.yaml``: ``what``
    (part 1, one sentence), optional ``consequence`` (an id of the closed list
    in ``consequences.<lang>.yaml``; free text is rejected) and ``todo``
    (part 2, exactly one action). Raises ``CatalogError``; an unsupported
    ``lang`` raises ``ValueError``.
    """
    consequences = load_catalog().consequences[check_language(lang)]
    return _check_entry(f"code text ({lang})", entry, consequences)


def resolve_code(code: object) -> tuple[str, str, ErrorClass]:
    """``(code shown, code whose texts apply, class)`` for any input.

    A malformed code is replaced by the generic code; a well-formed code that
    the kit does not know keeps its name and gets the generic class and texts.
    """
    catalog = load_catalog()
    if not is_well_formed_code(code):
        return catalog.generic_code, catalog.generic_code, ErrorClass.INTERNAL_ERROR
    assert isinstance(code, str)  # noqa: S101 - narrowed by is_well_formed_code
    target = catalog.aliases.get(code, code)
    if target in catalog.classes:
        return code, target, catalog.classes[target]
    return code, catalog.generic_code, ErrorClass.INTERNAL_ERROR


def class_for_code(code: object) -> ErrorClass:
    """Class of a module code; unknown or malformed codes get ``internal_error``."""
    return resolve_code(code)[2]


def is_known_code(code: object) -> bool:
    """True for a code listed in ``errors.yaml`` or one of its aliases."""
    catalog = load_catalog()
    return isinstance(code, str) and (code in catalog.classes or code in catalog.aliases)


def check_language(lang: object) -> str:
    if lang not in LANGUAGES:
        raise ValueError(f"unsupported language {lang!r}")
    assert isinstance(lang, str)  # noqa: S101 - narrowed by the membership test
    return lang


def _fill(text: str, values: Mapping[str, str]) -> str:
    # One pass over the template: inserted values are never expanded again.
    return _PLACEHOLDER.sub(lambda m: values[m.group(1)], text)


def check_params(params: Mapping[str, object] | None) -> dict[str, str]:
    """Validate placeholder values strictly; raise ``ValueError`` on the first bad one.

    Placeholder values end up in text shown to people. They come from
    configuration (``branding.contact``, role names of the interface) or from
    names the person may see anyway (the name of a workflow step, a count);
    never from the content, title or owner of a source object (PLT-07-A2).
    Values with control, format, private-use or separator characters, braces
    or a forbidden pattern are rejected. Use this to check configuration at
    start-up; ``display_text`` and ``build_envelope`` drop bad values and fall
    back to the defaults instead of failing on the error path.
    """
    if params is None:
        return {}
    out: dict[str, str] = {}
    for key, value in params.items():
        if (reason := _invalid_value(key, value)) is not None:
            raise ValueError(reason)
        assert isinstance(value, str)  # noqa: S101 - narrowed by _invalid_value
        out[key] = value
    return out


def _values(lang: str, shown: str, params: Mapping[str, object] | None) -> dict[str, str]:
    """Defaults for contact and role, overridden by every valid given value."""
    catalog = load_catalog()
    module = shown.split("-", 1)[0]
    values = {
        "contact": catalog.contact_default[lang],
        "role": catalog.review_roles[lang].get(module, catalog.role_default[lang]),
    }
    for key, value in (params or {}).items():
        if _invalid_value(key, value) is None:
            assert isinstance(value, str)  # noqa: S101 - narrowed by _invalid_value
            values[key] = value
    return values


def consequence_text(lang: str, key: str, values: Mapping[str, str]) -> str | None:
    """Consequence sentence ``key`` filled from ``values``.

    Without a value for one of its placeholders the sentence falls back to
    ``<key>_unnamed`` if the list has it, and is left out otherwise.
    """
    sentences = load_catalog().consequences[check_language(lang)]
    for candidate in (key, key + _UNNAMED_SUFFIX):
        sentence = sentences.get(candidate)
        if sentence is not None and _placeholders(sentence) <= set(values):
            return _fill(sentence, values)
    return None


def render_text(
    shown: str,
    text_code: str,
    *,
    correlation_id: str,
    lang: str,
    params: Mapping[str, object] | None,
    with_code: bool,
) -> DisplayText:
    """Three-part message with the texts of ``text_code``, showing ``shown``."""
    lang = check_language(lang)
    catalog = load_catalog()
    values = _values(lang, shown, params)
    entry = catalog.texts[lang][text_code]
    consequence = (
        None if entry.consequence is None else consequence_text(lang, entry.consequence, values)
    )
    reference = f"{catalog.reference_label[lang]}: {correlation_id}"
    if with_code:
        reference = f"{shown} · {reference}"
    return DisplayText(
        code=shown,
        what=_fill(entry.what, values),
        consequence=consequence,
        todo=_fill(entry.todo, values),
        reference=reference,
    )


def display_text(
    code: object,
    *,
    correlation_id: str,
    lang: str = "de",
    params: Mapping[str, object] | None = None,
    with_code: bool = False,
) -> DisplayText:
    """Three-part message for a person (pattern 8) for a module code.

    ``correlation_id`` must already be valid (see ``normalize_correlation_id``).
    Bad or unknown ``params`` are dropped: ``{contact}`` falls back to
    ``contact_default``, ``{role}`` to the reviewer role of the code's module.
    Only an unsupported ``lang`` raises.
    """
    shown, text_code, _ = resolve_code(code)
    return render_text(
        shown,
        text_code,
        correlation_id=correlation_id,
        lang=lang,
        params=params,
        with_code=with_code,
    )
