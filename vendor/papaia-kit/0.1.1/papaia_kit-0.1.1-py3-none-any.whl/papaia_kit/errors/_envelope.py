"""Error envelope ``error.v1`` (architecture V-06) and the correlation id it carries."""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from papaia_kit.correlation import accept_correlation_id, is_valid_correlation_id
from papaia_kit.errors._catalog import (
    DisplayText,
    check_language,
    class_for_code,
    display_text,
    is_known_code,
    load_catalog,
    render_text,
    resolve_code,
)
from papaia_kit.errors._classes import CLASSES, ErrorClass, is_well_formed_code
from papaia_kit.errors._patterns import find_forbidden_patterns, has_hidden_characters

CONTENT_TYPE = "application/problem+json"
DEFAULT_RETRY_AFTER = 60
MAX_RETRY_AFTER = 86_400

_CONTRACT_CODE = re.compile(r"[A-Za-z0-9_.-]{1,64}")
_LIMITS = {"title": 120, "message": 400, "hint": 300}
_REQUIRED = (
    "type",
    "title",
    "status",
    "code",
    "class",
    "message",
    "hint",
    "correlation_id",
    "retryable",
)
_OPTIONAL = ("retry_after", "contract_code")


# The kit has one correlation id rule (papaia_kit.correlation, contract/audit.md):
# a missing, malformed or key-shaped value is replaced by a new UUIDv7, so an
# error body, its display text and the audit event carry the same valid id.
normalize_correlation_id = accept_correlation_id


@dataclass(frozen=True)
class ErrorEnvelope:
    type: str
    title: str
    status: int
    code: str
    error_class: ErrorClass
    message: str
    hint: str
    correlation_id: str
    retryable: bool
    retry_after: int | None = None
    contract_code: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """JSON body of a problem response, or ``error.data`` of an MCP error."""
        body: dict[str, Any] = {
            "type": self.type,
            "title": self.title,
            "status": self.status,
            "code": self.code,
            "class": self.error_class.value,
            "message": self.message,
            "hint": self.hint,
            "correlation_id": self.correlation_id,
            "retryable": self.retryable,
        }
        if self.retry_after is not None:
            body["retry_after"] = self.retry_after
        if self.contract_code is not None:
            body["contract_code"] = self.contract_code
        return body

    def http_headers(self) -> dict[str, str]:
        headers = {"Content-Type": CONTENT_TYPE}
        if self.retry_after is not None:
            headers["Retry-After"] = str(self.retry_after)
        return headers


def _check_retry_after(cls: ErrorClass, value: object) -> int | None:
    if value is None:
        if cls is ErrorClass.RATE_LIMITED:
            raise ValueError("rate_limited needs retry_after")
        return None
    if not CLASSES[cls].retryable:
        raise ValueError(f"{cls.value} is final and takes no retry_after")
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_RETRY_AFTER:
        raise ValueError(f"retry_after must be an integer from 1 to {MAX_RETRY_AFTER}")
    return value


def _check_contract_code(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not _CONTRACT_CODE.fullmatch(value):
        raise ValueError("contract_code is malformed")
    return value


def build_envelope(
    code: object,
    *,
    correlation_id: object,
    lang: str = "de",
    status: int | None = None,
    retry_after: int | None = None,
    contract_code: str | None = None,
    params: Mapping[str, object] | None = None,
) -> ErrorEnvelope:
    """Envelope for a module code; title, message and hint come from the catalog.

    The envelope never takes free text, so source content, credentials or raw
    server or model output cannot reach it. Bad ``params`` fall back to the
    defaults (see ``display_text``), so the error path does not fail on them.
    ``status`` defaults to the class default; ``retry_after`` defaults to
    ``DEFAULT_RETRY_AFTER`` for ``rate_limited``.
    """
    lang = check_language(lang)
    shown, _, cls = resolve_code(code)
    spec = CLASSES[cls]
    if status is None:
        status = spec.default_status
    elif isinstance(status, bool) or status not in spec.statuses:
        raise ValueError(f"status {status!r} is not allowed for {cls.value}")
    if retry_after is None and cls is ErrorClass.RATE_LIMITED:
        retry_after = DEFAULT_RETRY_AFTER
    cid = normalize_correlation_id(correlation_id)
    text = display_text(shown, correlation_id=cid, lang=lang, params=params)
    return ErrorEnvelope(
        type=cls.type_uri,
        title=load_catalog().titles[lang][cls],
        status=status,
        code=shown,
        error_class=cls,
        message=text.part1,
        hint=text.todo,
        correlation_id=cid,
        retryable=spec.retryable,
        retry_after=_check_retry_after(cls, retry_after),
        contract_code=_check_contract_code(contract_code),
    )


def _text(body: Mapping[str, Any], key: str) -> str:
    value = body[key]
    if not isinstance(value, str) or not value or len(value) > _LIMITS[key]:
        raise ValueError(f"{key} must be a non-empty text of at most {_LIMITS[key]} characters")
    if has_hidden_characters(value):
        raise ValueError(f"{key} contains a control or format character")
    if find_forbidden_patterns(value):
        raise ValueError(f"{key} contains a forbidden pattern")
    return value


def parse_envelope(body: object) -> ErrorEnvelope:
    """Validate a received envelope strictly.

    Same rules as ``error.v1.schema.json``, plus what a schema cannot express:
    ``title``, ``message`` and ``hint`` must pass the forbidden patterns, and a
    code the kit knows must carry its class. A well-formed unknown code may
    carry any class. Even so, show a person only ``display_text_for(envelope)``,
    never the received texts.
    """
    if not isinstance(body, Mapping):
        raise ValueError("error envelope must be a JSON object")
    keys = set(body)
    if missing := set(_REQUIRED) - keys:
        raise ValueError(f"error envelope misses {sorted(missing)}")
    if unknown := keys - set(_REQUIRED) - set(_OPTIONAL):
        raise ValueError(f"error envelope has unknown fields {sorted(unknown)}")
    try:
        cls = ErrorClass(body["class"])
    except ValueError as exc:
        raise ValueError("unknown error class") from exc
    spec = CLASSES[cls]
    if body["type"] != cls.type_uri:
        raise ValueError("type does not match class")
    status = body["status"]
    if isinstance(status, bool) or not isinstance(status, int) or status not in spec.statuses:
        raise ValueError(f"status is not allowed for {cls.value}")
    if body["retryable"] is not spec.retryable:
        raise ValueError(f"retryable must be {spec.retryable} for {cls.value}")
    code = body["code"]
    if not is_well_formed_code(code):
        raise ValueError("code is malformed")
    if is_known_code(code) and class_for_code(code) is not cls:
        raise ValueError("class does not match code")
    cid = body["correlation_id"]
    if not is_valid_correlation_id(cid):
        raise ValueError("correlation_id is malformed")
    return ErrorEnvelope(
        type=cls.type_uri,
        title=_text(body, "title"),
        status=status,
        code=code,
        error_class=cls,
        message=_text(body, "message"),
        hint=_text(body, "hint"),
        correlation_id=cid,
        retryable=spec.retryable,
        retry_after=_check_retry_after(cls, body.get("retry_after")),
        contract_code=_check_contract_code(body.get("contract_code")),
    )


def display_text_for(
    envelope: ErrorEnvelope,
    *,
    lang: str = "de",
    params: Mapping[str, object] | None = None,
    with_code: bool = False,
) -> DisplayText:
    """Three-part message for a received envelope, rebuilt from code and class.

    This is the only way to show a received error to a person: ``title``,
    ``message`` and ``hint`` of the envelope are discarded. A code the kit
    knows gets its own texts; a well-formed unknown code gets the texts of the
    kit code of its class.
    """
    catalog = load_catalog()
    shown, text_code, _ = resolve_code(envelope.code)
    if not is_known_code(envelope.code):
        text_code = catalog.class_codes[envelope.error_class]
    return render_text(
        shown,
        text_code,
        correlation_id=normalize_correlation_id(envelope.correlation_id),
        lang=lang,
        params=params,
        with_code=with_code,
    )
