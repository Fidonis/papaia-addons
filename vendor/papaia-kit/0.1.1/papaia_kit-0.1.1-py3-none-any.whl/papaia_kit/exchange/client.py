"""The token exchange client (architecture V-13, security 1.4 and 1.5)."""

from __future__ import annotations

import hashlib
import http.client
import logging
import re
import threading
import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field, replace
from typing import Final
from urllib.parse import urlsplit

from papaia_kit.errors import CLASSES, ErrorClass, normalize_correlation_id
from papaia_kit.exchange._jwt import MAX_TOKEN_LENGTH, parse_json_object, unverified_claims
from papaia_kit.exchange.auth import ClientSecret, PrivateKeyJwt
from papaia_kit.exchange.transport import Transport, UrllibTransport
from papaia_kit.names import InvalidClaims, InvalidName, Kind, exchange_scope, lookup, person_id
from papaia_kit.names import validate as validate_name

log = logging.getLogger("papaia_kit.exchange")

GRANT_TYPE: Final = "urn:ietf:params:oauth:grant-type:token-exchange"
ACCESS_TOKEN_TYPE: Final = "urn:ietf:params:oauth:token-type:access_token"  # noqa: S105 - a URN
CORRELATION_HEADER: Final = "X-Papaia-Correlation-Id"
ORIGIN_HEADER: Final = "X-Papaia-Origin-Azp"
# An exchanged token is handed out of the cache only while at least this much
# of its lifetime is left, so the call that uses it does not race its expiry.
CACHE_MARGIN: Final = 10
MAX_TIMEOUT: Final = 60.0
_MAX_ENDPOINT = 2048
_MAX_SUB = 255
_SHOWN = re.compile(r"[a-z0-9-]{1,64}")
_OK = 200
_RESPONSE_FIELDS = frozenset(
    {
        "access_token",
        "expires_in",
        "token_type",
        "issued_token_type",
        "scope",
        "not-before-policy",
        "session_state",
        "refresh_expires_in",
    }
)
# Refusals of the issuer that mean the subject token is not active: the session
# was ended, the account revoked (security 1.12) or the token is not genuine.
# Which code Keycloak returns for which case is confirmed against the kit test
# issuer (KIT-015).
_REVOKED_ERRORS = frozenset({"invalid_token", "invalid_grant"})


class ExchangeError(Exception):
    """A token exchange that did not produce a token.

    ``error_class`` is one of the error classes of the error envelope
    (architecture V-06, ``papaia_kit.errors``); ``status`` and ``retryable``
    follow that class; ``reason`` says why in one machine-readable word.
    Neither the message nor any attribute carries a token value.
    """

    def __init__(
        self, error_class: ErrorClass, reason: str, *, audience: str | None, correlation_id: str
    ) -> None:
        spec = CLASSES[error_class]
        self.error_class = error_class
        self.reason = reason
        self.status = spec.default_status
        self.retryable = spec.retryable
        self.audience = audience
        self.correlation_id = correlation_id
        super().__init__(
            f"token exchange for audience {audience!r} failed: {error_class} ({reason}), "
            f"correlation id {correlation_id}"
        )


class _Refused(Exception):  # noqa: N818 - internal signal, turned into ExchangeError
    def __init__(self, error_class: ErrorClass, reason: str) -> None:
        super().__init__(reason)
        self.error_class = error_class
        self.reason = reason


@dataclass(frozen=True, slots=True)
class ExchangedToken:
    """An access token for exactly one audience."""

    access_token: str = field(repr=False)
    audience: str
    sub: str = field(repr=False)
    expires_at: float
    correlation_id: str
    # Client that sent the received token in a chain exchange; information only.
    origin_azp: str | None = None

    def __str__(self) -> str:
        return f"<exchanged token for {self.audience}>"

    def headers(self) -> dict[str, str]:
        """Request headers for the call to the audience."""
        result = {
            "Authorization": f"Bearer {self.access_token}",
            CORRELATION_HEADER: self.correlation_id,
        }
        if self.origin_azp is not None:
            result[ORIGIN_HEADER] = self.origin_azp
        return result


@dataclass(frozen=True, slots=True)
class _Entry:
    subject_digest: bytes
    token: ExchangedToken
    usable_until: float


def _endpoint(url: object) -> str:
    if not isinstance(url, str):
        raise TypeError("token_endpoint must be a string")
    parts = urlsplit(url)
    if (
        len(url) > _MAX_ENDPOINT
        or parts.scheme not in ("http", "https")
        or not parts.hostname
        or parts.username is not None
        or parts.password is not None
        or parts.query
        or parts.fragment
    ):
        raise ValueError("token_endpoint must be an http(s) URL without credentials or query")
    return url


def _single_aud(aud: object) -> str | None:
    if isinstance(aud, str):
        return aud
    if isinstance(aud, list) and len(aud) == 1 and isinstance(aud[0], str):
        return aud[0]
    return None


def _int_claim(claims: Mapping[str, object], name: str) -> int | None:
    value = claims.get(name)
    return value if type(value) is int else None


class ExchangeClient:
    """RFC 8693 token exchange with exactly one audience per token.

    Each request asks for ``audience=<a>`` and ``scope=aud-<a>``. A received
    token (``azp`` is another client) is exchanged only for an audience the
    client declares in ``downstream``; only a client that is itself an audience
    (the chain holder) may declare one, and the chain holder exchanges received
    tokens only, never its own. Exchanged tokens are cached per person (``sub``)
    and audience, bound to the subject token, and never beyond their lifetime.

    ``subject_token`` must be a token the caller has verified
    (``papaia_kit.authz``) or obtained from its own sign-in; the client reads its
    claims without verifying the signature.
    """

    def __init__(
        self,
        *,
        token_endpoint: str,
        client_id: str,
        auth: PrivateKeyJwt | ClientSecret,
        downstream: Iterable[str] = (),
        transport: Transport | None = None,
        clock: Callable[[], float] = time.time,
        timeout: float = 10.0,
        max_entries: int = 10_000,
    ) -> None:
        self._endpoint = _endpoint(token_endpoint)
        self._client_id = self._exchanging_client(client_id)
        if not isinstance(auth, PrivateKeyJwt | ClientSecret):
            raise TypeError("auth must be PrivateKeyJwt or ClientSecret")
        self._auth = auth
        # Policy data-chain of the realm applies to every exchange of the chain
        # holder, so it never exchanges a token of its own (security 1.5 no. 2/3).
        self._chain_holder = lookup(self._client_id, Kind.AUDIENCE) is not None
        self._downstream = self._declared(downstream)
        if isinstance(timeout, bool) or not isinstance(timeout, int | float):
            raise TypeError("timeout must be a number")
        if not 0 < timeout <= MAX_TIMEOUT:
            raise ValueError(f"timeout must be within (0, {MAX_TIMEOUT}] seconds")
        if type(max_entries) is not int or max_entries < 1:
            raise ValueError("max_entries must be a positive integer")
        self._timeout = float(timeout)
        self._max_entries = max_entries
        self._transport: Transport = transport if transport is not None else UrllibTransport()
        self._clock = clock
        self._cache: dict[tuple[str, str], _Entry] = {}
        self._lock = threading.Lock()
        if isinstance(auth, ClientSecret):
            log.warning(
                "token exchange client %s authenticates with a client secret; "
                "private_key_jwt replaces it once proven",
                self._client_id,
            )

    @staticmethod
    def _exchanging_client(client_id: object) -> str:
        if not isinstance(client_id, str):
            raise TypeError("client_id must be a string")
        validate_name(client_id, Kind.CLIENT)
        if client_id.startswith("svc-") or lookup(client_id, Kind.SERVICE_ACCOUNT):
            raise ValueError(f"{client_id!r} is a service account; it does not exchange tokens")
        entry = lookup(client_id, Kind.CLIENT)
        if entry is not None and not entry.token_exchange:
            raise ValueError(f"client {client_id!r} has no token exchange")
        return client_id

    def _declared(self, downstream: Iterable[str]) -> frozenset[str]:
        if isinstance(downstream, str | bytes) or not isinstance(
            downstream, list | tuple | set | frozenset
        ):
            raise TypeError("downstream must be a list of audiences")
        declared = frozenset(validate_name(a, Kind.AUDIENCE) for a in downstream)
        if not declared:
            return declared
        # Only a client that is itself an audience can exchange a foreign token
        # (security 1.5 no. 1); in the reference stack that is Data alone.
        if not self._chain_holder:
            raise ValueError(f"client {self._client_id!r} is no audience and cannot hold a chain")
        if self._client_id in declared:
            raise ValueError("downstream must not contain the client's own audience")
        return declared

    @property
    def client_id(self) -> str:
        return self._client_id

    @property
    def auth_method(self) -> str:
        return self._auth.method

    @property
    def downstream(self) -> frozenset[str]:
        return self._downstream

    def forget(self, sub: str) -> None:
        """Drop every cached token of one person (lifecycle signal, revocation)."""
        if not isinstance(sub, str):
            raise TypeError("sub must be a string")
        with self._lock:
            for key in [k for k in self._cache if k[0] == sub]:
                del self._cache[key]

    def _drop_bound(self, sub: str, digest: bytes) -> None:
        """Drop the entries bound to one refused subject token.

        A refusal names a token, not a person: a forged token that claims
        someone's ``sub`` must not clear that person's cache. The person-wide
        purge is ``forget(sub)`` on the lifecycle signal.
        """
        with self._lock:
            for key in [
                k for k, e in self._cache.items() if k[0] == sub and e.subject_digest == digest
            ]:
                del self._cache[key]

    def exchange(
        self, subject_token: str, audience: str, *, correlation_id: str | None = None
    ) -> ExchangedToken:
        """Exchange ``subject_token`` for a token with ``audience`` as its only audience."""
        now = self._clock()
        cid = normalize_correlation_id(correlation_id)
        # Annotations are not enforced at run time; only a name-shaped audience
        # reaches the log and the error, so no caller text is echoed.
        raw: object = audience
        shown = raw if isinstance(raw, str) and _SHOWN.fullmatch(raw) else None
        try:
            return self._exchange(subject_token, audience, cid, now)
        except _Refused as refused:
            log.info(
                "token exchange refused: client=%s audience=%s class=%s reason=%s "
                "correlation_id=%s",
                self._client_id,
                shown,
                refused.error_class,
                refused.reason,
                cid,
            )
            raise ExchangeError(
                refused.error_class, refused.reason, audience=shown, correlation_id=cid
            ) from None

    def _exchange(self, subject_token: str, audience: str, cid: str, now: float) -> ExchangedToken:
        scope = self._scope(audience)
        subject, sub = self._subject(subject_token, now)
        if subject["azp"] == self._client_id:
            if self._chain_holder:
                raise _Refused(ErrorClass.FORBIDDEN_OR_NOT_FOUND, "chain_holder_own_token")
            origin = None
        else:
            origin = self._chain_origin(subject, audience)
        digest = hashlib.sha256(subject_token.encode()).digest()
        key = (sub, audience)
        with self._lock:
            entry = self._cache.get(key)
            if entry is not None and entry.subject_digest == digest and entry.usable_until > now:
                log.debug(
                    "token exchange cached: client=%s audience=%s correlation_id=%s",
                    self._client_id,
                    audience,
                    cid,
                )
                return replace(entry.token, correlation_id=cid)

        try:
            body = self._request(subject_token, audience=audience, scope=scope, cid=cid, now=now)
        except _Refused as refused:
            if refused.error_class == ErrorClass.IDENTITY_REVOKED:
                self._drop_bound(sub, digest)
            raise
        try:
            token, expires_at = self._issued(body, subject, audience, now)
        except ValueError as exc:
            raise _Refused(ErrorClass.CONTRACT_MISMATCH, str(exc)) from None
        result = ExchangedToken(token, audience, sub, expires_at, cid, origin)
        with self._lock:
            self._cache.pop(key, None)
            self._cache[key] = _Entry(digest, result, expires_at - CACHE_MARGIN)
            self._evict(now)
        log.info(
            "token exchange issued: client=%s audience=%s chain=%s correlation_id=%s",
            self._client_id,
            audience,
            origin is not None,
            cid,
        )
        return result

    @staticmethod
    def _scope(audience: object) -> str:
        if not isinstance(audience, str):
            # A list, tuple or set would be a second audience.
            raise _Refused(ErrorClass.INVALID_INPUT, "one_audience_per_token")
        try:
            return exchange_scope(audience)
        except InvalidName:
            raise _Refused(ErrorClass.INVALID_INPUT, "invalid_audience") from None

    @staticmethod
    def _subject(subject_token: object, now: float) -> tuple[dict[str, object], str]:
        try:
            subject = unverified_claims(subject_token)
        except ValueError:
            raise _Refused(ErrorClass.INVALID_INPUT, "malformed_subject_token") from None
        sub, azp, exp = subject.get("sub"), subject.get("azp"), _int_claim(subject, "exp")
        if not isinstance(sub, str) or not 0 < len(sub) <= _MAX_SUB or not isinstance(azp, str):
            raise _Refused(ErrorClass.INVALID_INPUT, "malformed_subject_token")
        if exp is None or exp <= now:
            raise _Refused(ErrorClass.UNAUTHENTICATED, "subject_token_expired")
        return subject, sub

    def _chain_origin(self, subject: Mapping[str, object], audience: str) -> str:
        """The client that sent a received token; refuses an undeclared chain."""
        if audience not in self._downstream:
            raise _Refused(ErrorClass.FORBIDDEN_OR_NOT_FOUND, "chain_not_declared")
        if _single_aud(subject.get("aud")) != self._client_id:
            raise _Refused(ErrorClass.FORBIDDEN_OR_NOT_FOUND, "subject_audience_mismatch")
        azp = subject.get("azp")
        try:
            if not isinstance(azp, str) or person_id(subject) is None:
                raise _Refused(ErrorClass.FORBIDDEN_OR_NOT_FOUND, "not_a_person_token")
            return validate_name(azp, Kind.CLIENT)
        except (InvalidName, InvalidClaims):
            raise _Refused(ErrorClass.FORBIDDEN_OR_NOT_FOUND, "not_a_person_token") from None

    def _request(
        self, subject_token: str, *, audience: str, scope: str, cid: str, now: float
    ) -> bytes:
        form = {
            "grant_type": GRANT_TYPE,
            "subject_token": subject_token,
            "subject_token_type": ACCESS_TOKEN_TYPE,
            "requested_token_type": ACCESS_TOKEN_TYPE,
            "audience": audience,
            "scope": scope,
        }
        headers = {"Accept": "application/json", CORRELATION_HEADER: cid}
        self._auth.apply(self._client_id, self._endpoint, now, form, headers)
        try:
            status, body = self._transport.post_form(self._endpoint, form, headers, self._timeout)
        except (OSError, ValueError, http.client.HTTPException):
            raise _Refused(ErrorClass.UPSTREAM_UNAVAILABLE, "issuer_unreachable") from None
        if status == _OK:
            return body
        raise _Refused(*self._refusal(status, body))

    @staticmethod
    def _refusal(status: int, body: bytes) -> tuple[ErrorClass, str]:
        if status >= 500:  # noqa: PLR2004 - server error class
            return ErrorClass.UPSTREAM_UNAVAILABLE, "issuer_error"
        if status not in (400, 401, 403):  # the codes RFC 6749 5.2 uses for errors
            return ErrorClass.CONTRACT_MISMATCH, "unexpected_status"
        try:
            error = parse_json_object(body).get("error")
        except ValueError:
            error = None
        if error in _REVOKED_ERRORS:
            return ErrorClass.IDENTITY_REVOKED, "subject_token_not_active"
        if error == "invalid_client":
            return ErrorClass.FORBIDDEN_OR_NOT_FOUND, "client_authentication_failed"
        return ErrorClass.FORBIDDEN_OR_NOT_FOUND, "exchange_refused"

    @staticmethod
    def _response(body: bytes) -> tuple[str, int]:
        try:
            response = parse_json_object(body)
        except ValueError:
            raise ValueError("response_not_json_object") from None
        if "refresh_token" in response:
            raise ValueError("refresh_token_issued")
        if not response.keys() <= _RESPONSE_FIELDS:
            raise ValueError("unknown_response_field")
        token = response.get("access_token")
        expires_in = response.get("expires_in")
        token_type = response.get("token_type")
        if not isinstance(token, str) or len(token) > MAX_TOKEN_LENGTH:
            raise ValueError("missing_access_token")
        if not isinstance(token_type, str) or token_type.lower() != "bearer":
            raise ValueError("token_type_not_bearer")
        if response.get("issued_token_type", ACCESS_TOKEN_TYPE) != ACCESS_TOKEN_TYPE:
            raise ValueError("issued_token_type_not_access_token")
        if type(expires_in) is not int or expires_in <= 0:
            raise ValueError("invalid_expires_in")
        return token, expires_in

    def _issued(
        self, body: bytes, subject: Mapping[str, object], audience: str, now: float
    ) -> tuple[str, float]:
        """The access token of a success response and its expiry; ValueError names the defect.

        Every ValueError carries a fixed reason; no text of the issuer is passed on.
        """
        token, expires_in = self._response(body)
        try:
            claims = unverified_claims(token)
        except ValueError:
            raise ValueError("malformed_access_token") from None
        if _single_aud(claims.get("aud")) != audience:
            raise ValueError("audience_not_single")
        if claims.get("azp") != self._client_id:
            raise ValueError("azp_mismatch")
        for kept in ("sub", "sid", "auth_time"):
            if claims.get(kept) != subject.get(kept):
                raise ValueError(f"{kept}_not_preserved")
        exp = _int_claim(claims, "exp")
        if exp is None:
            raise ValueError("missing_exp")
        expires_at = min(float(exp), now + expires_in)
        if expires_at <= now:
            raise ValueError("issued_token_expired")
        return token, expires_at

    def _evict(self, now: float) -> None:
        if len(self._cache) <= self._max_entries:
            return
        for key in [k for k, e in self._cache.items() if e.usable_until <= now]:
            del self._cache[key]
        while len(self._cache) > self._max_entries:
            del self._cache[next(iter(self._cache))]
