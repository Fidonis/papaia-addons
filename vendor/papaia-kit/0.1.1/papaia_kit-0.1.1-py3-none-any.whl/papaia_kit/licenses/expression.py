"""SPDX license expressions: parsing, normalisation and evaluation against the policy."""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date

from papaia_kit.licenses.policy import (
    SCOPES,
    UNKNOWN,
    Exceptions,
    Policy,
    PolicyError,
    normalise_name,
)

# Free-text names and trove classifier tails seen in package metadata, mapped
# to SPDX identifiers. Names without a version or variant ("BSD License",
# "Apache Software License") stay unknown: Apache-1.1 and the BSD variants
# differ in their conditions, so such packages need a [[verified]] entry.
_ALIASES: dict[str, str] = {
    "mit license": "MIT",
    "the mit license": "MIT",
    "new bsd license": "BSD-3-Clause",
    "bsd 2-clause": "BSD-2-Clause",
    "bsd 3-clause": "BSD-3-Clause",
    "3-clause bsd license": "BSD-3-Clause",
    "isc license": "ISC",
    "isc license (iscl)": "ISC",
    "apache 2.0": "Apache-2.0",
    "apache license 2.0": "Apache-2.0",
    "apache license, version 2.0": "Apache-2.0",
    "apache software license 2.0": "Apache-2.0",
    "python software foundation license": "PSF-2.0",
    "postgresql license": "PostgreSQL",
    "mozilla public license 2.0 (mpl 2.0)": "MPL-2.0",
    "eclipse public license 2.0 (epl-2.0)": "EPL-2.0",
    "gnu general public license v2 (gplv2)": "GPL-2.0-only",
    "gnu general public license v2 or later (gplv2+)": "GPL-2.0-or-later",
    "gnu general public license v3 (gplv3)": "GPL-3.0-only",
    "gnu general public license v3 or later (gplv3+)": "GPL-3.0-or-later",
    "gnu affero general public license v3": "AGPL-3.0-only",
    "gnu affero general public license v3 or later (agplv3+)": "AGPL-3.0-or-later",
    "gnu lesser general public license v2 or later (lgplv2+)": "LGPL-2.1-or-later",
    "gnu lesser general public license v3 (lgplv3)": "LGPL-3.0-only",
    "the unlicense (unlicense)": "Unlicense",
    "zlib/libpng license": "Zlib",
    "cc0 1.0 universal (cc0 1.0) public domain dedication": "CC0-1.0",
}

_TOKEN = re.compile(r"\s*(\(|\)|[A-Za-z0-9.+:-]+)")
_OPERATORS = {"AND", "OR", "WITH"}
_MAX_EXPRESSION = 300
_RANK = {"deny": 0, "conditional": 1, "allow": 2}


class LicenseExpressionError(ValueError):
    """The text is not a valid SPDX license expression."""


@dataclass(frozen=True)
class License:
    spdx: str  # identifier, optionally "<id> WITH <exception>"


@dataclass(frozen=True)
class Compound:
    operator: str  # "AND" or "OR"
    parts: tuple[Node, ...]


Node = License | Compound


@dataclass(frozen=True)
class Record:
    """One dependency as found in a lock file or installed metadata."""

    name: str
    version: str
    license: str
    scope: str
    ecosystem: str = "python"
    source: str = "metadata"
    # Set by a reader that could not determine the record reliably (a locked
    # package missing from the environment); the record then always fails.
    problem: str = ""


def _tokenize(text: str) -> list[str]:
    tokens: list[str] = []
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        match = _TOKEN.match(text, pos)
        if not match:
            raise LicenseExpressionError(f"unexpected character in {text!r}")
        tokens.append(match.group(1))
        pos = match.end()
    return tokens


def parse_expression(text: str) -> Node:
    """Parse an SPDX expression; operators are accepted in any letter case."""
    if len(text) > _MAX_EXPRESSION:
        raise LicenseExpressionError("license expression is too long")
    tokens = _tokenize(text)
    if not tokens:
        raise LicenseExpressionError("empty license expression")
    pos = 0

    def peek() -> str | None:
        return tokens[pos] if pos < len(tokens) else None

    def take() -> str:
        nonlocal pos
        if pos >= len(tokens):
            raise LicenseExpressionError(f"incomplete license expression {text!r}")
        pos += 1
        return tokens[pos - 1]

    def compound(operator: str, operand: Callable[[], Node]) -> Node:
        parts = [operand()]
        while (token := peek()) is not None and token.upper() == operator:
            take()
            parts.append(operand())
        return parts[0] if len(parts) == 1 else Compound(operator, tuple(parts))

    def atom() -> Node:
        part = take()
        if part == "(":
            node = or_expr()
            if take() != ")":
                raise LicenseExpressionError(f"missing ')' in {text!r}")
            return node
        if part == ")" or part.upper() in _OPERATORS:
            raise LicenseExpressionError(f"unexpected {part!r} in {text!r}")
        if (nxt := peek()) is not None and nxt.upper() == "WITH":
            take()
            exception = take()
            if exception in "()" or exception.upper() in _OPERATORS:
                raise LicenseExpressionError(f"missing exception after WITH in {text!r}")
            return License(f"{part} WITH {exception}")
        return License(part)

    def and_expr() -> Node:
        return compound("AND", atom)

    def or_expr() -> Node:
        return compound("OR", and_expr)

    node = or_expr()
    if pos != len(tokens):
        raise LicenseExpressionError(f"unexpected {tokens[pos]!r} in {text!r}")
    return node


def license_alias(text: str) -> str | None:
    """SPDX identifier for a free-text license name from package metadata."""
    return _ALIASES.get(text.strip().lower())


def normalise(text: str, policy: Policy) -> str:
    """Map metadata text to a canonical SPDX expression string."""
    text = text.strip()
    alias = _ALIASES.get(text.lower())
    if alias:
        return alias
    return _render(parse_expression(text), policy)


def _render(node: Node, policy: Policy) -> str:
    if isinstance(node, License):
        return policy.canonical(node.spdx)
    return f" {node.operator} ".join(
        f"({_render(p, policy)})" if isinstance(p, Compound) else _render(p, policy)
        for p in node.parts
    )


def _decide(node: Node, policy: Policy, rule_decision: dict[str, str]) -> str:
    if isinstance(node, License):
        return rule_decision[policy.class_of(node.spdx)]
    verdicts = [_decide(p, policy, rule_decision) for p in node.parts]
    pick = max if node.operator == "OR" else min
    return pick(verdicts, key=_RANK.__getitem__)


def evaluate(  # noqa: PLR0911 - one return per policy outcome reads best
    record: Record,
    policy: Policy,
    exceptions: Exceptions,
    *,
    today: date,
    edition: str | None = None,
) -> str | None:
    """Return None when the record passes the policy, else the reason it fails."""
    if record.scope not in SCOPES:
        raise PolicyError(f"{record.name}: unknown scope {record.scope!r}")
    if record.problem:
        return record.problem
    name = normalise_name(record.name)
    text = effective_license(record, exceptions)
    if not text.strip():
        return "no license information"
    try:
        expression = normalise(text, policy)
        node = parse_expression(expression)
    except LicenseExpressionError as exc:
        return f"unknown license: {exc}"
    rule = policy.rules(edition)[record.scope]
    decisions = {cls: rule.decision(cls) for cls in policy.classes.values()}
    decisions["unknown"] = rule.decision("unknown")
    decision = _decide(node, policy, decisions)
    if decision == "allow":
        return None
    if decision == "deny":
        return f"not allowed in scope {record.scope}: {expression}"
    for entry in exceptions.exceptions:
        if (entry.package, entry.version, entry.scope) == (
            name,
            record.version,
            record.scope,
        ) and _same_license(entry.license, expression, policy):
            if entry.expires < today:
                return f"exception for {expression} expired on {entry.expires.isoformat()}"
            return None
    return f"{expression} in scope {record.scope} needs an exception entry"


def effective_license(record: Record, exceptions: Exceptions) -> str:
    """The record's license text, replaced by a matching [[verified]] entry."""
    name = normalise_name(record.name)
    for checked in exceptions.verified:
        if checked.package == name and checked.version == record.version:
            return checked.license
    return record.license


def classify(text: str, policy: Policy) -> str:
    """License classes of an expression in its shape, e.g. ``permissive OR strong``."""
    try:
        node = parse_expression(normalise(text, policy)) if text.strip() else None
    except LicenseExpressionError:
        node = None
    return UNKNOWN if node is None else _classes(node, policy, top=True)


def _classes(node: Node, policy: Policy, *, top: bool = False) -> str:
    if isinstance(node, License):
        return policy.class_of(node.spdx)
    parts = list(dict.fromkeys(_classes(p, policy) for p in node.parts))
    joined = f" {node.operator} ".join(parts)
    return joined if top or len(parts) == 1 else f"({joined})"


def _same_license(text: str, expression: str, policy: Policy) -> bool:
    try:
        return normalise(text, policy) == expression
    except LicenseExpressionError:
        return False
