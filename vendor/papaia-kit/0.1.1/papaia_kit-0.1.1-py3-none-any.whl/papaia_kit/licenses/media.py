"""Register of the media files the kit ships (``tokens/media.yaml``) and its license section.

The register names every font and icon file under ``tokens/assets/`` with its
source, release, rights holder, license and SHA-256. ``tools/build.py`` reads
it to generate ``dist/fonts`` and ``dist/icons``; ``papaia-kit licenses render
--media`` reads it to list the same files under "Bundled assets" in
THIRD_PARTY_LICENSES.md. Both use :func:`load_register`, so the shipped files
and the license list cannot drift apart.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from papaia_kit.licenses.policy import PolicyError

MAX_REGISTER_BYTES = 1024 * 1024

_MEDIA_FIELDS = {"file", "kind", "source", "release", "holder", "license", "retrieved", "sha256"}
_LICENSE_FIELDS = {"spdx", "file", "sha256"}
_MEDIA_FILE = re.compile(r"^assets/(fonts|icons)/[a-z0-9]+(?:-[a-z0-9]+)*\.(woff2|svg)$")
_LICENSE_FILE = re.compile(r"^licenses/[A-Za-z0-9.-]+\.txt$")
_KEY = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_SPDX = re.compile(r"^[A-Za-z0-9.-]{1,64}$")
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_URL = re.compile(r"^https://[A-Za-z0-9.-]+/[A-Za-z0-9._~/@%+-]*$")

SPRITE = "sprite.svg"
ICON_NOTICE = "NOTICE.txt"
LOGIN_THEME_FONTS = "dist/keycloak/papaia/login/resources/fonts/"


class MediaError(PolicyError):
    """The media register or a file it names is not valid."""


@dataclass(frozen=True)
class License:
    key: str
    spdx: str
    file: str

    @property
    def shipped_name(self) -> str:
        """Name of the license text next to the shipped files: ``LICENSE-<file name>``."""
        return f"LICENSE-{Path(self.file).name}"


@dataclass(frozen=True)
class Media:
    file: str
    kind: str
    symbol: str | None
    license: str
    sha256: str
    release: str = ""
    holder: str = ""
    source: str = ""


Register = tuple[Mapping[str, License], Sequence[Media]]


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _text(entry: Mapping[str, Any], key: str, where: str, limit: int = 300) -> str:
    value = entry.get(key)
    if not isinstance(value, str) or not value or len(value) > limit:
        raise MediaError(f"{where}: {key} is not a non-empty string")
    return value


def load_register(tokens: Path) -> tuple[dict[str, License], list[Media]]:
    """Read ``media.yaml`` and check every file it names against its SHA-256."""
    path = tokens / "media.yaml"
    try:
        if path.stat().st_size > MAX_REGISTER_BYTES:
            raise MediaError("media.yaml: larger than 1 MiB")
        doc = yaml.safe_load(path.read_text(encoding="utf-8"))
    except OSError as exc:
        raise MediaError(f"media.yaml: cannot read ({exc.strerror})") from None
    except (UnicodeDecodeError, yaml.YAMLError) as exc:
        raise MediaError(f"media.yaml: not UTF-8 YAML ({type(exc).__name__})") from None
    if not isinstance(doc, dict) or set(doc) != {"version", "licenses", "media"}:
        raise MediaError("media.yaml: needs exactly version, licenses, media")
    if doc["version"] != 1:
        raise MediaError("media.yaml: unsupported version")
    licenses = _licenses(tokens, doc["licenses"])
    if not isinstance(doc["media"], list) or not doc["media"]:
        raise MediaError("media.yaml: media is not a non-empty list")
    media = [_media(tokens, entry, index, licenses) for index, entry in enumerate(doc["media"])]
    files = [m.file for m in media]
    symbols = [m.symbol for m in media if m.symbol is not None]
    for name, values in (("file", files), ("symbol", symbols)):
        twice = sorted({v for v in values if values.count(v) > 1})
        if twice:
            raise MediaError(f"media.yaml: {name} listed twice: {twice[0]}")
    on_disk = {
        p.relative_to(tokens).as_posix() for p in (tokens / "assets").rglob("*") if not p.is_dir()
    }
    unregistered = sorted(on_disk - set(files))
    if unregistered:
        raise MediaError(f"{unregistered[0]}: no entry in media.yaml; it is not used")
    unused = sorted(set(licenses) - {m.license for m in media})
    if unused:
        raise MediaError(f"media.yaml: license {unused[0]} is not used")
    return licenses, media


def _licenses(tokens: Path, raw: object) -> dict[str, License]:
    if not isinstance(raw, dict) or not raw:
        raise MediaError("media.yaml: licenses is not a non-empty mapping")
    out = {}
    for key, entry in raw.items():
        where = f"media.yaml: license {key}"
        if not isinstance(key, str) or not _KEY.match(key):
            raise MediaError("media.yaml: license key is not a lowercase name")
        if not isinstance(entry, dict) or set(entry) != _LICENSE_FIELDS:
            raise MediaError(f"{where}: needs exactly {', '.join(sorted(_LICENSE_FIELDS))}")
        spdx, file = _text(entry, "spdx", where), _text(entry, "file", where)
        if not _SPDX.match(spdx) or not _LICENSE_FILE.match(file):
            raise MediaError(f"{where}: spdx or file is not valid")
        _verify(tokens, file, entry.get("sha256"))
        out[key] = License(key, spdx, file)
    return out


def _media(tokens: Path, entry: object, index: int, licenses: Mapping[str, License]) -> Media:
    where = f"media.yaml: media[{index}]"
    if not isinstance(entry, dict):
        raise MediaError(f"{where}: not a mapping")
    fields = set(entry)
    expected = _MEDIA_FIELDS | ({"symbol"} if entry.get("kind") == "icon" else set())
    if fields != expected:
        odd = sorted(fields ^ expected)
        raise MediaError(f"{where}: unknown or missing field {odd[0]}")
    file = _text(entry, "file", where)
    match = _MEDIA_FILE.match(file)
    kind = entry["kind"]
    if match is None or (kind, match.group(1), match.group(2)) not in {
        ("font", "fonts", "woff2"),
        ("icon", "icons", "svg"),
    }:
        raise MediaError(f"{where}: file and kind do not fit (fonts/*.woff2, icons/*.svg)")
    where = f"{file}"
    release, holder = (_text(entry, key, where) for key in ("release", "holder"))
    source = _text(entry, "source", where)
    if not _URL.match(source):
        raise MediaError(f"{where}: source is not an https URL")
    if not _DATE.match(_text(entry, "retrieved", where, 10)):
        raise MediaError(f"{where}: retrieved is not YYYY-MM-DD")
    license_key = _text(entry, "license", where)
    if license_key not in licenses:
        raise MediaError(f"{where}: license {license_key} is not in the licenses list")
    symbol = None
    if kind == "icon":
        symbol = _text(entry, "symbol", where, 64)
        if not _KEY.match(symbol):
            raise MediaError(f"{where}: symbol is not a lowercase name")
    digest = _verify(tokens, file, entry.get("sha256"))
    return Media(file, kind, symbol, license_key, digest, release, holder, source)


def _verify(tokens: Path, file: str, digest: object) -> str:
    if not isinstance(digest, str) or not _SHA256.match(digest):
        raise MediaError(f"{file}: sha256 is not 64 lowercase hex digits")
    path = tokens / file
    if path.is_symlink() or not path.is_file():
        raise MediaError(f"{file}: missing or not a regular file")
    if _sha256(path.read_bytes()) != digest:
        raise MediaError(f"{file}: sha256 does not match the register")
    return digest


def _cell(text: str) -> str:
    return text.replace("|", "\\|").replace("\n", " ") or "-"


def render_assets(register: Register) -> list[str]:
    """Markdown lines of the section "Bundled assets": every file under dist/fonts and dist/icons.

    Fonts are shipped one file per register entry, icons as symbols of one
    sprite; every license text is shipped next to the files it covers.
    """
    licenses, media = register
    fonts = sorted((m for m in media if m.kind == "font"), key=lambda m: Path(m.file).name)
    icons = sorted((m for m in media if m.kind == "icon"), key=lambda m: m.symbol or "")
    lines = [
        "## Bundled assets",
        "",
        "Fonts and icons shipped under `dist/`, generated from `tokens/media.yaml`. Each",
        "license text ships next to the files it covers. The login theme ships copies of",
        f"the same font files and license texts under `{LOGIN_THEME_FONTS}`.",
        "",
        "### Fonts",
        "",
        "| File | License | License text | Rights holder | Release | Source |",
        "|---|---|---|---|---|---|",
    ]
    for font in fonts:
        license_ = licenses[font.license]
        lines.append(
            f"| `dist/fonts/{Path(font.file).name}` | {_cell(license_.spdx)} | "
            f"`dist/fonts/{license_.shipped_name}` | {_cell(font.holder)} | "
            f"{_cell(font.release)} | {_cell(font.source)} |"
        )
    lines += [
        "",
        "### Icons",
        "",
        f"Symbols of `dist/icons/{SPRITE}`; `dist/icons/{ICON_NOTICE}` lists the same",
        "symbols next to the sprite.",
        "",
        "| Symbol | License | License text | Rights holder | Release | Source |",
        "|---|---|---|---|---|---|",
    ]
    for icon in icons:
        license_ = licenses[icon.license]
        lines.append(
            f"| `pk-icon-{icon.symbol}` | {_cell(license_.spdx)} | "
            f"`dist/icons/{license_.shipped_name}` | {_cell(icon.holder)} | "
            f"{_cell(icon.release)} | {_cell(icon.source)} |"
        )
    return [*lines, ""]
