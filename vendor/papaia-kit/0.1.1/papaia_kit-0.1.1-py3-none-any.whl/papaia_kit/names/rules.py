"""Naming rules per kind and the only builder of exchange scopes."""

from __future__ import annotations

import re

from papaia_kit.names._data import BASE, BUILTIN, REMOVED, ROLE_MODULES
from papaia_kit.names._model import Entry, InvalidName, Kind, Removed

MAX_NAME_LENGTH = 64
AUD_PREFIX = "aud-"
# An audience leaves room for its exchange scope within the length limit.
MAX_AUDIENCE_LENGTH = MAX_NAME_LENGTH - len(AUD_PREFIX)

_SEG = r"[a-z0-9]+"
_SYNTAX = re.compile(rf"[a-z][a-z0-9]*(?:-{_SEG})*")
# OIDC protocol scopes use an underscore; they are only valid as registered names.
_PROTOCOL_SCOPE = re.compile(r"[a-z]+(?:_[a-z]+)*")
_MCP = re.compile(rf"mcp-{_SEG}(?:-{_SEG})*")
_PAPAIA = re.compile(rf"papaia-{_SEG}(?:-{_SEG})*")
_SVC = re.compile(rf"svc-{_SEG}-{_SEG}(?:-{_SEG})*")
_ROLE = re.compile(rf"(?P<prefix>[a-z][a-z0-9]*)-{_SEG}(?:-{_SEG})*")
_SVC_PREFS = re.compile(rf"svc-(?P<module>{_SEG})-prefs")
_REGISTERED = frozenset((e.name, e.kind) for e in BASE)
_BUILTIN_INDEX: dict[tuple[str, Kind], Entry] = {(e.name, e.kind): e for e in BUILTIN}
_CLIENT_ONLY = frozenset(e.name for e in BASE if e.kind is Kind.CLIENT) - frozenset(
    e.name for e in BASE if e.kind is Kind.AUDIENCE
)

_RULES: dict[Kind, str] = {
    Kind.AUDIENCE: "mcp-<system> or papaia-<module>[-<surface>]",
    Kind.CLIENT: "papaia-<module>[-<surface>], mcp-<system> or svc-<module>-<purpose>",
    Kind.SCOPE: "aud-<audience>",
    Kind.ROLE: "<module>-<role> (module one of "
    + ", ".join(sorted(ROLE_MODULES))
    + ") or papaia-<role>",
    Kind.SERVICE_ACCOUNT: "svc-<module>-<purpose>",
    Kind.SERVICE: "papaia-<service>",
    Kind.NETWORK: "papaia-<network>",
}


def _kind(kind: Kind | str) -> Kind:
    if isinstance(kind, Kind):
        return kind
    if not isinstance(kind, str):
        raise TypeError(f"kind must be a Kind, not {type(kind).__name__}")
    try:
        return Kind(kind)
    except ValueError:
        raise ValueError(f"unknown kind {kind!r}") from None


def _removed(name: str, kind: Kind) -> Removed | None:
    for removed in REMOVED:
        if removed.name == name and (removed.kinds is None or kind in removed.kinds):
            return removed
    match = _SVC_PREFS.fullmatch(name)
    if match and kind in (Kind.SERVICE_ACCOUNT, Kind.CLIENT):
        module = match["module"]
        return Removed(name, f"svc-{module}-notify", "service accounts read notifications")
    return None


def _check_syntax(name: object, kind: Kind) -> str:
    if not isinstance(name, str):
        raise TypeError(f"{kind.label} name must be a string, not {type(name).__name__}")
    limit = MAX_AUDIENCE_LENGTH if kind is Kind.AUDIENCE else MAX_NAME_LENGTH
    if len(name) > limit:
        raise InvalidName(name, kind, f"longer than {limit} characters")
    if (name, kind) in _REGISTERED and kind is Kind.SCOPE and _PROTOCOL_SCOPE.fullmatch(name):
        return name
    if not _SYNTAX.fullmatch(name):
        raise InvalidName(
            name, kind, "only lower-case ASCII letters and digits in segments joined by '-'"
        )
    return name


def _check_rule(name: str, kind: Kind) -> None:
    rule = _RULES[kind]
    if kind is Kind.AUDIENCE:
        if name in _CLIENT_ONLY:
            raise InvalidName(name, kind, "registered as a client that is never an audience")
        ok = bool(_MCP.fullmatch(name) or _PAPAIA.fullmatch(name))
    elif kind is Kind.CLIENT:
        ok = bool(_PAPAIA.fullmatch(name) or _MCP.fullmatch(name) or _SVC.fullmatch(name))
    elif kind is Kind.SCOPE:
        _check_scope(name)
        return
    elif kind is Kind.ROLE:
        match = _ROLE.fullmatch(name)
        ok = bool(_PAPAIA.fullmatch(name)) or (
            match is not None and match["prefix"] in ROLE_MODULES
        )
    elif kind is Kind.SERVICE_ACCOUNT:
        ok = bool(_SVC.fullmatch(name))
    else:
        ok = bool(_PAPAIA.fullmatch(name))
    if not ok:
        raise InvalidName(name, kind, f"does not follow {rule}")


def _check_scope(name: str) -> None:
    if not name.startswith(AUD_PREFIX):
        raise InvalidName(name, Kind.SCOPE, f"does not follow {_RULES[Kind.SCOPE]}")
    audience = name[len(AUD_PREFIX) :]
    try:
        validate(audience, Kind.AUDIENCE)
    except InvalidName as exc:
        succ = _scope_successor(exc.successor)
        raise InvalidName(name, Kind.SCOPE, f"audience {audience!r}: {exc.reason}", succ) from None


def _scope_successor(audience_successor: str | None) -> str | None:
    # A removed audience may be replaced by a client that is never an audience
    # (papaia-flow-console -> flow-console); its scope is then no successor.
    if audience_successor and is_valid(audience_successor, Kind.AUDIENCE):
        return AUD_PREFIX + audience_successor
    return None


def validate(name: str, kind: Kind | str) -> str:
    """Return ``name`` if it is a valid name of ``kind``; raise ``InvalidName`` otherwise.

    A name is valid when it is not removed and either is registered for its
    kind (existing names such as ``flow`` included) or follows the rule of its
    kind. Removed names carry their successor in the exception.
    """
    kind = _kind(kind)
    _check_syntax(name, kind)
    removed = _removed(name, kind)
    if removed is not None:
        raise InvalidName(name, kind, f"removed name ({removed.reason})", removed.successor)
    if (name, kind) in _REGISTERED:
        return name
    _check_rule(name, kind)
    return name


def is_valid(name: str, kind: Kind | str) -> bool:
    """True if ``validate`` accepts the name; type errors still raise."""
    try:
        validate(name, kind)
    except InvalidName:
        return False
    return True


def successor(name: str, kind: Kind | str) -> str | None:
    """The name that replaces a removed name, or None if the name is not removed."""
    kind = _kind(kind)
    _check_syntax(name, kind)
    removed = _removed(name, kind)
    if removed is not None:
        return removed.successor
    if kind is Kind.SCOPE and name.startswith(AUD_PREFIX):
        return _scope_successor(successor(name[len(AUD_PREFIX) :], Kind.AUDIENCE))
    return None


def transitional(name: str, kind: Kind | str, stage: int) -> Removed | None:
    """The removed entry if ``name`` may still exist in ``stage`` next to its successor.

    ``validate`` rejects such a name all the same; only the realm sync and the
    realm conformance check use this to tolerate an old name during its
    transition (``wiki-mcp`` until the end of stage 1, RE-10).
    """
    kind = _kind(kind)
    if type(stage) is not int or stage < 0:  # bool is no stage
        raise TypeError("stage must be a non-negative integer")
    _check_syntax(name, kind)
    removed = _removed(name, kind)
    if removed is not None and removed.until_stage is not None and stage <= removed.until_stage:
        return removed
    return None


def builtin(name: str, kind: Kind | str) -> Entry | None:
    """The entry of a Keycloak built-in object (client scope, realm role, client), or None.

    Built-in objects are present in every realm and not managed by the
    register; ``validate`` does not accept them as names to create.
    """
    if not isinstance(name, str):
        raise TypeError(f"name must be a string, not {type(name).__name__}")
    return _BUILTIN_INDEX.get((name, _kind(kind)))


def has_exchange_prefix(name: str) -> bool:
    """Whether ``name`` has the form of an exchange scope (``aud-…``).

    It reads the form only, so a realm check finds every exchange scope even
    when its audience breaks the rules; ``validate`` checks the whole name.
    """
    if not isinstance(name, str):
        raise TypeError(f"name must be a string, not {type(name).__name__}")
    return name.startswith(AUD_PREFIX)


def exchange_scope(audience: str) -> str:
    """The client scope ``aud-<audience>`` that requests exactly this one audience.

    This is the only supported way to build an exchange scope. It takes
    exactly one audience and rejects removed names, client-only names and
    names that break the audience rule.
    """
    if not isinstance(audience, str):
        raise TypeError(
            f"exchange_scope takes exactly one audience as a string, not {type(audience).__name__}"
        )
    validate(audience, Kind.AUDIENCE)
    return AUD_PREFIX + audience
