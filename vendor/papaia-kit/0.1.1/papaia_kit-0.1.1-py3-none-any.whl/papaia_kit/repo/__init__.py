"""Repository discipline checks run in the CI of every papaia repository.

``words`` scans tracked and new files for denied terms (tool and vendor names,
private tooling). A repository whose existing texts hold such terms as product
vocabulary freezes them in a baseline file (``load_words_baseline``,
``check_words``): a listed hit passes, any other hit fails, and an entry whose
hit disappeared fails as stale. ``commits`` checks author, committer, sign-off
and message of every commit in a range; an optional start boundary
(``commit-boundary.toml``, ``load_commit_boundary``) leaves one named commit and
its ancestors out. The patterns are stored base64-encoded so that this file
does not match itself.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import subprocess
import tomllib
from collections import Counter
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_DENIED_B64 = (
    "XGIoY2xhdWRlfGFudGhyb3BpY3xvcGVuYWl8Y2hhdGdwdHxjb3BpbG90fGN1cnNvcnxhaWRlcnxhZ2VudHM/fGFnZW50aWN8"
    "dmliZWNvZFthLXpdKnxwYXBhaWEtdG9vbHN8c2V0dXAtcGFwYWlhfHVwZGF0ZS1wYXBhaWF8Zmlkb25pcy1jdGwpXGI="
)
_DENIED_EXACT_B64 = "XGJBSVxi"  # matched case-sensitively, so the product name papAIa passes
# API key prefix of one vendor, in any case and position (no word boundary)
_DENIED_VENDOR_PREFIX_B64 = "KD9pKXNrLWFudC0="

# Uses of two denied words that name no tool and stay allowed. Matching spans
# are blanked before the denied terms are searched, so any other hit on the
# same line still counts. Each pattern is narrow on purpose: lower case where
# code spells it that way, fixed value lists, no free prose.
ALLOWED_CONTEXTS_B64 = (
    # HTTP request header name (RFC 9110), any spelling of the separator
    "KD88IVtcdy1dKSg/aTp1c2VyWy1fIF1hZ2VudCkoPyFbXHctXSk=",
    # key daemons of OpenSSH and GnuPG
    "KD88IVtcdy1dKSg/OnNzaHxncGcpLWFnZW50KD8hW1x3LV0p",
    # CSS pointer-shape property followed by a CSS keyword value, url() or var()
    "KD88IVtcdy1dKWN1cnNvclxzKjpccyooPzooPzphdXRvfGRlZmF1bHR8bm9uZXxjb250ZXh0LW1lbnV8aGVscHxwb2ludGVy"
    "fHByb2dyZXNzfHdhaXR8Y2VsbHxjcm9zc2hhaXJ8dGV4dHx2ZXJ0aWNhbC10ZXh0fGFsaWFzfGNvcHl8bW92ZXxuby1kcm9w"
    "fG5vdC1hbGxvd2VkfGdyYWJiaW5nfGdyYWJ8YWxsLXNjcm9sbHxjb2wtcmVzaXplfHJvdy1yZXNpemV8bmVzdy1yZXNpemV8"
    "bndzZS1yZXNpemV8W25zZXddezEsMn0tcmVzaXplfHpvb20taW58em9vbS1vdXR8aW5oZXJpdHxpbml0aWFsfHVuc2V0fHJl"
    "dmVydC1sYXllcnxyZXZlcnQpKD8hW1x3LV0pfHVybFwofHZhclwoKQ==",
    # CSS utility classes for the pointer shape with the same keyword values
    "KD88IVtcdy1dKWN1cnNvci0oPzphdXRvfGRlZmF1bHR8bm9uZXxjb250ZXh0LW1lbnV8aGVscHxwb2ludGVyfHByb2dyZXNz"
    "fHdhaXR8Y2VsbHxjcm9zc2hhaXJ8dGV4dHx2ZXJ0aWNhbC10ZXh0fGFsaWFzfGNvcHl8bW92ZXxuby1kcm9wfG5vdC1hbGxv"
    "d2VkfGdyYWJiaW5nfGdyYWJ8YWxsLXNjcm9sbHxjb2wtcmVzaXplfHJvdy1yZXNpemV8bmVzdy1yZXNpemV8bndzZS1yZXNp"
    "emV8W25zZXddezEsMn0tcmVzaXplfHpvb20taW58em9vbS1vdXR8aW5oZXJpdHxpbml0aWFsfHVuc2V0fHJldmVydC1sYXll"
    "cnxyZXZlcnQpKD8hW1x3LV0p",
    # attribute or method of a code object right after an identifier, such as
    # the database API (PEP 249) or a DOM style object; not a dot-directory
    "KD88PVtcdylcXV0pXC5jdXJzb3IoPyFbXHcvLi1dKQ==",
    # pagination parameter of the MCP list methods as a quoted key or lookup
    "KD88PSIpY3Vyc29yKD89Ils6KVxdXSk=",
    # English product name of the manager's map of knowledge sources (glossary
    # entry 17, decision E-11), exact case, as a whole name only
    "KD88IVtcdy1dKUFJIE1hcHM/KD8hW1x3LV0p",
)

_DENIED = re.compile(base64.b64decode(_DENIED_B64).decode(), re.IGNORECASE)
_DENIED_EXACT = re.compile(base64.b64decode(_DENIED_EXACT_B64).decode())
_DENIED_VENDOR_PREFIX = re.compile(base64.b64decode(_DENIED_VENDOR_PREFIX_B64).decode())
_ALLOWED = re.compile("|".join(f"(?:{base64.b64decode(p).decode()})" for p in ALLOWED_CONTEXTS_B64))

# Third-party package names in lock files are not wording.
_SKIPPED_NAMES = frozenset({"uv.lock", "package-lock.json"})
_BINARY_PROBE = 8192
_MAX_RANGE = 200
_RANGE = re.compile(r"[A-Za-z0-9_./~^@{}-]+(\.\.\.?[A-Za-z0-9_./~^@{}-]+)?")
_CO_AUTHOR = re.compile(r"^co-authored-by:", re.IGNORECASE | re.MULTILINE)


@dataclass(frozen=True)
class Finding:
    location: str
    message: str


@dataclass(frozen=True)
class Hit:
    """One denied term on one line of a file."""

    path: str
    line: int
    term: str
    fingerprint: str

    @property
    def key(self) -> tuple[str, str, str]:
        return (self.path, self.term, self.fingerprint)


def find_denied_words(text: str) -> list[str]:
    """Denied terms in the text, in order of appearance (allowed contexts excluded)."""
    masked = _ALLOWED.sub(lambda m: " " * len(m.group(0)), text)
    hits = [
        (m.start(), m.group(0))
        for pattern in (_DENIED, _DENIED_EXACT, _DENIED_VENDOR_PREFIX)
        for m in pattern.finditer(masked)
    ]
    return [word for _, word in sorted(hits)]


def _git(root: Path, *args: str) -> str:
    # Fixed argument list without a shell; ranges are validated by valid_range.
    return subprocess.run(  # noqa: S603
        ["git", "-C", str(root), *args],  # noqa: S607 - git from PATH, like every developer tool
        check=True,
        capture_output=True,
        text=True,
    ).stdout


def line_fingerprint(line: str) -> str:
    """SHA-256 of the line text without surrounding white space (moves and indents keep it)."""
    return hashlib.sha256(line.strip().encode("utf-8")).hexdigest()


def versionable_files(root: Path) -> list[str]:
    """Paths git would version in ``root`` (tracked plus new, not ignored), sorted."""
    listed = _git(root, "ls-files", "-z", "--cached", "--others", "--exclude-standard")
    return sorted(set(filter(None, listed.split("\0"))))


def _text_files(root: Path) -> Iterable[tuple[str, str]]:
    """Every file git would version (tracked plus new, not ignored) that holds text."""
    for rel in versionable_files(root):
        path = root / rel
        if path.name in _SKIPPED_NAMES or not path.is_file() or path.is_symlink():
            continue
        data = path.read_bytes()
        if b"\0" in data[:_BINARY_PROBE]:
            continue
        yield rel, data.decode("utf-8", errors="replace")


def _path_line(path: str) -> str:
    return f"path = {json.dumps(path, ensure_ascii=False)}"


def _term_line(term: str) -> str:
    return f"term = {json.dumps(term)}"


def scan_hits(
    root: Path,
    *,
    baseline_path: str | None = None,
    baseline_terms: Iterable[str] = (),
    baseline_paths: Iterable[str] = (),
) -> list[Hit]:
    """Every denied term in the files git would version, in file and line order.

    In the baseline file itself (``baseline_path``, relative to ``root``) a line
    that is exactly ``term = "<term>"`` for a term, or ``path = "<path>"`` for a
    path the loaded baseline lists (written as ``render_baseline`` writes it) is
    not a hit; every other line of that file is checked like any file.
    """
    exempt = {_term_line(term) for term in baseline_terms}
    exempt |= {_path_line(path) for path in baseline_paths}
    hits = []
    for rel, text in _text_files(root):
        for number, line in enumerate(text.splitlines(), 1):
            if rel == baseline_path and line.strip() in exempt:
                continue
            for word in find_denied_words(line):
                hits.append(Hit(rel, number, word, line_fingerprint(line)))
    return hits


def _by_line(hits: Iterable[tuple[Hit, str]]) -> list[Finding]:
    """One finding per line, terms in order of appearance."""
    lines: dict[tuple[str, int], list[str]] = {}
    for hit, note in hits:
        lines.setdefault((hit.path, hit.line), []).append(hit.term + note)
    return [Finding(f"{path}:{line}", ", ".join(words)) for (path, line), words in lines.items()]


def scan_files(root: Path) -> list[Finding]:
    """Check every file git would version (tracked plus new, not ignored)."""
    return _by_line((hit, "") for hit in scan_hits(root))


# Frozen per-repository baseline of the word check.
MAX_BASELINE_BYTES = 1024 * 1024
MAX_BASELINE_ENTRIES = 10_000
MAX_BASELINE_COUNT = 1_000
MAX_REASON = 300
_MAX_PATH = 1024
_MAX_TERM = 64
_FINGERPRINT = re.compile(r"[0-9a-f]{64}")
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")
_ENTRY_KEYS = frozenset({"path", "term", "fingerprint", "count", "reason"})
_REQUIRED_KEYS = frozenset({"path", "term", "fingerprint", "reason"})

BASELINE_HEADER = """\
# Frozen baseline of `papaia-kit repo words` for this repository.
#
# Each entry is one place that already held a denied term when the baseline
# was frozen: the file (relative to the repository root), the term as found,
# the SHA-256 fingerprint of the line text without surrounding white space,
# the number of hits of this term on lines with this text in that file
# (`count`, default 1; a line that holds the term twice counts twice) and the
# reason. A listed hit passes, also after its line moved; any other hit fails.
# An entry whose hit disappeared fails as stale until it is removed.
#
# The file is written once with `repo words --write-baseline`. Removing an
# entry needs no review; adding or changing one does, in its own reviewed
# change with a reason for that place.
"""


class BaselineError(ValueError):
    """The baseline file cannot be used; the message names the file and the entry."""


@dataclass(frozen=True)
class BaselineEntry:
    path: str
    term: str
    fingerprint: str
    reason: str
    count: int = 1

    @property
    def key(self) -> tuple[str, str, str]:
        return (self.path, self.term, self.fingerprint)


@dataclass(frozen=True)
class WordsResult:
    failures: list[Finding]
    stale: list[Finding]
    baselined: int


def _control(text: str) -> bool:
    return _CONTROL.search(text) is not None


def check_reason(reason: object) -> str:
    """A reason is one line of 1 to MAX_REASON characters without a denied term."""
    if not isinstance(reason, str) or not reason.strip():
        raise BaselineError("reason must be a non-empty string")
    if len(reason) > MAX_REASON or _control(reason) or reason != reason.strip():
        raise BaselineError(f"reason must be one trimmed line of at most {MAX_REASON} characters")
    if find_denied_words(reason):
        raise BaselineError("reason contains a denied term")
    return reason


def _check_path(path: object) -> str:
    if not isinstance(path, str) or not 0 < len(path) <= _MAX_PATH or _control(path):
        raise BaselineError(f"path must be a string of 1 to {_MAX_PATH} characters")
    if path.startswith("/") or "\\" in path or any(p in {"", ".", ".."} for p in path.split("/")):
        raise BaselineError("path must be relative to the repository root, with / separators")
    return path


def _entry(raw: object) -> BaselineEntry:
    if not isinstance(raw, Mapping):
        raise BaselineError("an entry must be a table")
    if unknown := sorted(set(raw) - _ENTRY_KEYS):
        raise BaselineError(f"unknown key(s) {', '.join(unknown)}")
    if missing := sorted(_REQUIRED_KEYS - set(raw)):
        raise BaselineError(f"missing key(s) {', '.join(missing)}")
    path = _check_path(raw["path"])
    term = raw["term"]
    if not isinstance(term, str) or len(term) > _MAX_TERM or find_denied_words(term) != [term]:
        raise BaselineError("term must be exactly one denied term")
    fingerprint = raw["fingerprint"]
    if not isinstance(fingerprint, str) or not _FINGERPRINT.fullmatch(fingerprint):
        raise BaselineError("fingerprint must be 64 lower-case hexadecimal digits")
    count = raw.get("count", 1)
    if type(count) is not int or not 1 <= count <= MAX_BASELINE_COUNT:
        raise BaselineError(f"count must be an integer from 1 to {MAX_BASELINE_COUNT}")
    return BaselineEntry(path, term, fingerprint, check_reason(raw["reason"]), count)


def load_words_baseline(path: Path) -> tuple[BaselineEntry, ...]:
    """Read and check a baseline file; raises ``BaselineError`` naming the file."""
    try:
        with path.open("rb") as handle:
            data = handle.read(MAX_BASELINE_BYTES + 1)
        if len(data) > MAX_BASELINE_BYTES:
            raise BaselineError(f"larger than {MAX_BASELINE_BYTES} bytes")
        document: dict[str, Any] = tomllib.loads(data.decode("utf-8"))
        if unknown := sorted(set(document) - {"version", "entry"}):
            raise BaselineError(f"unknown key(s) {', '.join(unknown)}")
        if type(document.get("version")) is not int or document["version"] != 1:
            raise BaselineError("version must be 1")
        raw_entries = document.get("entry", [])
        if not isinstance(raw_entries, list):
            raise BaselineError("entry must be an array of tables")
        if len(raw_entries) > MAX_BASELINE_ENTRIES:
            raise BaselineError(f"more than {MAX_BASELINE_ENTRIES} entries")
        entries = []
        for number, raw in enumerate(raw_entries, 1):
            try:
                entries.append(_entry(raw))
            except BaselineError as exc:
                raise BaselineError(f"entry {number}: {exc}") from exc
        keys = Counter(e.key for e in entries)
        if twice := [k for k, n in keys.items() if n > 1]:
            raise BaselineError(f"entry {twice[0][0]} {twice[0][1]} is listed twice (use count)")
    except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError, BaselineError) as exc:
        raise BaselineError(f"words baseline {path}: {exc}") from exc
    return tuple(entries)


def baseline_path_in(root: Path, baseline: Path) -> str | None:
    """The baseline file relative to the repository root, or None when it lies outside."""
    try:
        return baseline.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return None


def check_words(root: Path, baseline: Sequence[BaselineEntry], baseline_path: Path) -> WordsResult:
    """Denied terms against the frozen baseline: only listed hits pass, unused entries are stale."""
    hits = scan_hits(
        root,
        baseline_path=baseline_path_in(root, baseline_path),
        baseline_terms={e.term for e in baseline},
        baseline_paths={e.path for e in baseline},
    )
    listed = {e.key: e for e in baseline}
    groups: dict[tuple[str, str, str], list[Hit]] = {}
    for hit in hits:
        groups.setdefault(hit.key, []).append(hit)
    failing: list[tuple[Hit, str]] = []
    found: Counter[tuple[str, str, str]] = Counter()
    for key, group in groups.items():
        entry = listed.get(key)
        if entry is None:
            failing += [(hit, "") for hit in group]
            continue
        found[key] = len(group)
        if len(group) > entry.count:
            note = f" ({len(group)} found, {entry.count} in the baseline)"
            failing += [(hit, note) for hit in group]
    failing.sort(key=lambda item: (item[0].path, item[0].line))
    stale = [
        Finding(
            e.path,
            f"stale baseline entry for {e.term} (fingerprint {e.fingerprint[:12]}, "
            f"{found[e.key]} of {e.count} found)",
        )
        for e in baseline
        if found[e.key] < e.count
    ]
    baselined = sum(n for key, n in found.items() if n <= listed[key].count)
    return WordsResult(_by_line(failing), stale, baselined)


def render_baseline(hits: Sequence[Hit], reason: str) -> tuple[str, int]:
    """The baseline document for the hits (one entry per path, term and line text).

    Raises ``BaselineError`` for any document ``load_words_baseline`` would
    reject (entry values, number of entries, size), so nothing unusable is written.
    """
    reason = check_reason(reason)
    counts = Counter(hit.key for hit in hits)
    order = sorted(
        {hit.key: hit for hit in reversed(hits)}.values(), key=lambda h: (h.path, h.line)
    )
    if len(order) > MAX_BASELINE_ENTRIES:
        raise BaselineError(
            f"{len(order)} entries, the baseline holds at most {MAX_BASELINE_ENTRIES} entries"
        )
    parts = [BASELINE_HEADER, "\nversion = 1\n"]
    for hit in order:
        raw: dict[str, object] = {
            "path": hit.path,
            "term": hit.term,
            "fingerprint": hit.fingerprint,
            "count": counts[hit.key],
            "reason": reason,
        }
        try:
            _entry(raw)
        except BaselineError as exc:
            raise BaselineError(f"{hit.path}:{hit.line}: {exc}") from exc
        parts.append(
            "\n[[entry]]\n"
            f"{_path_line(hit.path)}\n"
            f"{_term_line(hit.term)}\n"
            f'fingerprint = "{hit.fingerprint}"\n'
            + (f"count = {counts[hit.key]}\n" if counts[hit.key] > 1 else "")
            + f"reason = {json.dumps(reason, ensure_ascii=False)}\n"
        )
    text = "".join(parts)
    if (size := len(text.encode("utf-8"))) > MAX_BASELINE_BYTES:
        raise BaselineError(f"{size} bytes, the baseline holds at most {MAX_BASELINE_BYTES} bytes")
    return text, len(order)


def write_baseline(root: Path, baseline: Path, reason: str) -> int:
    """Create the baseline file once from the current hits; refuses an existing file."""
    text, entries = render_baseline(scan_hits(root), reason)
    with baseline.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    return entries


def valid_range(revision_range: str) -> bool:
    return (
        0 < len(revision_range) <= _MAX_RANGE
        and not revision_range.startswith("-")
        and _RANGE.fullmatch(revision_range) is not None
    )


# Start boundary of the commit check, one per repository.
COMMIT_BOUNDARY_FILE = "commit-boundary.toml"
MAX_BOUNDARY_BYTES = 4096
_FULL_SHA = re.compile(r"[0-9a-f]{40}|[0-9a-f]{64}")
_BOUNDARY_KEYS = frozenset({"version", "commit", "reason"})


class CommitBoundaryError(ValueError):
    """The boundary file cannot be used; the message names the file."""


class BoundaryNotAncestorError(CommitBoundaryError):
    """The boundary commit is not an ancestor of the end of the checked range."""


@dataclass(frozen=True)
class CommitBoundary:
    """One commit, named by its full SHA, from which on the commit rules apply.

    The commit itself and all its ancestors are left out of ``check_commits``;
    every later commit is checked. ``reason`` says why the earlier history is
    exempt (one line, no denied term).
    """

    commit: str
    reason: str


def load_commit_boundary(path: Path) -> CommitBoundary:
    """Read and check a boundary file; raises ``CommitBoundaryError`` naming the file."""
    try:
        with path.open("rb") as handle:
            data = handle.read(MAX_BOUNDARY_BYTES + 1)
        if len(data) > MAX_BOUNDARY_BYTES:
            raise CommitBoundaryError(f"larger than {MAX_BOUNDARY_BYTES} bytes")
        document: dict[str, Any] = tomllib.loads(data.decode("utf-8"))
        if unknown := sorted(set(document) - _BOUNDARY_KEYS):
            raise CommitBoundaryError(f"unknown key(s) {', '.join(unknown)}")
        if type(document.get("version")) is not int or document["version"] != 1:
            raise CommitBoundaryError("version must be 1")
        if missing := sorted(_BOUNDARY_KEYS - set(document)):
            raise CommitBoundaryError(f"missing key(s) {', '.join(missing)}")
        commit = document["commit"]
        if not isinstance(commit, str) or not _FULL_SHA.fullmatch(commit):
            raise CommitBoundaryError(
                "commit must be the full SHA of one commit in lower-case hexadecimal digits"
            )
        try:
            reason = check_reason(document["reason"])
        except BaselineError as exc:
            raise CommitBoundaryError(str(exc)) from exc
    except (OSError, UnicodeDecodeError, tomllib.TOMLDecodeError, CommitBoundaryError) as exc:
        raise CommitBoundaryError(f"commit boundary {path}: {exc}") from exc
    return CommitBoundary(commit, reason)


def range_end(revision_range: str) -> str:
    """The revision a range ends at: the right side of ``A..B`` or ``A...B``, else the range."""
    for separator in ("...", ".."):
        if separator in revision_range:
            return revision_range.split(separator, 1)[1]
    return revision_range


def _git_ok(root: Path, *args: str) -> bool:
    try:
        _git(root, *args)
    except subprocess.CalledProcessError:
        return False
    return True


def check_boundary(root: Path, revision_range: str, boundary: CommitBoundary) -> None:
    """The boundary names a commit of the repository that the range end descends from."""
    if not valid_range(revision_range):
        raise ValueError(f"invalid revision range {revision_range!r}")
    if not _git_ok(root, "cat-file", "-e", f"{boundary.commit}^{{commit}}"):
        raise CommitBoundaryError(f"commit boundary: no commit {boundary.commit} in the repository")
    end = range_end(revision_range)
    if not _git_ok(root, "merge-base", "--is-ancestor", boundary.commit, end):
        raise BoundaryNotAncestorError(
            f"commit boundary {boundary.commit} is not an ancestor of {end}, "
            "the end of the checked range"
        )


def check_commits(
    root: Path,
    revision_range: str,
    email_domain: str,
    boundary: CommitBoundary | None = None,
) -> list[Finding]:
    """Check author, committer, sign-off and wording of every commit in the range.

    With a ``boundary`` the boundary commit and its ancestors are left out; the
    boundary must be an ancestor of the end of the range (``check_boundary``).
    """
    if not valid_range(revision_range):
        raise ValueError(f"invalid revision range {revision_range!r}")
    excluded: tuple[str, ...] = ()
    if boundary is not None:
        check_boundary(root, revision_range, boundary)
        excluded = (f"^{boundary.commit}",)
    log = _git(
        root,
        "log",
        "-z",
        "--format=%H%x1f%an%x1f%ae%x1f%cn%x1f%ce%x1f%B",
        revision_range,
        *excluded,
        "--",
    )
    suffix = "@" + email_domain.lower()
    findings = []
    for raw in filter(None, log.split("\0")):
        sha, author, author_email, _, committer_email, message = raw.split("\x1f", 5)
        where = sha[:12]
        if not author_email.lower().endswith(suffix):
            findings.append(Finding(where, f"author email {author_email} is not {suffix}"))
        if not committer_email.lower().endswith(suffix):
            findings.append(Finding(where, f"committer email {committer_email} is not {suffix}"))
        if f"Signed-off-by: {author} <{author_email}>" not in message:
            findings.append(Finding(where, "missing sign-off of the author"))
        if _CO_AUTHOR.search(message):
            findings.append(Finding(where, "co-author trailer is not allowed"))
        words = find_denied_words(message)
        if words:
            findings.append(Finding(where, f"denied term(s) in message: {', '.join(words)}"))
    return findings
