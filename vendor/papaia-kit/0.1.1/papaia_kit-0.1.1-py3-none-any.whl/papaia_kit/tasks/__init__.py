"""'Meine Aufgaben': the task item format and the one collector (PLT-81, RE-71).

``papaia.task-item/1`` (``schemas/task-item.v1.schema.json``) is the form in
which Flow, Data and Studio serve the tasks of a person at
``GET /api/v1/me/tasks`` and the counts at ``GET /api/v1/me/tasks/summary``.
``collect`` is the only place that merges them: Me, Studio and Flow call it
and show its list and its count. See ``contract/tasks.md``::

    from papaia_kit import tasks as pk_tasks

    result = pk_tasks.collect(token, catalog=catalog, exchange=exchange_client)
"""

from papaia_kit.tasks._items import (
    FORMAT,
    MAX_BODY,
    SCHEMA_FILE,
    Summary,
    TaskContractError,
    check_summary,
    check_task_list,
    parse_summary,
    parse_task_list,
    validate_task_item,
)
from papaia_kit.tasks.collector import (
    MAX_TIMEOUT,
    SOURCES,
    SUMMARY_PATH,
    TASKS_PATH,
    Collected,
    Exchanger,
    LocalSource,
    TaskSource,
    collect,
    hint_line,
)
from papaia_kit.tasks.transport import GetTransport, UrllibGetTransport

__all__ = [
    "FORMAT",
    "MAX_BODY",
    "MAX_TIMEOUT",
    "SCHEMA_FILE",
    "SOURCES",
    "SUMMARY_PATH",
    "TASKS_PATH",
    "Collected",
    "Exchanger",
    "GetTransport",
    "LocalSource",
    "Summary",
    "TaskContractError",
    "TaskSource",
    "UrllibGetTransport",
    "check_summary",
    "check_task_list",
    "collect",
    "hint_line",
    "parse_summary",
    "parse_task_list",
    "validate_task_item",
]
