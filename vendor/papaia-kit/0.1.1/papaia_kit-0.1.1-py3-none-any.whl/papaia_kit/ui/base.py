"""Base layer ``pk.base``: contract, expected computed styles and fixture page.

``ui/base.css`` styles the plain semantic HTML that server-rendered modules
write inside ``#pk-main`` and ``dialog.pk-dialog`` (headings, paragraphs,
lists, links, fieldsets, labels and form controls without a wrapper class).
``contract/base.yaml`` names the elements of the fixture page and the computed
styles read from each (``contract/base.md``); :func:`expected_values` resolves
the kit variables per theme with the comparison rule of the specimen page
(:mod:`papaia_kit.ui.specimen`). :func:`base_page` is the fixture document the
browser test (``js/test-browser/base.browser.ts``) loads.
"""

from __future__ import annotations

import copy
import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import yaml
from markupsafe import Markup

from papaia_kit._resources import contract_dir, tokens_dir
from papaia_kit.ui.shell import parse_shell_input, render_shell, shell_environment
from papaia_kit.ui.specimen import (
    REFERENCE_INPUT,
    first_family,
    normalize_color,
    normalize_length,
)
from papaia_kit.ui.tokens import THEMES, TokenSet, load_tokens

FORMAT = "papaia.base/1"
EXPECTED_FORMAT = "papaia.base-expected/1"
STATES = frozenset({"rest", "hover", "active", "disabled"})
#: Input types the base layer styles like a ``.pk-field`` control (ticket order).
BASE_INPUT_TYPES = ("text", "email", "search", "number", "date", "time", "url", "password")
COLOR_PROPS = frozenset(
    {"background-color", "color", "border-top-color", "text-decoration-color", "accent-color"}
)
LENGTH_PROPS = frozenset(
    {
        "font-size",
        "line-height",
        "margin-top",
        "margin-bottom",
        "padding-top",
        "padding-left",
        "border-top-width",
        "border-top-left-radius",
        "height",
        "width",
        "max-width",
        "text-underline-offset",
        "text-decoration-thickness",
    }
)
KEYWORD_PROPS = frozenset(
    {"border-top-style", "display", "box-sizing", "list-style-type", "text-decoration-line"}
)
PROPERTIES = COLOR_PROPS | LENGTH_PROPS | KEYWORD_PROPS | {"font-family", "font-weight", "opacity"}
MAX_FILE_BYTES = 256 * 1024
MAX_NAME = 64
MAX_VALUE = 64
VIEWPORT_MIN, VIEWPORT_MAX = 200, 4000
MAX_VAR_DEPTH = 8

_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_VAR = re.compile(r"^var\((--pk-[a-z0-9-]+)\)$")
_VAR_ANY = re.compile(r"var\((--pk-[a-z0-9-]+)\)")
_KEYWORD = re.compile(r"^[a-z-]{1,32}$")
_NUMBER = re.compile(r"^\d+(?:\.\d+)?$")
_SELECTOR = re.compile(r'^[a-z0-9\[\]="\-. #]{1,120}$')

TEXTS: dict[str, dict[str, str]] = {
    "de": {
        "title": "Benachrichtigungen",
        "home": "Übersicht",
        "intro": "Wie und wann Abläufe Sie erreichen.",
        "intro_more": "Datenklasse: personenbezogen. Die Einstellungen gelten für alle Geräte.",
        "h2": "Kanäle",
        "h3": "Reihenfolge",
        "h4": "Ruhezeiten",
        "after_heading": "Aufforderungen zum Handeln kommen immer an.",
        "ul1": "E-Mail an die hinterlegte Adresse",
        "ul2": "Chat der Assistenz",
        "ol1": "Zuerst per E-Mail",
        "ol2": "Danach im Chat",
        "link": "Mehr in der Hilfe",
        "link_hover": "Zur Übersicht",
        "legend": "Kontaktdaten",
        "text": "Name",
        "email": "Mail-Adresse",
        "search": "Suchbegriff",
        "number": "Anzahl der Erinnerungen",
        "date": "Beginn",
        "time": "Uhrzeit",
        "url": "Webhook-Adresse",
        "password": "Kennwort des Webhooks",
        "hover": "Ort",
        "invalid": "Telefon",
        "invalid_text": "Geben Sie eine Telefonnummer mit Vorwahl ein.",
        "disabled": "Kundennummer (gesperrt)",
        "select": "Sprache",
        "option_de": "Deutsch",
        "option_en": "Englisch",
        "textarea": "Notiz",
        "choices": "Hinweise zur Information",
        "checkbox": "Ruhezeiten einhalten",
        "radio_single": "Einzeln",
        "radio_daily": "Einmal täglich gesammelt",
        "inline": "Neuer Kanal",
        "add": "Hinzufügen",
        "save": "Speichern",
        "cancel": "Abbrechen",
        "delete": "Löschen",
        "move": "Nach oben",
        "locked": "gesperrt",
    },
    "en": {
        "title": "Notifications",
        "home": "Overview",
        "intro": "How and when workflows reach you.",
        "intro_more": "Data class: personal. The settings apply to every device.",
        "h2": "Channels",
        "h3": "Order",
        "h4": "Quiet hours",
        "after_heading": "Requests to act always reach you.",
        "ul1": "Mail to the stored address",
        "ul2": "Assistant chat",
        "ol1": "First by mail",
        "ol2": "Then in the chat",
        "link": "More in the help",
        "link_hover": "To the overview",
        "legend": "Contact details",
        "text": "Name",
        "email": "Mail address",
        "search": "Search term",
        "number": "Number of reminders",
        "date": "Start",
        "time": "Time",
        "url": "Webhook address",
        "password": "Webhook password",
        "hover": "Place",
        "invalid": "Phone",
        "invalid_text": "Enter a phone number with area code.",
        "disabled": "Customer number (locked)",
        "select": "Language",
        "option_de": "German",
        "option_en": "English",
        "textarea": "Note",
        "choices": "Information notices",
        "checkbox": "Keep quiet hours",
        "radio_single": "One by one",
        "radio_daily": "Once a day, collected",
        "inline": "New channel",
        "add": "Add",
        "save": "Save",
        "cancel": "Cancel",
        "delete": "Delete",
        "move": "Move up",
        "locked": "locked",
    },
}


class BaseError(ValueError):
    """The base contract or a request for the fixture page is not valid."""


@dataclass(frozen=True)
class BaseElement:
    name: str
    state: str
    selector: str
    not_default: tuple[str, ...]
    expect: Mapping[str, str]


@dataclass(frozen=True)
class BaseContract:
    viewports: Mapping[str, Mapping[str, int]]
    default_props: tuple[str, ...]
    elements: tuple[BaseElement, ...]


# --- contract ---------------------------------------------------------------------


def load_base(path: Path | None = None, tokens: TokenSet | None = None) -> BaseContract:
    """Read ``contract/base.yaml`` (or ``path``) strictly."""
    source = path or contract_dir() / "base.yaml"
    raw = source.read_bytes()
    if len(raw) > MAX_FILE_BYTES:
        raise BaseError(f"{source.name}: larger than {MAX_FILE_BYTES} bytes")
    return parse_base(
        yaml.safe_load(raw.decode("utf-8")),
        tokens or load_tokens(tokens_dir() / "papaia.tokens.json"),
    )


def _keys(where: str, data: object, required: set[str], optional: frozenset[str]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise BaseError(f"{where}: expected a mapping")
    unknown = set(data) - required - optional
    if unknown:
        raise BaseError(f"{where}: unknown field {sorted(map(str, unknown))[0]!r}")
    missing = required - set(data)
    if missing:
        raise BaseError(f"{where}: missing field {sorted(missing)[0]!r}")
    return data


def parse_base(doc: object, tokens: TokenSet) -> BaseContract:
    """Check a decoded base contract against its format and the token names."""
    data = _keys("base", doc, {"format", "viewports", "default_props", "elements"}, frozenset())
    if data["format"] != FORMAT:
        raise BaseError(f"base: format must be {FORMAT!r}")
    viewports = _keys("viewports", data["viewports"], {"desktop", "narrow"}, frozenset())
    for key, value in viewports.items():
        size = _keys(f"viewports/{key}", value, {"width", "height"}, frozenset())
        if not all(isinstance(v, int) and VIEWPORT_MIN <= v <= VIEWPORT_MAX for v in size.values()):
            raise BaseError(f"viewports/{key}: width and height between 200 and 4000")
    defaults = data["default_props"]
    if (
        not isinstance(defaults, list)
        or not defaults
        or not all(isinstance(p, str) and p in PROPERTIES for p in defaults)
    ):
        raise BaseError("default_props: expected a non-empty list of read properties")
    if not isinstance(data["elements"], list) or not data["elements"]:
        raise BaseError("elements: expected a non-empty list")
    known = _all_variables(tokens)
    elements: list[BaseElement] = []
    for index, item in enumerate(data["elements"]):
        element = _element(f"elements/{index}", item, known, frozenset(defaults))
        if any(e.name == element.name for e in elements):
            raise BaseError(f"elements/{index}: duplicate element {element.name!r}")
        elements.append(element)
    return BaseContract(
        viewports=dict(viewports), default_props=tuple(defaults), elements=tuple(elements)
    )


def _element(where: str, item: object, known: set[str], defaults: frozenset[str]) -> BaseElement:
    entry = _keys(where, item, {"name", "state", "not_default", "expect"}, frozenset({"selector"}))
    name = entry["name"]
    if not isinstance(name, str) or not _NAME.fullmatch(name) or len(name) > MAX_NAME:
        raise BaseError(f"{where}: name must be lower-case words joined by '-'")
    if entry["state"] not in STATES:
        raise BaseError(f"{where}: state must be one of {sorted(STATES)}")
    selector = entry.get("selector", f'[data-pk-base="{name}"]')
    if not isinstance(selector, str) or not _SELECTOR.fullmatch(selector):
        raise BaseError(f"{where}: selector has characters outside the allowed set")
    not_default = entry["not_default"]
    if (
        not isinstance(not_default, list)
        or not not_default
        or not all(isinstance(p, str) and p in defaults for p in not_default)
    ):
        raise BaseError(f"{where}/not_default: expected a non-empty list from default_props")
    expect = entry["expect"]
    if not isinstance(expect, dict) or not expect:
        raise BaseError(f"{where}/expect: expected a non-empty mapping")
    for prop, value in expect.items():
        if prop not in PROPERTIES:
            raise BaseError(f"{where}/expect: property {prop!r} is not read")
        if not isinstance(value, str) or len(value) > MAX_VALUE:
            raise BaseError(f"{where}/expect/{prop}: expected a short string")
        ref = _VAR.fullmatch(value)
        if ref and ref.group(1) not in known:
            raise BaseError(f"{where}/expect/{prop}: unknown variable {ref.group(1)}")
        if not ref:
            normalize_value(prop, value)
    return BaseElement(name, entry["state"], selector, tuple(not_default), dict(expect))


def _all_variables(tokens: TokenSet) -> set[str]:
    names = set(tokens.shared)
    for theme in tokens.themes.values():
        names |= set(theme.variables)
    return names


# --- comparison rule (contract/specimen.md, extended by the properties above) ----------


def _number(value: float) -> str:
    return f"{int(value)}" if value == int(value) else f"{value:g}"


def normalize_value(prop: str, raw: str) -> str:
    """Normalise one expected value; refuses what the comparison rule cannot read."""
    if prop in COLOR_PROPS:
        color = normalize_color(raw)
        if color is None:
            raise BaseError(f"{prop}: {raw!r} is not a colour")
        return color
    if prop in LENGTH_PROPS:
        length = "0px" if raw == "0" else normalize_length(raw)
        if length is None:
            raise BaseError(f"{prop}: {raw!r} is not a length in px or rem")
        return length
    if prop == "font-family":
        family = first_family(raw)
        if not family:
            raise BaseError("font-family: empty")
        return family
    if prop == "font-weight":
        if not re.fullmatch(r"[1-9]00", raw):
            raise BaseError(f"font-weight: {raw!r} is not a weight 100-900")
        return raw
    if prop == "opacity":
        if not _NUMBER.fullmatch(raw) or float(raw) > 1:
            raise BaseError(f"opacity: {raw!r} is not a number between 0 and 1")
        return _number(round(float(raw), 2))
    if not _KEYWORD.fullmatch(raw):
        raise BaseError(f"{prop}: {raw!r} is not a keyword")
    return raw


def _variables(tokens: TokenSet, theme: str) -> dict[str, str]:
    merged = {**tokens.shared, **tokens.themes[theme].variables}

    def resolve(name: str, depth: int = 0) -> str:
        if depth > MAX_VAR_DEPTH:
            raise BaseError(f"{name}: variable references nest too deep")
        if name not in merged:
            raise BaseError(f"unknown variable {name}")
        return _VAR_ANY.sub(lambda m: resolve(m.group(1), depth + 1), merged[name])

    return {name: resolve(name) for name in merged}


def expected_values(base: BaseContract, tokens: TokenSet, theme: str) -> dict[str, Any]:
    """Expected computed styles of the fixture page for ``theme``."""
    if theme not in THEMES:
        raise BaseError(f"theme must be one of {list(THEMES)}")
    variables = _variables(tokens, theme)
    elements: dict[str, dict[str, str]] = {}
    for element in base.elements:
        values: dict[str, str] = {}
        for prop, value in sorted(element.expect.items()):
            ref = _VAR.fullmatch(value)
            values[prop] = normalize_value(prop, variables[ref.group(1)] if ref else value)
        elements[element.name] = values
    return {
        "format": EXPECTED_FORMAT,
        "theme": theme,
        "viewports": {k: dict(v) for k, v in base.viewports.items()},
        "states": {e.name: e.state for e in base.elements},
        "selectors": {e.name: e.selector for e in base.elements},
        "not_default": {e.name: list(e.not_default) for e in base.elements},
        "elements": elements,
    }


def expected_text(base: BaseContract, tokens: TokenSet, theme: str) -> str:
    return json.dumps(expected_values(base, tokens, theme), indent=2, ensure_ascii=False) + "\n"


# --- fixture page -------------------------------------------------------------------


def _texts(lang: str) -> dict[str, str]:
    if lang not in TEXTS:
        raise BaseError(f"lang must be one of {sorted(TEXTS)}")
    return TEXTS[lang]


def base_body(lang: str) -> Markup:
    """Fixture content (inside ``main``): plain semantic HTML, autoescaped."""
    macro = shell_environment().get_template("pk/base.html").module.base  # type: ignore[attr-defined]
    body: Markup = macro(_texts(lang), BASE_INPUT_TYPES)
    return body


class _Hooks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.names: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        for key, value in attrs:
            if key == "data-pk-base" and value:
                self.names.append(value)


def check_base_markup(html: str, base: BaseContract) -> list[str]:
    """Problems of a fixture page's markup: hooks missing, doubled or unknown."""
    parser = _Hooks()
    parser.feed(html)
    parser.close()
    hooked = {e.name for e in base.elements if e.selector == f'[data-pk-base="{e.name}"]'}
    problems = [f"missing: {n}" for n in sorted(hooked) if n not in parser.names]
    problems += [f"more than once: {n}" for n in sorted(hooked) if parser.names.count(n) > 1]
    names = {e.name for e in base.elements}
    problems += [f"unknown: {n}" for n in sorted(set(parser.names) - names)]
    return problems


def base_page(*, lang: str, theme: str) -> str:
    """The whole fixture document inside the shell of the reference input (module flow)."""
    texts = _texts(lang)
    if theme not in THEMES:
        raise BaseError(f"theme must be one of {list(THEMES)}")
    doc = copy.deepcopy(
        json.loads(
            (contract_dir() / "shell" / "inputs" / REFERENCE_INPUT).read_text(encoding="utf-8")
        )
    )
    doc.update(locale=lang, theme=theme)
    doc["page"] = {
        "title": texts["title"],
        "breadcrumb": [{"label": texts["home"], "href": "/"}, {"label": texts["title"]}],
    }
    doc["nav"] = {"current": "/_kit/base", "groups": []}
    return render_shell(parse_shell_input(doc), base_body(lang))
