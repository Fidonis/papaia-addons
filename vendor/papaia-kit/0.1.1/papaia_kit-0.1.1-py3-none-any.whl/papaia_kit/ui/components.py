"""Fixture page of the components (layout, section head, card, module tile, list, badge,
description list, actions menu, welcome).

``components_page`` puts the example markup of every component of
``contract/patterns/patterns.yaml`` into the shell of the reference input, one
``<section data-pk-component="<id>">`` per component. The browser test of the
kit (``js/test-browser/components.browser.ts``) checks columns, baselines, tab
stops, colours and accessibility on it. Examples write symbol references as
fragments (``#pk-icon-<name>``); the page points them at the kit's sprite.
"""

from __future__ import annotations

import copy
import json

from markupsafe import Markup, escape

from papaia_kit._resources import contract_dir
from papaia_kit.ui import messages
from papaia_kit.ui.patterns import PatternError, load_components
from papaia_kit.ui.shell import ASSET_ROOT, parse_shell_input, render_shell
from papaia_kit.ui.specimen import REFERENCE_INPUT
from papaia_kit.ui.tokens import THEMES

__all__ = ["PAGE_PATH", "components_body", "components_page"]

PAGE_PATH = "/_kit/components"
_TITLES = {
    "de": {
        "page": "Bausteine",
        "home": "Übersicht",
        "layout": "Anordnung",
        "section": "Abschnittskopf",
        "card": "Karte",
        "tile": "Modulkachel",
        "list": "Liste",
        "badge": "Kennzeichen und Zähler",
        "dl": "Beschreibungsliste",
        "menu": "Weitere Aktionen",
        "welcome": "Begrüßung",
        "new": "Aufgabe anlegen",
        "export": "Als CSV exportieren",
        "delete": "Erledigte löschen",
    },
    "en": {
        "page": "Components",
        "home": "Overview",
        "layout": "Layout",
        "section": "Section head",
        "card": "Card",
        "tile": "Module tile",
        "list": "List",
        "badge": "Badge and count",
        "dl": "Description list",
        "menu": "More actions",
        "welcome": "Welcome",
        "new": "New task",
        "export": "Export as CSV",
        "delete": "Delete completed",
    },
}


def _example_markup(component_id: str, lang: str) -> str:
    path = contract_dir() / "patterns" / "examples" / f"{component_id}.{lang}.html"
    text = path.read_text(encoding="utf-8")
    return text.replace('href="#pk-icon-', f'href="{ASSET_ROOT}/icons/sprite.svg#pk-icon-')


def components_body(lang: str) -> Markup:
    """Content of ``main``: the examples of every component, in the order of the contract."""
    if lang not in messages.LANGUAGES:
        raise PatternError(f"patterns: language must be one of {list(messages.LANGUAGES)}")
    titles = _TITLES[lang]
    parts: list[str] = []
    for component in load_components():
        heading = f"pk-component-{component.id}"
        title = titles.get(component.id, component.id)
        parts.append(
            f'<section data-pk-component="{component.id}" aria-labelledby="{heading}">\n'
            f'<h2 id="{heading}">{escape(title)}</h2>\n'
            f"{_example_markup(component.id, lang)}</section>\n"
        )
    return Markup("".join(parts))  # noqa: S704 - the kit's own contract files, not input


def components_page(*, lang: str, theme: str) -> str:
    """The whole fixture document inside the shell of the reference input."""
    if theme not in THEMES:
        raise PatternError(f"patterns: theme must be one of {list(THEMES)}")
    body = components_body(lang)
    titles = _TITLES[lang]
    doc = copy.deepcopy(
        json.loads(
            (contract_dir() / "shell" / "inputs" / REFERENCE_INPUT).read_text(encoding="utf-8")
        )
    )
    doc.update(locale=lang, theme=theme)
    doc["page"] = {
        "title": titles["page"],
        "breadcrumb": [{"label": titles["home"], "href": "/"}, {"label": titles["page"]}],
        # Page header of interface spec 2.1: one primary button, the rest in the menu.
        "primary_action": {"label": titles["new"], "href": "/tasks/new"},
        "more_actions": [
            {"label": titles["export"], "href": "/tasks/export"},
            {
                "label": titles["delete"],
                "href": "/tasks/done/delete",
                "post": True,
                "destructive": True,
            },
        ],
    }
    doc["nav"] = {"current": PAGE_PATH, "groups": []}
    return render_shell(parse_shell_input(doc), body)
