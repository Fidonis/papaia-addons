"""Pattern 9: dates, times and numbers in fixed formats (``contract/vectors/formats.json``).

The formats are fixed patterns with the kit's own month and weekday lists, not
locale data, so every module and both language bindings print the same
characters. The server formats a point in time in the time zone of the person
(``time_zone`` from ``prefs``). Whether a weekday stands before the date
depends on the kind of time value (``WEEKDAY_KINDS``); the date itself never
carries one.
"""

from __future__ import annotations

import functools
import html
import json
import math
import re
from collections.abc import Mapping
from dataclasses import dataclass
from datetime import datetime
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from types import MappingProxyType
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from papaia_kit._resources import contract_dir

LANGUAGES = ("de", "en")
MAX_DECIMALS = 12
_MAX_NUMBER_CHARS = 64
_MAX_ZONE_CHARS = 64
_MAX_NAME_CHARS = 16  # month or weekday name
_MAX_PART_CHARS = 32  # pattern or separator
_GROUP = 3  # digits per thousands group
_ZONE = re.compile(r"^[A-Za-z][A-Za-z0-9_+-]*(?:/[A-Za-z0-9_+-]+)*$")
_NUMBER = re.compile(r"^-?\d+(?:\.\d+)?$")
_FIELD = re.compile(r"\{([A-Za-z]+)\}")
_DATE_FIELDS = frozenset({"d", "dd", "mm", "mon", "yyyy"})
_TIME_FIELDS = frozenset({"HH", "MM"})
_LANGUAGE_FIELDS = {
    "date",
    "time",
    "weekdays",
    "weekday_separator",
    "date_time_separator",
    "decimal",
    "group",
}


class FormatError(ValueError):
    """Input to a format function or the format file is not valid."""


@dataclass(frozen=True)
class Language:
    date: str
    time: str
    months: tuple[str, ...]
    weekdays: tuple[str, ...]
    weekday_separator: str
    date_time_separator: str
    decimal: str
    group: str


@dataclass(frozen=True)
class Moment:
    """A point in time formatted for one person; ``text`` is what the person reads."""

    iso: str
    weekday: str | None
    date: str
    time: str
    weekday_separator: str
    date_time_separator: str

    @property
    def stamp(self) -> str:
        """Date and time, the content of the ``<time>`` element."""
        return f"{self.date}{self.date_time_separator}{self.time}"

    @property
    def text(self) -> str:
        if self.weekday is None:
            return self.stamp
        return f"{self.weekday}{self.weekday_separator}{self.stamp}"


def _fail(message: str) -> FormatError:
    return FormatError(f"format: {message}")


def _strings(value: object, count: int, where: str) -> tuple[str, ...]:
    if not isinstance(value, list) or len(value) != count:
        raise _fail(f"{where}: expected {count} strings")
    if not all(isinstance(item, str) and 0 < len(item) <= _MAX_NAME_CHARS for item in value):
        raise _fail(f"{where}: expected {count} strings")
    return tuple(value)


def _language(lang: str, raw: object) -> Language:
    if not isinstance(raw, dict):
        raise _fail(f"languages.{lang}: expected a mapping")
    needed = set(_LANGUAGE_FIELDS)
    date = raw.get("date")
    if isinstance(date, str) and "{mon}" in date:
        needed.add("months")
    if missing := needed - set(raw):
        raise _fail(f"languages.{lang}: missing {sorted(missing)}")
    if unknown := set(raw) - needed:
        raise _fail(f"languages.{lang}: unknown {sorted(unknown)}")
    for key in needed - {"weekdays", "months"}:
        if not isinstance(raw[key], str) or not 0 < len(raw[key]) <= _MAX_PART_CHARS:
            raise _fail(f"languages.{lang}.{key}: expected a short string")
    if not set(_FIELD.findall(raw["date"])) <= _DATE_FIELDS:
        raise _fail(f"languages.{lang}.date: unknown field")
    if not set(_FIELD.findall(raw["time"])) <= _TIME_FIELDS:
        raise _fail(f"languages.{lang}.time: unknown field")
    months = _strings(raw["months"], 12, f"languages.{lang}.months") if "months" in raw else ()
    return Language(
        date=raw["date"],
        time=raw["time"],
        months=months,
        weekdays=_strings(raw["weekdays"], 7, f"languages.{lang}.weekdays"),
        weekday_separator=raw["weekday_separator"],
        date_time_separator=raw["date_time_separator"],
        decimal=raw["decimal"],
        group=raw["group"],
    )


def parse_formats(data: object) -> tuple[dict[str, Language], dict[str, bool]]:
    """Languages and kinds of a format document; raises ``FormatError`` naming the field."""
    if not isinstance(data, dict) or data.get("version") != 1:
        raise _fail("expected a mapping with version 1")
    if unknown := set(data) - {"version", "description", "languages", "kinds", "vectors"}:
        raise _fail(f"unknown {sorted(unknown)}")
    langs = data.get("languages")
    if not isinstance(langs, dict) or set(langs) != set(LANGUAGES):
        raise _fail(f"languages: expected exactly {list(LANGUAGES)}")
    kinds = data.get("kinds")
    if not isinstance(kinds, dict) or not kinds:
        raise _fail("kinds: expected a mapping")
    weekday: dict[str, bool] = {}
    for kind, spec in kinds.items():
        if not isinstance(spec, dict) or set(spec) != {"weekday"}:
            raise _fail(f"kinds.{kind}: expected exactly the field weekday")
        if not isinstance(spec["weekday"], bool):
            raise _fail(f"kinds.{kind}.weekday: expected true or false")
        weekday[str(kind)] = spec["weekday"]
    return {lang: _language(lang, langs[lang]) for lang in LANGUAGES}, weekday


@functools.cache
def _load() -> tuple[dict[str, Language], dict[str, bool]]:
    path = contract_dir() / "vectors" / "formats.json"
    data: Any = json.loads(path.read_text(encoding="utf-8"))
    return parse_formats(data)


# Kind of time value -> whether a weekday stands before the date (Ä-31).
WEEKDAY_KINDS: Mapping[str, bool] = MappingProxyType(_load()[1])


def _lang(lang: object) -> Language:
    if not isinstance(lang, str) or lang not in LANGUAGES:
        raise _fail(f"unknown language, expected one of {list(LANGUAGES)}")
    return _load()[0][lang]


def _zone(time_zone: object) -> ZoneInfo:
    if (
        not isinstance(time_zone, str)
        or len(time_zone) > _MAX_ZONE_CHARS
        or not _ZONE.fullmatch(time_zone)
    ):
        raise _fail("time zone must be an IANA name such as Europe/Berlin")
    try:
        return ZoneInfo(time_zone)
    except (ZoneInfoNotFoundError, ValueError) as exc:
        raise _fail("unknown time zone") from exc


def _fill(pattern: str, fields: dict[str, str]) -> str:
    return _FIELD.sub(lambda m: fields[m.group(1)], pattern)


def format_moment(value: object, *, kind: object, lang: object, time_zone: object) -> Moment:
    """Format ``value`` (with offset) for a person reading ``lang`` in ``time_zone``."""
    if not isinstance(value, datetime) or value.utcoffset() is None:
        raise _fail("value must be a datetime with time zone or offset")
    kinds = _load()[1]
    if not isinstance(kind, str) or kind not in kinds:
        raise _fail(f"unknown kind of time value, expected one of {sorted(kinds)}")
    spec = _lang(lang)
    local = value.astimezone(_zone(time_zone))
    fields = {
        "d": str(local.day),
        "dd": f"{local.day:02d}",
        "mm": f"{local.month:02d}",
        "mon": spec.months[local.month - 1] if spec.months else "",
        "yyyy": f"{local.year:04d}",
        "HH": f"{local.hour:02d}",
        "MM": f"{local.minute:02d}",
    }
    return Moment(
        iso=local.isoformat(timespec="seconds"),
        weekday=spec.weekdays[local.weekday()] if kinds[kind] else None,
        date=_fill(spec.date, fields),
        time=_fill(spec.time, fields),
        weekday_separator=spec.weekday_separator,
        date_time_separator=spec.date_time_separator,
    )


def moment_html(moment: Moment) -> str:
    """Markup of pattern 9: weekday as its own element before ``<time>``, escaped."""
    stamp = (
        f'<time datetime="{html.escape(moment.iso, quote=True)}">'
        f"{html.escape(moment.stamp, quote=False)}</time>"
    )
    if moment.weekday is None:
        return stamp
    weekday = html.escape(moment.weekday, quote=False)
    separator = html.escape(moment.weekday_separator, quote=False)
    return f"<span data-pk-weekday>{weekday}</span>{separator}{stamp}"


def _decimal(value: object) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise _fail("number expected")
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            raise _fail("number must be finite")
        value = repr(value)
        if "e" in value or "E" in value:
            raise _fail("number out of range")
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise _fail("number must be finite")
        return value
    if isinstance(value, str) and len(value) <= _MAX_NUMBER_CHARS and _NUMBER.fullmatch(value):
        try:
            return Decimal(value)
        except InvalidOperation as exc:  # pragma: no cover - the pattern admits only digits
            raise _fail("number expected") from exc
    raise _fail("number expected (int, float, Decimal or a plain decimal string)")


def format_number(value: object, lang: object, decimals: object = None) -> str:
    """``1234567.5`` → de ``1.234.567,5``, en ``1,234,567.5``; ``decimals`` rounds half up."""
    spec = _lang(lang)
    number = _decimal(value)
    if decimals is not None:
        if isinstance(decimals, bool) or not isinstance(decimals, int):
            raise _fail("decimals must be an integer")
        if not 0 <= decimals <= MAX_DECIMALS:
            raise _fail(f"decimals must be between 0 and {MAX_DECIMALS}")
        number = number.quantize(Decimal(1).scaleb(-decimals), rounding=ROUND_HALF_UP)
    if len(number.as_tuple().digits) > _MAX_NUMBER_CHARS:
        raise _fail("number has too many digits")
    plain = format(abs(number), "f")
    whole, _, fraction = plain.partition(".")
    groups: list[str] = []
    while len(whole) > _GROUP:
        groups.insert(0, whole[-_GROUP:])
        whole = whole[:-_GROUP]
    groups.insert(0, whole)
    text = spec.group.join(groups)
    if fraction:
        text = f"{text}{spec.decimal}{fraction}"
    negative = number.is_signed() and any(number.as_tuple().digits)
    return f"-{text}" if negative else text
