"""Page list: module parts ``ui/pages.yaml`` and their union ``contract/pages.yaml``.

Interface spec 3.9. Each module keeps its part (``papaia.pages-part/1``); the
page list of a run (``papaia.pages/1``) is the union of the parts of the bill
of materials. :func:`load_part` checks one part and :func:`union` builds the
list; a part without ``signed_off_by`` or with a schema error is rejected.

Checks beyond the schema ``contract/pages.schema.json``:

- every row names the module of its part, and no path is listed twice;
- every part lists ``/help``, the specimen page ``/_kit/specimen`` and the
  state page "Kein Zugang" (``state: no_access``, kind ``zustand``);
- every guided path (``leitweg``) has a unique name, its steps are numbered
  1, 2, 3, ... and every step's path is a page of the part;
- in the union, every module appears once.

Messages name the place and the rule; they quote field names and checked paths,
never free text of the file.
"""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping
from functools import lru_cache
from typing import Any

import yaml
from jsonschema import Draft202012Validator, FormatChecker

from papaia_kit._resources import contract_dir

__all__ = [
    "MAX_PART_BYTES",
    "PAGES_FORMAT",
    "PART_FORMAT",
    "REQUIRED_PATHS",
    "PagesError",
    "dump_pages",
    "load_pages",
    "load_part",
    "union",
]

PART_FORMAT = "papaia.pages-part/1"
PAGES_FORMAT = "papaia.pages/1"
MAX_PART_BYTES = 1024 * 1024
REQUIRED_PATHS = ("/help", "/_kit/specimen")
NO_ACCESS = "no_access"
_MAX_PROBLEMS = 20


class PagesError(ValueError):
    """A part or a page list failed a check. ``problems`` lists place and rule."""

    def __init__(self, problems: Iterable[str]) -> None:
        self.problems = tuple(problems)[:_MAX_PROBLEMS] or ("invalid",)
        super().__init__("; ".join(self.problems))


class _UniqueKeyLoader(yaml.SafeLoader):
    """Safe loader that rejects a mapping key written twice."""


def _mapping(loader: _UniqueKeyLoader, node: yaml.MappingNode) -> dict[Any, Any]:
    keys = [loader.construct_object(k) for k, _ in node.value]
    if len(keys) != len(set(map(repr, keys))):
        raise yaml.constructor.ConstructorError(None, None, "duplicate key", node.start_mark)
    return loader.construct_mapping(node)


_UniqueKeyLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


@lru_cache(maxsize=2)
def _validator(definition: str) -> Draft202012Validator:
    # Validate against the one definition the format names, so errors point
    # into the document instead of at the top-level oneOf.
    schema = json.loads((contract_dir() / "pages.schema.json").read_text(encoding="utf-8"))
    schema.pop("oneOf")
    schema["$ref"] = f"#/$defs/{definition}"
    return Draft202012Validator(schema, format_checker=FormatChecker())


def load_part(data: bytes, *, source: str = "ui/pages.yaml") -> dict[str, Any]:
    """Check one module part and return it as plain data."""
    document = _read(data, source)
    _check_schema(document, PART_FORMAT, source)
    _check_part(document, source)
    return dict(document)


def load_pages(data: bytes, *, source: str = "contract/pages.yaml") -> dict[str, Any]:
    """Check a page list built by :func:`union`."""
    document = _read(data, source)
    _check_schema(document, PAGES_FORMAT, source)
    # Every row must belong to a signed module entry, and each module has one
    # entry; otherwise rows could pass without signed_off_by or required pages.
    problems: list[str] = []
    entries: set[str] = set()
    for index, module in enumerate(document["modules"]):
        if module["module"] in entries:
            problems.append(
                f"{source}: modules/{index}: {module['module']} listed twice in modules"
            )
        entries.add(module["module"])
    problems += [
        f"{source}: pages/{index}: module {row['module']} has no entry in modules"
        for index, row in enumerate(document["pages"])
        if row["module"] not in entries
    ]
    if problems:
        raise PagesError(problems)
    for module in document["modules"]:
        rows = [r for r in document["pages"] if r["module"] == module["module"]]
        _check_part({**module, "pages": rows}, f"{source}: {module['module']}")
    return dict(document)


def union(parts: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Page list of the given parts, ordered by module and path.

    Every part is checked again, so a part that bypassed :func:`load_part` is
    rejected here as well.
    """
    checked: dict[str, Mapping[str, Any]] = {}
    for part in parts:
        source = f"part {part.get('module', '?')}"
        _check_schema(part, PART_FORMAT, source)
        _check_part(part, source)
        if part["module"] in checked:
            raise PagesError([f"{source}: module {part['module']} has more than one part"])
        checked[part["module"]] = part
    modules = [checked[m] for m in sorted(checked)]
    return {
        "format": PAGES_FORMAT,
        "modules": [
            {
                "module": p["module"],
                "signed_off_by": dict(p["signed_off_by"]),
                "leitweg": p["leitweg"],
            }
            for p in modules
        ],
        "pages": [dict(row) for p in modules for row in sorted(p["pages"], key=_row_key)],
    }


def dump_pages(document: Mapping[str, Any]) -> str:
    """YAML text of a page list, stable for the same input."""
    header = "# Generated by papaia-kit pages union from the module parts ui/pages.yaml.\n"
    return header + yaml.safe_dump(dict(document), allow_unicode=True, sort_keys=False, width=200)


def _read(data: bytes, source: str) -> Any:
    if len(data) > MAX_PART_BYTES:
        raise PagesError([f"{source}: larger than {MAX_PART_BYTES} bytes"])
    try:
        text = data.decode("utf-8")
        return yaml.load(text, Loader=_UniqueKeyLoader)  # noqa: S506 - safe loader subclass
    except UnicodeDecodeError:
        raise PagesError([f"{source}: not UTF-8"]) from None
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        line = f" line {mark.line + 1}" if mark is not None else ""
        raise PagesError([f"{source}:{line} not valid YAML"]) from None


def _check_schema(document: Any, expected: str, source: str) -> None:
    if not isinstance(document, Mapping) or document.get("format") != expected:
        raise PagesError([f"{source}: format must be {expected}"])
    definition = "Part" if expected == PART_FORMAT else "Union"
    errors = sorted(_validator(definition).iter_errors(dict(document)), key=lambda e: str(e.path))
    if errors:
        raise PagesError(f"{source}: {_place(e)}: {_rule(e)}" for e in errors)


def _check_part(part: Mapping[str, Any], source: str) -> None:
    module = part["module"]
    problems: list[str] = []
    paths: set[str] = set()
    states: set[str] = set()
    for index, row in enumerate(part["pages"]):
        if row["module"] != module:
            problems.append(f"{source}: pages/{index}: module differs from the module of the part")
        if "path" in row:
            if row["path"] in paths:
                problems.append(f"{source}: pages/{index}: path {row['path']} listed twice")
            paths.add(row["path"])
        elif row["state"] in states:
            problems.append(f"{source}: pages/{index}: state page listed twice")
        else:
            states.add(row["state"])
            if "zustand" not in row["kinds"]:
                problems.append(f"{source}: pages/{index}: a state page has kind zustand")
    problems += [f"{source}: page {p} missing" for p in REQUIRED_PATHS if p not in paths]
    if NO_ACCESS not in states:
        problems.append(f"{source}: state page {NO_ACCESS} (Kein Zugang) missing")
    names: set[str] = set()
    for index, way in enumerate(part["leitweg"]):
        if way["name"] in names:
            problems.append(f"{source}: leitweg/{index}: name used twice")
        names.add(way["name"])
        if [s["step"] for s in way["steps"]] != list(range(1, len(way["steps"]) + 1)):
            problems.append(f"{source}: leitweg/{index}: steps must be numbered 1, 2, 3, ...")
        problems += [
            f"{source}: leitweg/{index}/steps/{n}: path {s['path']} is not a page of the part"
            for n, s in enumerate(way["steps"])
            if s["path"] not in paths
        ]
    if problems:
        raise PagesError(problems)


def _row_key(row: Mapping[str, Any]) -> tuple[str, str]:
    return (row.get("path", ""), row.get("state", ""))


def _place(error: Any) -> str:
    return "/".join(str(p) for p in error.absolute_path) or "(document)"


def _rule(error: Any) -> str:
    # The validator message can quote the offending value; name the rule instead.
    if error.validator == "required":
        missing = [k for k in error.validator_value if k not in error.instance]
        return f"required field {', '.join(missing)} missing"
    if error.validator == "additionalProperties":
        known = error.schema.get("properties", {})
        extra = sorted(k for k in error.instance if k not in known)
        return f"unknown field {', '.join(extra)}"
    return f"breaks rule {error.validator}"
