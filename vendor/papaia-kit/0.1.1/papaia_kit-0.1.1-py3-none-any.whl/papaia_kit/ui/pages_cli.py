"""``papaia-kit pages``: build and check the page list (interface spec 3.9).

``union PART... --out FILE`` checks every module part ``ui/pages.yaml`` and
writes their union; nothing is written when one part is rejected. ``check
FILE`` checks a page list written by ``union``.
"""

from __future__ import annotations

import argparse
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

from papaia_kit.ui.pages import MAX_PART_BYTES, PagesError, dump_pages, load_pages, load_part, union

__all__ = ["add_parser", "run"]

EXIT_OK, EXIT_FAIL, EXIT_USAGE = 0, 1, 2
# A page list holds at most 64 parts.
_MAX_LIST_BYTES = 64 * MAX_PART_BYTES


def add_parser(groups: Any) -> None:
    """Arguments of ``pages``; ``groups`` is the top-level subparsers action."""
    pages = groups.add_parser("pages", help="page list from the module parts")
    sub = pages.add_subparsers(dest="command", required=True)
    build = sub.add_parser("union", help="check the module parts and write their union")
    build.add_argument("parts", nargs="+", type=Path, help="module part ui/pages.yaml")
    build.add_argument("--out", type=Path, required=True, help="page list to write")
    check = sub.add_parser("check", help="check a page list")
    check.add_argument("file", type=Path)


def run(args: argparse.Namespace) -> int:
    try:
        if args.command == "union":
            parts = [load_part(_read(p, MAX_PART_BYTES), source=str(p)) for p in args.parts]
            _write(args.out, dump_pages(union(parts)))
            print(f"pages: {len(parts)} parts written to {args.out}")
            return EXIT_OK
        document = load_pages(_read(args.file, _MAX_LIST_BYTES), source=str(args.file))
        print(f"pages: {len(document['modules'])} modules, {len(document['pages'])} pages")
        return EXIT_OK
    except PagesError as exc:
        for problem in exc.problems:
            print(f"  {problem}", file=sys.stderr)
        print("page list rejected", file=sys.stderr)
        return EXIT_FAIL
    except OSError as exc:
        print(f"error: {exc.strerror or type(exc).__name__}: {exc.filename}", file=sys.stderr)
        return EXIT_USAGE


def _read(path: Path, limit: int) -> bytes:
    with path.open("rb") as handle:
        data = handle.read(limit + 1)
    if len(data) > limit:
        raise PagesError([f"{path}: larger than {limit} bytes"])
    return data


def _write(path: Path, text: str) -> None:
    # Write next to the target and rename, so a reader never sees half a file.
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
