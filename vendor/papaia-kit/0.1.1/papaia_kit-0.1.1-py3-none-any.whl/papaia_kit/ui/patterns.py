"""The nine patterns and the components (``contract/patterns/``).

``patterns.yaml`` lists per pattern its states, the elements each state must
contain and the fixed texts it shows; ``examples/<id>.<lang>.html`` holds the
example markup, one ``<section data-pk-example="<state>">`` per state.
``check_example`` compares parsed markup against a state, so the examples
and any module page that renders a pattern are checked the same way.

``components`` in the same file describes the building blocks that are not
one of the nine numbered patterns (layout primitives, section head, card,
module tile) in the same form: states, mandatory elements, fixed texts.

``symbols`` in ``patterns.yaml`` names the message blocks (toast, inline
alert, error message, empty and loading state) that must show a symbol and a
text, so that no state is told apart by colour alone (oberflaeche 5).

Two more rules hold for every example and any module markup: a badge
(``.pk-badge``) has a known ``data-pk-tone`` and a text, and the summary of an
actions menu (``details.pk-menu``) has a name (KIT-050).
"""

from __future__ import annotations

import functools
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any

import yaml

from papaia_kit._resources import contract_dir
from papaia_kit.ui import messages

PATTERN_COUNT = 9
MAX_EXAMPLE_BYTES = 256 * 1024
_ID = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
_TAG = re.compile(r"^[a-z][a-z0-9]{0,15}$")
_ATTR = re.compile(r"^[a-z][a-z0-9-]{0,63}$")
_TEXT_KEY = re.compile(r"^(?:(?:states|welcome)\.)?[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)?$")
# Message files a text key may name with its first part; any other key is in patterns.
_PREFIXED = ("states", "welcome")
BADGE_TONES = ("neutral", "info", "success", "warning", "error")
_SYMBOL = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_CLASS = re.compile(r"^pk-[a-z]+(?:-[a-z]+)*$")
_HREF_SYMBOL = re.compile(r"#pk-icon-([a-z0-9]+(?:-[a-z0-9]+)*)$")
_VOID = frozenset(
    {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "wbr"}
)


class PatternError(ValueError):
    """The pattern file or an example is malformed."""


@dataclass(frozen=True)
class Requirement:
    tag: str
    attrs: Mapping[str, str | None]

    def describe(self) -> str:
        parts = [k if v is None else f'{k}="{v}"' for k, v in sorted(self.attrs.items())]
        return f"<{' '.join([self.tag, *parts])}>"

    def matches(self, tag: str, attrs: Mapping[str, str | None]) -> bool:
        if tag != self.tag:
            return False
        for name, wanted in self.attrs.items():
            if name not in attrs:
                return False
            if wanted is None:
                continue
            have = attrs[name] or ""
            if name == "class":
                if not set(wanted.split()) <= set(have.split()):
                    return False
            elif have != wanted:
                return False
        return True


@dataclass(frozen=True)
class State:
    id: str
    require: tuple[Requirement, ...]
    texts: tuple[str, ...]
    shows: Mapping[str, str] | None


@dataclass(frozen=True)
class Pattern:
    number: int
    id: str
    states: Mapping[str, State]


@dataclass(frozen=True)
class Component:
    id: str
    states: Mapping[str, State]


@dataclass(frozen=True)
class SymbolRules:
    """Message blocks that show a symbol: by tone (``toned``) or one fixed symbol each."""

    tones: Mapping[str, str]
    toned: tuple[str, ...]
    fixed: Mapping[str, str | None]

    @property
    def classes(self) -> frozenset[str]:
        return frozenset((*self.toned, *self.fixed))


@dataclass
class Block:
    """One message block of an example: its symbols (hidden and visible) and its text."""

    kind: str
    tone: str | None
    symbols: list[str] = field(default_factory=list)
    visible_symbols: list[str] = field(default_factory=list)
    text: str = ""


@dataclass
class Named:
    """A badge or the summary of an actions menu: it needs a name (label or text)."""

    kind: str  # "pk-badge" or "pk-menu"
    tone: str | None = None
    label: bool = False
    text: str = ""


@dataclass
class Example:
    """Parsed markup of one state."""

    elements: list[tuple[str, dict[str, str | None]]] = field(default_factory=list)
    texts: list[str] = field(default_factory=list)
    raw_text: str = ""
    blocks: list[Block] = field(default_factory=list)
    unnamed: list[str] = field(default_factory=list)
    named: list[Named] = field(default_factory=list)

    @property
    def attributes(self) -> set[tuple[str, str, str | None]]:
        return {(tag, k, v) for tag, attrs in self.elements for k, v in attrs.items()}

    @property
    def visible_text(self) -> str:
        return re.sub(r"\s+", " ", self.raw_text).strip()


def _fail(text: str) -> PatternError:
    return PatternError(f"patterns: {text}")


def _keys(where: str, data: object, required: set[str], optional: frozenset[str]) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise _fail(f"{where}: expected a mapping")
    if missing := required - set(data):
        raise _fail(f"{where}: missing {sorted(missing)}")
    if unknown := set(data) - required - optional:
        raise _fail(f"{where}: unknown {sorted(unknown)}")
    return data


def _requirement(where: str, raw: object) -> Requirement:
    entry = _keys(where, raw, {"tag"}, frozenset({"attrs"}))
    tag = entry["tag"]
    attrs = entry.get("attrs", {})
    if not isinstance(tag, str) or not _TAG.match(tag) or not isinstance(attrs, dict):
        raise _fail(f"{where}: bad tag or attrs")
    for name, value in attrs.items():
        if not isinstance(name, str) or not _ATTR.match(name):
            raise _fail(f"{where}: bad attribute name")
        if value is not None and not isinstance(value, str):
            raise _fail(f"{where}: attribute {name} must be a string or null")
    return Requirement(tag, dict(attrs))


def _state(where: str, state_id: object, raw: object) -> State:
    if not isinstance(state_id, str) or not _ID.match(state_id):
        raise _fail(f"{where}: bad state id")
    entry = _keys(where, raw, {"require", "texts"}, frozenset({"shows"}))
    require = entry["require"]
    texts = entry["texts"]
    if not isinstance(require, list) or not require:
        raise _fail(f"{where}: require must be a non-empty list")
    if not isinstance(texts, list) or not all(
        isinstance(t, str) and _TEXT_KEY.match(t) for t in texts
    ):
        raise _fail(f"{where}: texts must be a list of message keys")
    for key in texts:
        _template(key, "de")  # the key must exist
    shows = entry.get("shows")
    if shows is not None and (
        not isinstance(shows, dict)
        or set(shows) != set(messages.LANGUAGES)
        or not all(isinstance(v, str) for v in shows.values())
    ):
        raise _fail(f"{where}: shows must hold one text per language")
    return State(
        state_id,
        tuple(_requirement(f"{where}.require[{i}]", r) for i, r in enumerate(require)),
        tuple(texts),
        shows,
    )


def _document(data: object) -> dict[str, Any]:
    return _keys(
        "patterns.yaml",
        data,
        {"version", "timing", "patterns"},
        frozenset({"components", "symbols"}),
    )


def parse_patterns(data: object) -> tuple[Pattern, ...]:
    """The patterns of a ``patterns.yaml`` document, numbered 1 to 9 in order."""
    doc = _document(data)
    if doc["version"] != 1:
        raise _fail("patterns.yaml: expected version 1")
    raw = doc["patterns"]
    if not isinstance(raw, list) or len(raw) != PATTERN_COUNT:
        raise _fail(f"patterns.yaml: expected {PATTERN_COUNT} patterns")
    out = []
    for index, item in enumerate(raw, 1):
        entry = _keys(f"pattern {index}", item, {"number", "id", "states"}, frozenset())
        if (
            entry["number"] != index
            or not isinstance(entry["id"], str)
            or not _ID.match(entry["id"])
        ):
            raise _fail(f"pattern {index}: number must be {index} and id a short name")
        states = entry["states"]
        if not isinstance(states, dict) or not states:
            raise _fail(f"pattern {index}: states must be a non-empty mapping")
        out.append(
            Pattern(
                index,
                entry["id"],
                {str(k): _state(f"{entry['id']}.{k}", k, v) for k, v in states.items()},
            )
        )
    if len({p.id for p in out}) != len(out):
        raise _fail("patterns.yaml: pattern ids must be unique")
    return tuple(out)


def parse_components(data: object) -> tuple[Component, ...]:
    """The components of a ``patterns.yaml`` document, in file order.

    Every component has a unique short id that is not the id of a pattern, and
    at least one state of the same form as a pattern state.
    """
    doc = _document(data)
    pattern_ids = {p.id for p in parse_patterns(doc)}
    raw = doc.get("components", [])
    if not isinstance(raw, list):
        raise _fail("patterns.yaml: components must be a list")
    out: list[Component] = []
    for index, item in enumerate(raw, 1):
        entry = _keys(f"component {index}", item, {"id", "states"}, frozenset())
        component_id = entry["id"]
        if not isinstance(component_id, str) or not _ID.match(component_id):
            raise _fail(f"component {index}: id must be a short name")
        if component_id in pattern_ids:
            raise _fail(f"component {component_id}: id is the id of a pattern")
        states = entry["states"]
        if not isinstance(states, dict) or not states:
            raise _fail(f"component {component_id}: states must be a non-empty mapping")
        out.append(
            Component(
                component_id,
                {str(k): _state(f"{component_id}.{k}", k, v) for k, v in states.items()},
            )
        )
    if len({c.id for c in out}) != len(out):
        raise _fail("patterns.yaml: component ids must be unique")
    return tuple(out)


def _is_class(value: object) -> bool:
    return isinstance(value, str) and _CLASS.match(value) is not None


def parse_symbols(data: object) -> SymbolRules:
    """The ``symbols`` section of a ``patterns.yaml`` document."""
    doc = _keys(
        "patterns.yaml",
        data,
        {"version", "timing", "patterns", "symbols"},
        frozenset({"components"}),
    )
    raw = _keys("symbols", doc["symbols"], {"tones", "toned", "fixed"}, frozenset())
    tones, toned, fixed = raw["tones"], raw["toned"], raw["fixed"]
    if (
        not isinstance(tones, dict)
        or not tones
        or not all(
            isinstance(k, str) and _ID.match(k) and isinstance(v, str) and _SYMBOL.match(v)
            for k, v in tones.items()
        )
    ):
        raise _fail("symbols.tones: expected tone: symbol pairs")
    if not isinstance(toned, list) or not all(_is_class(c) for c in toned):
        raise _fail("symbols.toned: expected a list of pk-* classes")
    if not isinstance(fixed, dict) or not all(
        _is_class(k) and (v is None or (isinstance(v, str) and _SYMBOL.match(v)))
        for k, v in fixed.items()
    ):
        raise _fail("symbols.fixed: expected pk-* class: symbol (or null for any symbol)")
    if set(toned) & set(fixed) or len(set(toned)) != len(toned):
        raise _fail("symbols: a class is listed twice")
    return SymbolRules(dict(tones), tuple(toned), dict(fixed))


@functools.cache
def _patterns_file() -> object:
    path = contract_dir() / "patterns" / "patterns.yaml"
    return yaml.safe_load(path.read_text(encoding="utf-8"))


@functools.cache
def load_patterns() -> tuple[Pattern, ...]:
    """The kit's nine patterns from ``contract/patterns/patterns.yaml``."""
    return parse_patterns(_patterns_file())


@functools.cache
def load_components() -> tuple[Component, ...]:
    """The kit's components from ``contract/patterns/patterns.yaml``."""
    return parse_components(_patterns_file())


@functools.cache
def load_symbols() -> SymbolRules:
    """The symbol rules of the message blocks from ``contract/patterns/patterns.yaml``."""
    return parse_symbols(_patterns_file())


class _ExampleParser(HTMLParser):
    def __init__(self, classes: frozenset[str]) -> None:
        super().__init__(convert_charrefs=True)
        self.classes = classes
        self.examples: dict[str, Example] = {}
        self.current: Example | None = None
        self.depth = 0  # open <section> elements inside the current example
        self.stack: list[tuple[str, dict[str, str | None]]] = []
        self.open: list[tuple[Block, int]] = []
        self.naming: list[tuple[Named, int]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag == "section" and "data-pk-example" in values:
            state = values["data-pk-example"] or ""
            if self.current is not None or not _ID.match(state) or state in self.examples:
                raise _fail(f"example section {state!r}: nested, malformed or repeated")
            self.current = self.examples[state] = Example()
            self.depth = 0
            self.stack, self.open, self.naming = [], [], []
            return
        if self.current is None:
            return
        self.current.elements.append((tag, values))
        if tag == "section":
            self.depth += 1
        if tag == "use" and self.open:
            self._symbol(values)
        if "data-pk-icon-only" in values and not any(
            (values.get(k) or "").strip() for k in ("aria-label", "aria-labelledby")
        ):
            self.current.unnamed.append(tag)
        if tag in _VOID:
            return
        named = self._named(tag, values)
        self.stack.append((tag, values))
        if named is not None:
            self.current.named.append(named)
            self.naming.append((named, len(self.stack)))
        kinds = set((values.get("class") or "").split()) & self.classes
        if kinds:
            block = Block(sorted(kinds)[0], values.get("data-pk-tone"))
            self.current.blocks.append(block)
            self.open.append((block, len(self.stack)))

    def _named(self, tag: str, values: Mapping[str, str | None]) -> Named | None:
        """A badge, or the summary of an actions menu, starting at this element."""
        if "pk-badge" in (values.get("class") or "").split():
            return Named("pk-badge", tone=values.get("data-pk-tone"))
        parent = self.stack[-1] if self.stack else None
        if (
            tag == "summary"
            and parent is not None
            and parent[0] == "details"
            and "pk-menu" in (parent[1].get("class") or "").split()
        ):
            label = any((values.get(k) or "").strip() for k in ("aria-label", "aria-labelledby"))
            return Named("pk-menu", label=label)
        return None

    def _symbol(self, values: Mapping[str, str | None]) -> None:
        href = values.get("href") or values.get("xlink:href") or ""
        match = _HREF_SYMBOL.search(href)
        svg = next((a for t, a in reversed(self.stack) if t == "svg"), None)
        if match is None or svg is None:
            return
        block = self.open[-1][0]
        hidden = svg.get("aria-hidden") == "true"
        (block.symbols if hidden else block.visible_symbols).append(match.group(1))

    def handle_endtag(self, tag: str) -> None:
        if tag == "section":
            if not self.depth:
                self.current = None
                return
            self.depth -= 1
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break
        while self.open and self.open[-1][1] > len(self.stack):
            self.open.pop()
        while self.naming and self.naming[-1][1] > len(self.stack):
            self.naming.pop()

    def handle_data(self, data: str) -> None:
        if self.current is not None:
            self.current.raw_text += data
            if data.strip():
                self.current.texts.append(re.sub(r"\s+", " ", data).strip())
            for block, _ in self.open:
                block.text += data
            for named, _ in self.naming:
                named.text += data


def parse_example(markup: str) -> dict[str, Example]:
    """The states of one example file, by ``data-pk-example``."""
    if len(markup.encode("utf-8")) > MAX_EXAMPLE_BYTES:
        raise _fail("example larger than the limit")
    parser = _ExampleParser(load_symbols().classes)
    parser.feed(markup)
    parser.close()
    return parser.examples


def load_examples(pattern_id: str, lang: str) -> dict[str, Example]:
    """Example markup of a pattern or component in ``lang`` from ``contract/patterns/examples/``."""
    known = {p.id for p in load_patterns()} | {c.id for c in load_components()}
    if lang not in messages.LANGUAGES or pattern_id not in known:
        raise _fail("unknown pattern or language")
    path = contract_dir() / "patterns" / "examples" / f"{pattern_id}.{lang}.html"
    return parse_example(path.read_text(encoding="utf-8"))


def _template(key: str, lang: str) -> str:
    prefixed = key.partition(".")[0] in _PREFIXED and "." in key
    name, _, rest = key.partition(".") if prefixed else ("patterns", "", key)
    texts = messages.load_texts(name, lang)
    if rest not in texts:
        raise _fail(f"unknown text key {key}")
    return texts[rest]


def text_regex(template: str) -> re.Pattern[str]:
    """``template`` as a pattern in which every placeholder stands for any value."""
    pieces = re.split(r"\{[a-z_]+\}", template)
    return re.compile(".+?".join(re.escape(piece) for piece in pieces))


def check_example(example: Example, state: State, lang: str) -> list[str]:
    """Problems of ``example`` against ``state``: missing elements and missing texts."""
    problems = [
        f"missing element {req.describe()}"
        for req in state.require
        if not any(req.matches(tag, attrs) for tag, attrs in example.elements)
    ]
    shown = example.visible_text
    for key in state.texts:
        if not text_regex(_template(key, lang)).search(shown):
            problems.append(f"missing text {key}")
    if state.shows is not None and shown != state.shows[lang]:
        problems.append(f"shows {shown!r}, expected {state.shows[lang]!r}")
    return problems + symbol_problems(example) + name_problems(example)


def name_problems(example: Example) -> list[str]:
    """Badges without a known tone or without text, and actions menus without a name."""
    problems: list[str] = []
    for named in example.named:
        if named.kind == "pk-badge":
            if named.tone not in BADGE_TONES:
                problems.append(f"pk-badge without data-pk-tone ({', '.join(BADGE_TONES)})")
            if not named.text.strip():
                problems.append("pk-badge: no text (a badge always shows words)")
        elif not named.label and not named.text.strip():
            problems.append("pk-menu: summary without a name (aria-label or text)")
    return problems


def symbol_problems(example: Example) -> list[str]:
    """Message blocks without a hidden symbol, with the wrong one or without text.

    A toned block (toast, inline alert) needs ``data-pk-tone`` and the symbol of its
    tone first; a fixed block its own symbol (any symbol where the rule says null).
    Symbol-only buttons need an accessible name.
    """
    rules = load_symbols()
    problems = [f"{tag}[data-pk-icon-only] without aria-label" for tag in example.unnamed]
    for block in example.blocks:
        expected: str | None = None
        if block.kind in rules.toned:
            if block.tone is None or block.tone not in rules.tones:
                problems.append(f"{block.kind} without data-pk-tone ({', '.join(rules.tones)})")
                continue
            expected = rules.tones[block.tone]
        else:
            expected = rules.fixed[block.kind]
        if not block.symbols and block.visible_symbols:
            problems.append(f'{block.kind}: symbol without aria-hidden="true"')
        elif not block.symbols:
            problems.append(f"{block.kind}: no symbol")
        elif expected is not None and block.symbols[0] != expected:
            problems.append(f"{block.kind}: symbol {block.symbols[0]}, expected {expected}")
        if not block.text.strip():
            problems.append(f"{block.kind}: no text next to the symbol")
    return problems
