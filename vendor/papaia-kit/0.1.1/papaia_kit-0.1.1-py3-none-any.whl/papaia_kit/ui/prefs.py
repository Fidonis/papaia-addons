"""Language, appearance and time zone from the core service ``prefs`` (interface spec 3.3).

The one source is ``prefs`` (architecture D-02, RE-08). The claims ``locale``
and ``zoneinfo`` of any token are not a source: nothing here takes claims, and
a module renders from the values this module keeps in its session.

- **Login.** :func:`load_on_login` reads ``GET /api/v1/preferences/me`` with
  the person's token (audience ``papaia-prefs``) and stores the values in the
  session under :data:`SESSION_KEY`.
- **Every HTML document.** :func:`current_preferences` compares the etag of the
  session cookie ``pk_ui`` with the session and reloads from ``prefs`` before
  the page renders when they differ. The cookie only signals a change; its
  values never replace those of ``prefs``.
- **Rendering.** :func:`rendering` gives ``lang`` (``browser`` resolved from
  ``Accept-Language``, default German), ``data-theme`` (none for ``system``)
  and the time zone, so the first byte of the document is already right.
- **Writing.** :func:`write_preferences` sends ``PUT /api/v1/preferences/me``
  with ``If-Match``, stores the answer, returns the new ``Set-Cookie`` value of
  ``pk_ui`` and hands one ``papaia.audit/1`` row (field names, no values) to
  the module's audit sink. The forms ``/_kit/appearance`` and
  ``/_kit/language`` take their value through :func:`appearance_change` and
  :func:`language_change`; the welcome hint through :func:`welcome_change`.

Nothing here keeps a value in browser storage or a lasting cookie.
"""

from __future__ import annotations

import json
import re
import zoneinfo
from collections.abc import Callable, Mapping, MutableMapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from functools import cache
from typing import Any, Final, Literal, Protocol
from urllib.parse import urlsplit

from papaia_kit.audit import AUDIT_FORMAT, validate_event
from papaia_kit.correlation import CORRELATION_HEADER, accept_correlation_id
from papaia_kit.errors import CLASSES, ErrorClass
from papaia_kit.exchange._jwt import MAX_TOKEN_LENGTH
from papaia_kit.exchange.transport import UrllibTransport

__all__ = [
    "AUDIENCE",
    "COOKIE_NAME",
    "ME_PATH",
    "SESSION_KEY",
    "Preferences",
    "PreferencesClient",
    "PreferencesError",
    "Rendering",
    "UiCookie",
    "WriteResult",
    "appearance_change",
    "current_preferences",
    "language_change",
    "language_from_accept",
    "load_on_login",
    "parse_preferences",
    "parse_ui_cookie",
    "rendering",
    "return_target",
    "ui_cookie_value",
    "ui_set_cookie",
    "welcome_change",
    "write_preferences",
]

AUDIENCE: Final = "papaia-prefs"
ME_PATH: Final = "/api/v1/preferences/me"
COOKIE_NAME: Final = "pk_ui"
SESSION_KEY: Final = "pk_prefs"
LOCALES: Final = ("de", "en", "browser")
APPEARANCES: Final = ("light", "dark", "system")
FORM_APPEARANCES: Final = ("light", "dark")
LANGUAGES: Final = ("de", "en")
DEFAULT_LANGUAGE: Final = "de"
WRITABLE: Final = frozenset({"locale", "appearance", "time_zone", "welcome_seen"})
MAX_TIMEOUT: Final = 30.0

_REQUIRED = frozenset({"locale", "appearance", "time_zone", "welcome_seen", "etag"})
# Fields of a prefs answer that this module does not use; they are accepted so
# the answer of D-02 parses, and dropped.
_OTHER = frozenset(
    {"sub", "preferred_channel", "fallback_channel", "fallback_after", "quiet_hours", "updated_at"}
)
_MAX_TIME_ZONE = 64
_MAX_WELCOME_KEYS = 32
_MAX_HEADER = 8192
_MAX_ACCEPT = 4096
_MAX_REFERER = 2048
_ETAG = re.compile(r"[A-Za-z0-9._~+/=-]{1,128}")
_SURFACE = re.compile(r"[a-z][a-z0-9-]{0,31}")
_SURFACE_CLIENT = re.compile(r"papaia-([a-z][a-z0-9-]{0,31})")
_SEEN = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z")
_SEEN_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
_COOKIE = re.compile(r"(light|dark|system)\.(de|en|browser)\.([A-Za-z0-9._~+/=-]{1,128})")
_TOKEN = re.compile(r"[\x21-\x7e]+")
_LABEL = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
_DOMAIN = re.compile(rf"(?=.{{1,253}}$){_LABEL}(?:\.{_LABEL})*")
_QUALITY = re.compile(r"q=(0(?:\.[0-9]{0,3})?|1(?:\.0{0,3})?)", re.IGNORECASE)
_LANGUAGE_RANGE = re.compile(r"[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*|\*")
_UNSAFE_URL = re.compile(r"[\x00-\x20\x7f\\]")
_OK = 200

_CODES: Final = {
    ErrorClass.UNAUTHENTICATED: "PK-AUTH-001",
    ErrorClass.FORBIDDEN_OR_NOT_FOUND: "PK-ACCESS-001",
    ErrorClass.INVALID_INPUT: "PK-INPUT-001",
    ErrorClass.CONFLICT: "PK-CONFLICT-001",
    ErrorClass.RATE_LIMITED: "PK-RATE-001",
    ErrorClass.UPSTREAM_UNAVAILABLE: "PK-UPSTREAM-001",
    ErrorClass.CONTRACT_MISMATCH: "PK-CONTRACT-001",
}
_STATUS_CLASSES: Final = {
    400: ErrorClass.INVALID_INPUT,
    401: ErrorClass.UNAUTHENTICATED,
    403: ErrorClass.FORBIDDEN_OR_NOT_FOUND,
    404: ErrorClass.FORBIDDEN_OR_NOT_FOUND,
    412: ErrorClass.CONFLICT,
    428: ErrorClass.INVALID_INPUT,
    429: ErrorClass.RATE_LIMITED,
}
# A refusal of the person's own request; everything else is a failure.
_DENIED = frozenset(
    {
        ErrorClass.UNAUTHENTICATED,
        ErrorClass.FORBIDDEN_OR_NOT_FOUND,
        ErrorClass.INVALID_INPUT,
        ErrorClass.CONFLICT,
        ErrorClass.RATE_LIMITED,
    }
)

AuditSink = Callable[[dict[str, object]], object]
TokenSource = Callable[[], str]


class PreferencesError(Exception):
    """A read or write of preferences that did not succeed.

    ``error_class`` is a class of the error envelope (architecture V-06),
    ``code`` the matching kit code, ``reason`` one machine-readable word.
    Neither the message nor an attribute carries a token or a value.
    """

    def __init__(self, error_class: ErrorClass, reason: str, *, correlation_id: str = "") -> None:
        self.error_class = error_class
        self.code = _CODES.get(error_class, "PK-INTERNAL-001")
        self.reason = reason
        self.status = CLASSES[error_class].default_status
        self.retryable = CLASSES[error_class].retryable
        self.correlation_id = correlation_id
        super().__init__(f"preferences: {error_class} ({reason})")


@dataclass(frozen=True)
class Preferences:
    """The values of ``prefs`` this module renders with, plus the record's etag."""

    locale: str
    appearance: str
    time_zone: str
    welcome_seen: Mapping[str, str] = field(default_factory=dict)
    etag: str = ""

    def to_session(self) -> dict[str, Any]:
        return {
            "locale": self.locale,
            "appearance": self.appearance,
            "time_zone": self.time_zone,
            "welcome_seen": dict(self.welcome_seen),
            "etag": self.etag,
        }


@dataclass(frozen=True)
class UiCookie:
    """The parsed ``pk_ui`` cookie: ``<appearance>.<locale>.<etag>``."""

    appearance: str
    locale: str
    etag: str


@dataclass(frozen=True)
class Rendering:
    """What the server puts into the first HTML: ``lang``, ``data-theme``, the time zone."""

    lang: str
    language_setting: str
    theme: str
    time_zone: str

    @property
    def data_theme(self) -> str | None:
        return None if self.theme == "system" else self.theme

    def shell_fields(self) -> dict[str, str]:
        """``locale``, ``language_setting`` and ``theme`` of a ``papaia.shell-input/1``."""
        return {"locale": self.lang, "language_setting": self.language_setting, "theme": self.theme}


@dataclass(frozen=True)
class WriteResult:
    """A stored change: the new values and the ``Set-Cookie`` value for ``pk_ui``."""

    preferences: Preferences
    set_cookie: str


# --- values -----------------------------------------------------------------------------


@cache
def _time_zones() -> frozenset[str]:
    return frozenset(zoneinfo.available_timezones())


def _valid_time_zone(value: object) -> bool:
    return isinstance(value, str) and 0 < len(value) <= _MAX_TIME_ZONE and value in _time_zones()


def _valid_seen(value: object) -> bool:
    if not isinstance(value, str) or not _SEEN.fullmatch(value):
        return False
    try:
        datetime.strptime(value, _SEEN_FORMAT)  # noqa: DTZ007 - only checks the calendar
    except ValueError:
        return False
    return True


def _welcome(value: object, *, allow_empty: bool) -> dict[str, str] | None:
    if not isinstance(value, Mapping) or len(value) > _MAX_WELCOME_KEYS:
        return None
    if not value and not allow_empty:
        return None
    checked: dict[str, str] = {}
    for key, seen in value.items():
        if not (isinstance(key, str) and _SURFACE.fullmatch(key) and _valid_seen(seen)):
            return None
        checked[key] = seen
    return checked


def _checked(data: object, *, extra: frozenset[str]) -> Preferences | None:
    if not isinstance(data, Mapping):
        return None
    names = set(data)
    if not names >= _REQUIRED or names - _REQUIRED - extra:
        return None
    welcome = _welcome(data["welcome_seen"], allow_empty=True)
    etag = data["etag"]
    if (
        data["locale"] not in LOCALES
        or data["appearance"] not in APPEARANCES
        or not _valid_time_zone(data["time_zone"])
        or welcome is None
        or not (isinstance(etag, str) and _ETAG.fullmatch(etag))
    ):
        return None
    return Preferences(data["locale"], data["appearance"], data["time_zone"], welcome, etag)


def parse_preferences(data: object, *, correlation_id: str = "") -> Preferences:
    """Check an answer of ``prefs`` (decoded JSON); unknown or invalid fields are refused."""
    prefs = _checked(data, extra=_OTHER)
    if prefs is None:
        raise PreferencesError(
            ErrorClass.CONTRACT_MISMATCH, "answer", correlation_id=correlation_id
        )
    return prefs


def _from_session(session: Mapping[str, Any]) -> Preferences | None:
    return _checked(session.get(SESSION_KEY), extra=frozenset())


def _store(session: MutableMapping[str, Any], prefs: Preferences) -> Preferences:
    session[SESSION_KEY] = prefs.to_session()
    return prefs


# --- language and appearance in the first byte ------------------------------------------


def language_from_accept(header: str | None) -> str:
    """``de`` or ``en`` from an ``Accept-Language`` header (RFC 9110 12.5.4), default ``de``.

    The highest weight wins, the earlier entry on equal weight; ``*``,
    unsupported languages, weight 0 and malformed entries count for nothing.
    """
    if not header or len(header) > _MAX_ACCEPT:
        return DEFAULT_LANGUAGE
    best, best_q = DEFAULT_LANGUAGE, 0.0
    for item in header.split(","):
        parts = [p.strip() for p in item.split(";")]
        if not _LANGUAGE_RANGE.fullmatch(parts[0]):
            continue
        quality = 1.0
        if len(parts) > 1:
            match = _QUALITY.fullmatch(parts[1]) if len(parts) == 2 else None  # noqa: PLR2004
            if match is None:
                continue
            quality = float(match.group(1))
        primary = parts[0].split("-")[0].lower()
        if primary in LANGUAGES and quality > best_q:
            best, best_q = primary, quality
    return best


def rendering(prefs: Preferences, *, accept_language: str | None) -> Rendering:
    """``lang``, appearance and time zone of the page from the session values."""
    lang = language_from_accept(accept_language) if prefs.locale == "browser" else prefs.locale
    return Rendering(lang, prefs.locale, prefs.appearance, prefs.time_zone)


# --- the pk_ui cookie -------------------------------------------------------------------


def parse_ui_cookie(cookie_header: str | None) -> UiCookie | None:
    """``pk_ui`` from a ``Cookie`` request header; ``None`` when absent or unreadable."""
    if not cookie_header or len(cookie_header) > _MAX_HEADER:
        return None
    for part in cookie_header.split(";"):
        name, sep, value = part.strip().partition("=")
        if sep and name == COOKIE_NAME:
            match = _COOKIE.fullmatch(value)
            return UiCookie(*match.groups()) if match else None
    return None


def ui_cookie_value(prefs: Preferences) -> str:
    return f"{prefs.appearance}.{prefs.locale}.{prefs.etag}"


def ui_set_cookie(prefs: Preferences, *, domain: object) -> str:
    """``Set-Cookie`` value of ``pk_ui``: a session cookie for every host below ``domain``.

    No ``Max-Age``/``Expires`` (it ends with the browser session) and no
    ``HttpOnly``, because ``theme-sync.js`` reads the etag; the value names
    no person. ``domain=None`` gives a host-only cookie (a module without
    platform).
    """
    attributes = [f"{COOKIE_NAME}={ui_cookie_value(prefs)}"]
    if domain is not None:
        if not isinstance(domain, str) or not _DOMAIN.fullmatch(domain):
            raise ValueError("domain must be a lower-case host name such as example.test")
        attributes.append(f"Domain={domain}")
    attributes += ["Path=/", "Secure", "SameSite=Lax"]
    return "; ".join(attributes)


# --- HTTP -------------------------------------------------------------------------------


class JsonTransport(Protocol):
    """Sends one request and returns status code and body."""

    def send(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        body: bytes | None,
        timeout: float,
    ) -> tuple[int, bytes]: ...


class UrllibJsonTransport(UrllibTransport):
    """Standard library transport (no redirect, no proxy variables, bounded body)."""

    def send(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        body: bytes | None,
        timeout: float,
    ) -> tuple[int, bytes]:
        import http.client  # noqa: PLC0415 - only the default transport needs it
        import urllib.request  # noqa: PLC0415

        if urlsplit(url).scheme not in ("http", "https"):
            raise OSError("preference route must use http or https")
        request = urllib.request.Request(  # noqa: S310 - scheme checked above
            url, data=body, headers=dict(headers), method=method
        )
        try:
            return self._send(request, timeout)
        except http.client.HTTPException as error:
            raise OSError(f"malformed response: {type(error).__name__}") from None


def _reject_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate member")
        result[key] = value
    return result


def _reject_constant(name: str) -> Any:
    raise ValueError(f"constant {name} is not JSON")


def _check_token(token: object) -> str:
    if not isinstance(token, str) or not 0 < len(token) <= MAX_TOKEN_LENGTH:
        raise ValueError("token must be a non-empty string of bounded length")
    if not _TOKEN.fullmatch(token):
        raise ValueError("token must not contain white space or control characters")
    return token


class PreferencesClient:
    """``GET`` and ``PUT /api/v1/preferences/me`` with the person's token."""

    def __init__(
        self, base_url: object, *, transport: JsonTransport | None = None, timeout: float = 5.0
    ) -> None:
        parts = urlsplit(base_url) if isinstance(base_url, str) else None
        if (
            parts is None
            or parts.scheme not in ("http", "https")
            or not parts.hostname
            or "@" in parts.netloc
            or parts.query
            or parts.fragment
            or not isinstance(base_url, str)
            or _UNSAFE_URL.search(base_url)
        ):
            raise ValueError("base_url must be http(s)://host[:port][/path] without credentials")
        if not 0 < timeout <= MAX_TIMEOUT:
            raise ValueError(f"timeout must lie in (0, {MAX_TIMEOUT}] seconds")
        self.url = base_url.rstrip("/") + ME_PATH
        self._transport: JsonTransport = transport or UrllibJsonTransport()
        self._timeout = timeout

    def get(self, token: str, *, correlation_id: str) -> Preferences:
        return self._call("GET", token, None, None, correlation_id)

    def put(
        self, token: str, change: Mapping[str, Any], *, etag: str, correlation_id: str
    ) -> Preferences:
        if not _ETAG.fullmatch(etag):
            raise ValueError("etag does not fit the prefs etag form")
        body = json.dumps(dict(change), separators=(",", ":")).encode("utf-8")
        return self._call("PUT", token, body, etag, correlation_id)

    def _call(
        self, method: str, token: str, body: bytes | None, etag: str | None, correlation_id: str
    ) -> Preferences:
        cid = accept_correlation_id(correlation_id)
        headers = {
            "Authorization": f"Bearer {_check_token(token)}",
            "Accept": "application/json",
            CORRELATION_HEADER: cid,
        }
        if body is not None:
            headers["Content-Type"] = "application/json"
        if etag is not None:
            headers["If-Match"] = f'"{etag}"'
        try:
            status, raw = self._transport.send(method, self.url, headers, body, self._timeout)
        except OSError:
            raise PreferencesError(
                ErrorClass.UPSTREAM_UNAVAILABLE, "transport", correlation_id=cid
            ) from None
        if status != _OK:
            error_class = _STATUS_CLASSES.get(status, ErrorClass.UPSTREAM_UNAVAILABLE)
            raise PreferencesError(error_class, f"status_{status}", correlation_id=cid)
        try:
            data = json.loads(
                raw.decode("utf-8"),
                object_pairs_hook=_reject_duplicates,
                parse_constant=_reject_constant,
            )
        except (UnicodeDecodeError, ValueError, RecursionError):
            raise PreferencesError(
                ErrorClass.CONTRACT_MISMATCH, "body", correlation_id=cid
            ) from None
        return parse_preferences(data, correlation_id=cid)


# --- session ----------------------------------------------------------------------------


def load_on_login(
    session: MutableMapping[str, Any],
    client: PreferencesClient,
    token: TokenSource,
    *,
    correlation_id: str,
) -> Preferences:
    """Read the person's values at login and keep them in the session."""
    return _store(session, client.get(token(), correlation_id=correlation_id))


def current_preferences(
    session: MutableMapping[str, Any],
    cookie_header: str | None,
    *,
    client: PreferencesClient,
    token: TokenSource,
    correlation_id: str,
) -> Preferences:
    """The values to render with; reloaded from ``prefs`` first when ``pk_ui`` names a new etag.

    ``token`` is called only when a reload is needed. A missing or unreadable
    session entry is reloaded as well; an unreadable cookie is ignored.
    """
    stored = _from_session(session)
    cookie = parse_ui_cookie(cookie_header)
    if stored is not None and (cookie is None or cookie.etag == stored.etag):
        return stored
    return _store(session, client.get(token(), correlation_id=correlation_id))


# --- writing ----------------------------------------------------------------------------


def appearance_change(value: object) -> dict[str, str]:
    """The change of the footer form ``/_kit/appearance`` (``light`` or ``dark``)."""
    if not isinstance(value, str) or value not in FORM_APPEARANCES:
        raise PreferencesError(ErrorClass.INVALID_INPUT, "appearance")
    return {"appearance": value}


def language_change(value: object) -> dict[str, str]:
    """The change of the language menu ``/_kit/language`` (``browser``, ``de`` or ``en``)."""
    if not isinstance(value, str) or value not in LOCALES:
        raise PreferencesError(ErrorClass.INVALID_INPUT, "locale")
    return {"locale": value}


def welcome_change(ui_id: object, moment: object) -> dict[str, dict[str, str]]:
    """The change that marks the welcome hint of the own surface ``ui_id`` as seen (RE-44)."""
    if not isinstance(moment, datetime) or moment.tzinfo is None:
        raise ValueError("moment must be an aware datetime")
    if not isinstance(ui_id, str) or not _SURFACE.fullmatch(ui_id):
        raise PreferencesError(ErrorClass.INVALID_INPUT, "welcome_seen")
    return {"welcome_seen": {ui_id: moment.astimezone(UTC).strftime(_SEEN_FORMAT)}}


def _check_change(change: object, azp: str) -> dict[str, Any]:
    if not isinstance(change, Mapping) or not change or set(change) - WRITABLE:
        raise PreferencesError(ErrorClass.INVALID_INPUT, "fields")
    rules: dict[str, Callable[[Any], bool]] = {
        "locale": lambda v: isinstance(v, str) and v in LOCALES,
        "appearance": lambda v: isinstance(v, str) and v in APPEARANCES,
        "time_zone": _valid_time_zone,
        "welcome_seen": lambda v: _welcome(v, allow_empty=False) is not None,
    }
    for name, value in change.items():
        if not rules[name](value):
            raise PreferencesError(ErrorClass.INVALID_INPUT, name)
    if "welcome_seen" in change:
        own = _SURFACE_CLIENT.fullmatch(azp)
        if own is None or set(change["welcome_seen"]) != {own.group(1)}:
            raise PreferencesError(ErrorClass.INVALID_INPUT, "welcome_seen")
    return {
        name: dict(value) if isinstance(value, Mapping) else value for name, value in change.items()
    }


def _audit_row(
    *,
    result: Literal["allowed", "denied", "error"],
    sub: str,
    azp: str,
    writer: str,
    correlation_id: str,
    fields: list[str],
    error_code: str | None,
) -> dict[str, object]:
    now = datetime.now(UTC)
    return {
        "format": AUDIT_FORMAT,
        "time": now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z",
        "correlation_id": correlation_id,
        "writer": writer,
        "role": "caller",
        "sub": sub,
        "identity_kind": "person",
        "service_account": None,
        "azp": azp,
        "aud": AUDIENCE,
        "catalog_id": "prefs",
        "operation": "write_own",
        "effect": "write",
        "object_ref": {"type": "preferences", "id": "me"},
        "result": result,
        "error_code": error_code,
        # Field names only, never the values (interface spec 3.3).
        "detail": {"objects": fields} if fields else None,
        "event": "operation",
    }


def write_preferences(
    session: MutableMapping[str, Any],
    client: PreferencesClient,
    token: TokenSource,
    change: object,
    *,
    sub: str,
    azp: str,
    writer: str,
    audit: AuditSink,
    correlation_id: str,
    domain: object,
) -> WriteResult:
    """Store ``change`` in ``prefs`` with the person's token and refresh session and ``pk_ui``.

    ``If-Match`` carries the etag of the session. A stale etag (412) reloads
    the record once and sends the same change again, because every kit form
    sets whole field values. Exactly one ``papaia.audit/1`` row goes to
    ``audit`` per call, with the correlation id and the changed field names;
    a refusal is raised as :class:`PreferencesError` after its row.
    """
    if not callable(audit):
        raise TypeError("audit must be callable (for example AuditWriter.write bound to a conn)")
    cid = accept_correlation_id(correlation_id)
    names = sorted(n for n in change if isinstance(n, str)) if isinstance(change, Mapping) else []
    fields = [n for n in names if n in WRITABLE]
    # Wrong identity or writer values are a programming error of the module,
    # found before anything is sent.
    probe = _audit_row(
        result="allowed", sub=sub, azp=azp, writer=writer, correlation_id=cid,
        fields=fields, error_code=None,
    )  # fmt: skip
    try:
        validate_event({**probe, "source_seq": 1})
    except ValueError:
        raise ValueError("sub, azp or writer do not fit papaia.audit/1") from None
    if domain is not None:
        ui_set_cookie(Preferences("de", "light", "UTC", {}, "0"), domain=domain)

    def record(result: Literal["allowed", "denied", "error"], code: str | None) -> None:
        audit(
            _audit_row(
                result=result,
                sub=sub,
                azp=azp,
                writer=writer,
                correlation_id=cid,
                fields=fields,
                error_code=code,
            )  # fmt: skip
        )

    try:
        checked = _check_change(change, azp)
        stored = _from_session(session) or client.get(token(), correlation_id=cid)
        try:
            prefs = client.put(token(), checked, etag=stored.etag, correlation_id=cid)
        except PreferencesError as error:
            if error.error_class is not ErrorClass.CONFLICT:
                raise
            fresh = _store(session, client.get(token(), correlation_id=cid))
            prefs = client.put(token(), checked, etag=fresh.etag, correlation_id=cid)
    except PreferencesError as error:
        error.correlation_id = cid
        record("denied" if error.error_class in _DENIED else "error", error.code)
        raise
    _store(session, prefs)
    record("allowed", None)
    return WriteResult(prefs, ui_set_cookie(prefs, domain=domain))


# --- the 303 after a form ---------------------------------------------------------------


def return_target(referer: str | None, *, origin: str) -> str:
    """Path to answer a kit form with ``303``: the ``Referer`` of the same origin, else ``/``.

    ``origin`` is the module's own ``https://host[:port]``. The result is
    always a local path (no scheme, no host, no ``//``), so it cannot lead
    elsewhere; the fragment is dropped.
    """
    own = urlsplit(origin)
    if own.scheme != "https" or not own.netloc or own.path not in ("", "/"):
        raise ValueError("origin must be https://host[:port]")
    if not referer or len(referer) > _MAX_REFERER or _UNSAFE_URL.search(referer):
        return "/"
    parts = urlsplit(referer)
    if parts.scheme != own.scheme or parts.netloc.lower() != own.netloc.lower():
        return "/"
    path = parts.path or "/"
    if not path.startswith("/") or path.startswith("//"):
        return "/"
    return f"{path}?{parts.query}" if parts.query else path
