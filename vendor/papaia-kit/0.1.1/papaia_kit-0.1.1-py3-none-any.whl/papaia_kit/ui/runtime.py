"""Runtime stages of the word check on a running system (interface spec 4.3).

L2 (PLT-27-A7): a test script reads the rendered text nodes of the frame and
the navigation and hands them to ``check_rendered``: the same patterns as in
CI (``find_replaced``), plus the character-identical check of every node the
script names as a mandatory place. L1 (PLT-27-A6): ``pseudo_entries`` builds
the check locale ``x-pk`` from a catalog export, every text wrapped in marks;
``check_pseudo`` reports rendered text without marks and visible key names.
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from papaia_kit.ui.glossary import LANGUAGES, MANDATORY_MODULE_TITLE, Glossary, load_glossary
from papaia_kit.ui.words import (
    KINDS,
    MAX_TEXT,
    CatalogEntry,
    InputError,
    WordFinding,
    find_replaced,
    hit_finding,
)

PSEUDO_LOCALE = "x-pk"
MARK_OPEN = "⟦"
MARK_CLOSE = "⟧"
EXEMPT_REASONS = frozenset({"person", "catalog_name"})
MAX_NODES = 100_000
MAX_NAME = 64
_NODE_FIELDS = frozenset({"text", "glossary_id", "kind", "exempt"})
_MARKED = re.compile(f"{MARK_OPEN}[^{MARK_OPEN}{MARK_CLOSE}]*{MARK_CLOSE}")
_LETTER = re.compile(r"[^\W\d_]")


@dataclass(frozen=True)
class RenderedNode:
    """One visible text node or accessible name read from the running system."""

    text: str
    glossary_id: str | None = None
    kind: str = "nav"
    exempt: str | None = None


def _optional_str(item: Mapping[str, Any], name: str, where: str) -> str | None:
    value = item.get(name)
    if value is not None and (not isinstance(value, str) or not 0 < len(value) <= MAX_NAME):
        raise InputError(f"{where}: {name} must be a short string")
    return value


def parse_nodes(raw: object, label: str) -> list[RenderedNode]:
    """Nodes from JSON: an array of strings or of ``{text, glossary_id?, kind?, exempt?}``."""
    if not isinstance(raw, list) or len(raw) > MAX_NODES:
        raise InputError(f"{label}: expected a JSON array of at most {MAX_NODES} nodes")
    nodes = []
    for index, raw_item in enumerate(raw, 1):
        where = f"{label}: node {index}"
        item = {"text": raw_item} if isinstance(raw_item, str) else raw_item
        if not isinstance(item, dict):
            raise InputError(f"{where}: expected a string or an object")
        if unknown := set(item) - _NODE_FIELDS:
            raise InputError(f"{where}: unknown field(s) {sorted(unknown)}")
        text = item.get("text")
        if not isinstance(text, str) or len(text) > MAX_TEXT:
            raise InputError(f"{where}: text must be a string of at most {MAX_TEXT} characters")
        kind = item.get("kind", "nav")
        if kind not in KINDS:
            raise InputError(f"{where}: kind must be one of {sorted(KINDS)}")
        exempt = _optional_str(item, "exempt", where)
        if exempt is not None and exempt not in EXEMPT_REASONS:
            raise InputError(f"{where}: exempt must be one of {sorted(EXEMPT_REASONS)}")
        nodes.append(RenderedNode(text, _optional_str(item, "glossary_id", where), kind, exempt))
    return nodes


def check_rendered(
    nodes: Sequence[RenderedNode],
    lang: str,
    *,
    module: str | None = None,
    glossary: Glossary | None = None,
) -> list[WordFinding]:
    """W1 on every node and the mandatory-place comparison on nodes with a glossary id."""
    glossary = glossary or load_glossary()
    if lang not in LANGUAGES:
        raise InputError(f"unknown language {lang!r}")
    if module is not None and module not in glossary.fixed.modules:
        raise InputError(f"unknown module {module!r}")
    findings: list[WordFinding] = []
    for index, node in enumerate(nodes, 1):
        location = f"node {index}"
        for hit in find_replaced(
            node.text, node.kind, (lang,), address=lang == "de", glossary=glossary
        ):
            findings.append(hit_finding(hit, "rendered", location))
        if node.glossary_id is None:
            continue
        if node.glossary_id == MANDATORY_MODULE_TITLE:
            if module is None:
                raise InputError(f"{location}: the module title needs the module name")
            expected: tuple[str, ...] = (glossary.fixed.modules[module][lang],)
        elif node.glossary_id in glossary.by_id:
            expected = glossary.by_id[node.glossary_id].lang(lang).forms
        else:
            raise InputError(f"{location}: unknown glossary id {node.glossary_id!r}")
        shown = node.text.strip()
        if shown not in expected:
            findings.append(
                WordFinding(
                    "W2",
                    "rendered",
                    location,
                    lang,
                    shown,
                    node.glossary_id,
                    expected,
                    f'"{shown}" differs from the glossary: use '
                    + " / ".join(f'"{word}"' for word in expected),
                )
            )
    return findings


def pseudo_entries(entries: Iterable[Mapping[str, Any] | CatalogEntry]) -> list[dict[str, Any]]:
    """The check locale: the same entries with every text wrapped in marks."""
    out = []
    for entry in entries:
        item = (
            {"key": entry.key, "text": entry.text, "kind": entry.kind}
            if isinstance(entry, CatalogEntry)
            else dict(entry)
        )
        item["text"] = f"{MARK_OPEN}{item['text']}{MARK_CLOSE}"
        out.append(item)
    return out


def check_pseudo(nodes: Sequence[RenderedNode], keys: Iterable[str]) -> list[WordFinding]:
    """Rendered text under the check locale: every text marked, no key name visible.

    Nodes with an ``exempt`` reason (data of the person, a proper name from the
    catalog) and nodes without letters (numbers) pass.
    """
    key_list = sorted(set(keys), key=lambda key: (-len(key), key))
    key_pattern = (
        re.compile("(?<![\\w.-])(?:" + "|".join(map(re.escape, key_list)) + ")(?![\\w.-])")
        if key_list
        else None
    )
    findings = []
    for index, node in enumerate(nodes, 1):
        text = node.text.strip()
        if not text or node.exempt is not None:
            continue
        location = f"node {index}"
        visible = key_pattern.search(text) if key_pattern else None
        if visible:
            findings.append(
                WordFinding(
                    "L1",
                    "rendered",
                    location,
                    None,
                    visible.group(0),
                    None,
                    (),
                    f"key name {visible.group(0)} is visible",
                )
            )
        elif _LETTER.search(_MARKED.sub(" ", text)):
            findings.append(
                WordFinding(
                    "L1",
                    "rendered",
                    location,
                    None,
                    text,
                    None,
                    (),
                    f'text not marked in the check locale: "{text}"',
                )
            )
    return findings
