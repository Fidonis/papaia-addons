"""Word check of a module against the glossary (``pk-words``, interface spec 4.3).

Five sources, one CI stage each: ``ui`` (the normalised catalog export
``i18n/export/{de,en}.json``), ``templates`` (text nodes of ``*.html``,
``*.tsx``, ``*.jsx``), ``docs`` (``docs/help/**/*.md``), ``mails`` (mail
templates) and ``messages`` (code and message files per language). Every
source runs W1 (replaced words, form of address); the catalog export also runs
W2 (mandatory places), W3 (restricted words), W4 (completeness) and W5
(forbidden patterns). Findings carry the replacement from the glossary.

This is the only implementation of the patterns: the runtime stage L2 hands
rendered text nodes to the same functions (``papaia_kit.ui.runtime``).
"""

from __future__ import annotations

import functools
import json
import os
import re
import subprocess
from collections.abc import Iterable, Iterator, Mapping, Sequence
from dataclasses import asdict, dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

import yaml

from papaia_kit.errors._patterns import find_forbidden_patterns, has_hidden_characters
from papaia_kit.repo import versionable_files
from papaia_kit.ui.glossary import (
    LANGUAGES,
    MANDATORY_MODULE_TITLE,
    NOT_PRESENT,
    Entry,
    Glossary,
    load_glossary,
)

SOURCES = ("ui", "templates", "docs", "mails", "messages")
CHECKS = ("W1", "W2", "W3", "W4", "W5")
KINDS = frozenset({"nav", "title", "button", "tab", "text", "message"})
LABEL_KINDS = frozenset({"nav", "title", "button", "tab"})
SENTENCE_KINDS = frozenset({"text", "message"})
SCOPES = {"ui": "ui", "templates": "ui", "mails": "ui", "messages": "ui", "docs": "doc"}
NAV_MAX_CHARS = 24
ADDRESS_ID = "address"

EXPORT_DIR = Path("i18n/export")
MAP_FILE = Path("i18n/glossary-map.yaml")
SOURCE_GLOBS: Mapping[str, tuple[str, ...]] = {
    "templates": ("**/*.html", "**/*.tsx", "**/*.jsx"),
    "docs": ("docs/help/**/*.md",),
    "mails": ("**/mail/**/*.j2", "**/mails/**/*.j2"),
    "messages": (
        "**/messages/*.de.yaml",
        "**/messages/*.en.yaml",
        "**/codes.de.yaml",
        "**/codes.en.yaml",
    ),
}
DEFAULT_EXCLUDES = (
    "**/node_modules/**",
    "**/vendor/**",
    "**/.venv/**",
    "**/tests/**",
    "**/fixtures/**",
    "**/mail/**",
    "**/mails/**",
)
# Mail templates are excluded from the templates source only.
_TEMPLATE_ONLY_EXCLUDES = frozenset({"**/mail/**", "**/mails/**"})

MAX_FILE_BYTES = 5 * 1024 * 1024
MAX_EXPORT_BYTES = 20 * 1024 * 1024
MAX_TEXT = 20_000
MAX_KEYS_PER_PLACE = 20
_KEY = re.compile(r"[A-Za-z0-9_][A-Za-z0-9_.:/-]{0,199}")
_EXPORT_FIELDS = frozenset({"key", "text", "kind", "fuzzy"})
_PLACEHOLDER = re.compile(
    r"\{\{.*?\}\}|\{[A-Za-z_][\w.]*\}|%\([A-Za-z_]\w*\)[sdif]|%[sdif]|\$\{[^}]*\}"
)


class InputError(ValueError):
    """An input file is missing or malformed (exit code 2 on the command line)."""


@dataclass(frozen=True)
class WordFinding:
    check: str
    source: str
    location: str
    lang: str | None
    match: str
    entry: str | None
    replacement: tuple[str, ...]
    message: str
    severity: str = "error"

    def as_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["replacement"] = list(self.replacement)
        return data


@dataclass(frozen=True)
class CatalogEntry:
    key: str
    text: str
    kind: str
    fuzzy: bool = False


@dataclass(frozen=True)
class Hit:
    start: int
    end: int
    match: str
    lang: str
    entry: str
    replacement: tuple[str, ...]


@dataclass(frozen=True)
class _Segment:
    line: int
    text: str
    kind: str


# --- W1: replaced words and form of address ----------------------------------------------------


def _replacement(entry: Entry, lang: str) -> tuple[str, ...]:
    part = entry.lang(lang)
    return (part.term,) if part.plural is None else (part.term, part.plural)


def _boundary_alternation(words: Iterable[str]) -> str:
    ordered = sorted(set(words), key=lambda word: (-len(word), word))
    return "(?<![\\w-])(?:" + "|".join(re.escape(word) for word in ordered) + ")(?![\\w-])"


@functools.cache
def _form_mask(glossary: Glossary, langs: tuple[str, ...]) -> re.Pattern[str]:
    """Every glossary term of ``langs`` as a whole word, so that no pattern reports a term."""
    return re.compile(
        _boundary_alternation(
            form for entry in glossary.entries for lang in langs for form in entry.lang(lang).forms
        )
    )


def _mask(pattern: re.Pattern[str], text: str) -> str:
    # Same length, so positions stay valid; NUL is no word character.
    return pattern.sub(lambda m: "\0" * len(m.group(0)), text)


def _merge(hits: list[Hit]) -> list[Hit]:
    """Drop hits inside a longer hit; join the replacements of hits on the same span."""
    kept: list[Hit] = []
    for hit in sorted(hits, key=lambda h: (h.start, -(h.end - h.start))):
        same = next((k for k in kept if (k.start, k.end) == (hit.start, hit.end)), None)
        if same is not None:
            joined = same.replacement + tuple(
                r for r in hit.replacement if r not in same.replacement
            )
            kept[kept.index(same)] = Hit(
                same.start, same.end, same.match, same.lang, same.entry, joined
            )
        elif not any(k.start <= hit.start and hit.end <= k.end for k in kept):
            kept.append(hit)
    return sorted(kept, key=lambda h: (h.start, h.end))


def find_replaced(
    text: str,
    kind: str,
    langs: Sequence[str],
    *,
    scope: str = "ui",
    address: bool = False,
    glossary: Glossary | None = None,
) -> list[Hit]:
    """Replaced words in ``text`` shown as ``kind``, checked with the lists of ``langs``.

    ``address`` adds the German form-of-address pattern. Allowed role words
    pass in running text (kinds ``text`` and ``message``).
    """
    glossary = glossary or load_glossary()
    masked = _mask(_form_mask(glossary, tuple(langs)), text)
    hits: list[Hit] = []
    in_sentence = kind in SENTENCE_KINDS
    for lang in langs:
        for entry in glossary.entries:
            if scope not in entry.scope and not (scope == "ui" and "admin" in entry.scope):
                continue
            part = entry.lang(lang)
            allowed = (
                [m.span() for p in part.allow_in_sentence for m in p.finditer(masked)]
                if in_sentence
                else []
            )
            for replaced in part.replaces:
                for m in replaced.regex.finditer(masked):
                    start, end = m.span()
                    if start == end or any(a <= start and end <= b for a, b in allowed):
                        continue
                    hits.append(
                        Hit(start, end, text[start:end], lang, entry.id, _replacement(entry, lang))
                    )
    if address:
        fixed = glossary.fixed
        for m in fixed.address_forbidden_de.finditer(masked):
            hits.append(Hit(m.start(), m.end(), m.group(0), "de", ADDRESS_ID, (fixed.address,)))
    return _merge(hits)


def _quoted(words: Iterable[str]) -> str:
    return " / ".join(f'"{word}"' for word in words)


def hit_finding(hit: Hit, source: str, location: str) -> WordFinding:
    return WordFinding(
        check="W1",
        source=source,
        location=location,
        lang=hit.lang,
        match=hit.match,
        entry=hit.entry,
        replacement=hit.replacement,
        message=f'"{hit.match}": use {_quoted(hit.replacement)} ({hit.entry})',
    )


# --- input files -------------------------------------------------------------------------------


def _read_limited(path: Path, limit: int, label: str) -> str:
    try:
        if path.stat().st_size > limit:
            raise InputError(f"{label}: larger than {limit} bytes")
        return path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise InputError(f"{label}: missing") from exc
    except UnicodeDecodeError as exc:
        raise InputError(f"{label}: not UTF-8") from exc


def check_key(key: object, label: str) -> str:
    if not isinstance(key, str) or not _KEY.fullmatch(key):
        raise InputError(f"{label}: invalid key {key!r}")
    return key


def parse_export(raw: object, label: str) -> list[CatalogEntry]:
    """Entries ``{key, text, kind[, fuzzy]}`` of one catalog export (unknown fields rejected)."""
    if not isinstance(raw, list):
        raise InputError(f"{label}: expected a JSON array of entries")
    entries: list[CatalogEntry] = []
    seen: set[str] = set()
    for index, item in enumerate(raw):
        where = f"{label}[{index}]"
        if not isinstance(item, dict):
            raise InputError(f"{where}: expected an object")
        if unknown := set(item) - _EXPORT_FIELDS:
            raise InputError(f"{where}: unknown field(s) {sorted(unknown)}")
        if missing := {"key", "text", "kind"} - set(item):
            raise InputError(f"{where}: missing field(s) {sorted(missing)}")
        key = check_key(item["key"], where)
        text, kind, fuzzy = item["text"], item["kind"], item.get("fuzzy", False)
        if not isinstance(text, str) or len(text) > MAX_TEXT:
            raise InputError(f"{where}: text must be a string of at most {MAX_TEXT} characters")
        if kind not in KINDS:
            raise InputError(f"{where}: kind must be one of {sorted(KINDS)}")
        if not isinstance(fuzzy, bool):
            raise InputError(f"{where}: fuzzy must be true or false")
        if key in seen:
            raise InputError(f"{where}: duplicate key {key!r}")
        seen.add(key)
        entries.append(CatalogEntry(key, text, kind, fuzzy))
    return entries


def load_export(path: Path, label: str | None = None) -> list[CatalogEntry]:
    label = label or str(path)
    try:
        raw = json.loads(_read_limited(path, MAX_EXPORT_BYTES, label))
    except json.JSONDecodeError as exc:
        raise InputError(f"{label}: not valid JSON (line {exc.lineno})") from exc
    return parse_export(raw, label)


@dataclass(frozen=True)
class GlossaryMap:
    module: str
    places: Mapping[str, tuple[str, ...] | None]  # None: "nicht vorhanden"


def parse_map(raw: object, label: str, glossary: Glossary) -> GlossaryMap:
    """``i18n/glossary-map.yaml``: glossary id -> catalog key(s) or "nicht vorhanden"."""
    if not isinstance(raw, dict) or set(raw) != {"version", "module", "map"}:
        raise InputError(f"{label}: expected exactly the fields version, module, map")
    if raw["version"] != 1:
        raise InputError(f"{label}: version must be 1")
    if raw["module"] not in glossary.fixed.modules:
        raise InputError(f"{label}: unknown module {raw['module']!r}")
    if not isinstance(raw["map"], dict):
        raise InputError(f"{label}: map must be a mapping")
    places: dict[str, tuple[str, ...] | None] = {}
    ids = glossary.ids()
    for place, value in raw["map"].items():
        where = f"{label}: map.{place}"
        if place not in ids:
            raise InputError(f"{where}: unknown glossary id")
        if value == NOT_PRESENT:
            places[place] = None
            continue
        keys = [value] if isinstance(value, str) else value
        if not isinstance(keys, list) or not 1 <= len(keys) <= MAX_KEYS_PER_PLACE:
            raise InputError(f'{where}: expected a key, a list of keys or "{NOT_PRESENT}"')
        checked = tuple(check_key(key, where) for key in keys)
        if len(set(checked)) != len(checked):
            raise InputError(f"{where}: duplicate key")
        places[place] = checked
    return GlossaryMap(raw["module"], places)


def load_map(path: Path, label: str, glossary: Glossary) -> GlossaryMap:
    try:
        raw = yaml.safe_load(_read_limited(path, MAX_FILE_BYTES, label))
    except yaml.YAMLError as exc:
        raise InputError(f"{label}: not valid YAML") from exc
    return parse_map(raw, label, glossary)


# --- files of the module -----------------------------------------------------------------------


@functools.cache
def _glob_regex(pattern: str) -> re.Pattern[str]:
    out = []
    i = 0
    while i < len(pattern):
        if pattern.startswith("**/", i):
            out.append("(?:.*/)?")
            i += 3
        elif pattern.startswith("**", i):
            out.append(".*")
            i += 2
        elif pattern[i] == "*":
            out.append("[^/]*")
            i += 1
        else:
            out.append(re.escape(pattern[i]))
            i += 1
    return re.compile("".join(out))


def glob_match(path: str, patterns: Iterable[str]) -> bool:
    return any(_glob_regex(pattern).fullmatch(path) for pattern in patterns)


def _git_files(root: Path) -> list[str] | None:
    try:
        return versionable_files(root)
    except (OSError, subprocess.CalledProcessError):
        return None


def _walked_files(root: Path) -> list[str]:
    found = []
    for directory, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules"]
        for name in files:
            found.append((Path(directory) / name).relative_to(root).as_posix())
    return sorted(found)


def module_files(root: Path) -> list[str]:
    """Files of the module: what git would version, or every file outside a git work tree."""
    listed = _git_files(root) if (root / ".git").exists() else None
    files = listed if listed is not None else _walked_files(root)
    return [rel for rel in files if (root / rel).is_file() and not (root / rel).is_symlink()]


def path_language(rel: str) -> str | None:
    """Language from a name part (``start.de.html``) or a directory (``help/de/start.md``)."""
    parts = rel.split("/")
    tokens = set(parts[-1].split(".")[1:]) | set(parts[:-1])
    found = [lang for lang in LANGUAGES if lang in tokens]
    return found[0] if len(found) == 1 else None


# --- text extraction ---------------------------------------------------------------------------

_JINJA = re.compile(r"\{#.*?#\}|\{%.*?%\}|\{\{.*?\}\}", re.DOTALL)
_TEXT_ATTRIBUTES = frozenset({"title", "alt", "placeholder", "aria-label", "label"})
_SKIPPED_ELEMENTS = frozenset({"script", "style", "code", "pre", "template"})
_KIND_OF_ELEMENT = {
    "h1": "title",
    "h2": "title",
    "h3": "title",
    "h4": "title",
    "h5": "title",
    "h6": "title",
    "title": "title",
    "button": "button",
    "nav": "nav",
}
_VOID = frozenset(
    {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "source",
        "track",
        "wbr",
    }
)


def _blank(pattern: re.Pattern[str], text: str) -> str:
    """Replace matches by spaces, keeping line breaks so line numbers stay right."""
    return pattern.sub(lambda m: re.sub(r"[^\n]", " ", m.group(0)), text)


class _TextNodes(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.stack: list[tuple[str, str | None]] = []
        self.segments: list[_Segment] = []
        self.lang: str | None = None

    def _kind(self) -> str:
        for tag, role in reversed(self.stack):
            if role == "tab":
                return "tab"
            if tag in _KIND_OF_ELEMENT:
                return _KIND_OF_ELEMENT[tag]
        return "text"

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag == "html" and values.get("lang"):
            lang = (values["lang"] or "").split("-")[0].lower()
            self.lang = lang if lang in LANGUAGES else None
        line = self.getpos()[0]
        kind = "button" if tag == "button" else self._kind()
        for name, value in attrs:
            if name in _TEXT_ATTRIBUTES and value and value.strip():
                self.segments.append(_Segment(line, value, kind))
        if tag not in _VOID:
            self.stack.append((tag, values.get("role")))

    def handle_endtag(self, tag: str) -> None:
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                del self.stack[index:]
                break

    def handle_data(self, data: str) -> None:
        if not data.strip() or any(tag in _SKIPPED_ELEMENTS for tag, _ in self.stack):
            return
        line = self.getpos()[0]
        for offset, row in enumerate(data.split("\n")):
            if row.strip():
                self.segments.append(_Segment(line + offset, row, self._kind()))


def html_segments(text: str) -> tuple[list[_Segment], str | None]:
    """Text nodes and text attributes of an HTML or Jinja template, and its ``<html lang>``."""
    parser = _TextNodes()
    parser.feed(_blank(_JINJA, text))
    parser.close()
    return parser.segments, parser.lang


_JSX_COMMENT = re.compile(r"/\*.*?\*/|^\s*//[^\n]*", re.DOTALL | re.MULTILINE)
_JSX_TEXT = re.compile(r"<([A-Za-z][\w.]*)\b[^<>]*>([^<>{}]+)(?=<|\{)")
_JSX_ATTRIBUTE = re.compile(r"\b(title|alt|placeholder|aria-label|label)=\"([^\"]*)\"")
_CODE_MARKS = re.compile(r"[;=&|]|=>")


def jsx_segments(text: str) -> list[_Segment]:
    """Text between JSX tags and string-valued text attributes (no expressions)."""
    source = _blank(_JSX_COMMENT, text)
    segments = []
    for m in _JSX_TEXT.finditer(source):
        content = m.group(2)
        if (
            not content.strip()
            or _CODE_MARKS.search(content)
            or not re.search(r"[^\W\d_]", content)
        ):
            continue
        tag = m.group(1).lower()
        kind = _KIND_OF_ELEMENT.get(tag, "tab" if tag == "tab" else "text")
        segments.append(_Segment(source.count("\n", 0, m.start(2)) + 1, content, kind))
    for m in _JSX_ATTRIBUTE.finditer(source):
        segments.append(_Segment(source.count("\n", 0, m.start(2)) + 1, m.group(2), "text"))
    return sorted(segments, key=lambda s: s.line)


_FENCE = re.compile(r"^(```|~~~).*?^\1[^\n]*$", re.DOTALL | re.MULTILINE)
_INLINE_CODE = re.compile(r"`[^`\n]*`")
_HTML_COMMENT = re.compile(r"<!--.*?-->", re.DOTALL)
_LINK_TARGET = re.compile(r"\]\([^)\n]*\)|<https?://[^>\s]*>")


def markdown_segments(text: str) -> list[_Segment]:
    """Lines of running text and headings; code, comments and link targets removed."""
    cleaned = text
    for pattern in (_FENCE, _HTML_COMMENT, _INLINE_CODE, _LINK_TARGET):
        cleaned = _blank(pattern, cleaned)
    segments = []
    for number, line in enumerate(cleaned.split("\n"), 1):
        if line.strip():
            kind = "title" if line.lstrip().startswith("#") else "text"
            segments.append(_Segment(number, line, kind))
    return segments


def yaml_segments(text: str, label: str) -> list[_Segment]:
    """Every string value of a message file with its line (keys are identifiers)."""
    try:
        root = yaml.compose(text, Loader=yaml.SafeLoader)
    except yaml.YAMLError as exc:
        raise InputError(f"{label}: not valid YAML") from exc
    segments: list[_Segment] = []

    def walk(node: yaml.Node) -> None:
        if isinstance(node, yaml.MappingNode):
            for _, value in node.value:
                walk(value)
        elif isinstance(node, yaml.SequenceNode):
            for item in node.value:
                walk(item)
        elif isinstance(node, yaml.ScalarNode) and node.tag == "tag:yaml.org,2002:str":
            segments.append(_Segment(node.start_mark.line + 1, str(node.value), "message"))

    if root is not None:
        walk(root)
    return segments


def file_segments(source: str, rel: str, text: str) -> tuple[list[_Segment], str | None]:
    lang = path_language(rel)
    if source == "messages":
        return yaml_segments(text, rel), lang
    if source == "docs":
        return markdown_segments(text), lang
    if rel.endswith((".tsx", ".jsx")):
        return jsx_segments(text), lang
    if source == "mails" and ".html" not in rel:
        plain = _blank(_JINJA, text)
        lines = [
            _Segment(n, row, "text") for n, row in enumerate(plain.split("\n"), 1) if row.strip()
        ]
        return lines, lang
    segments, html_lang = html_segments(text)
    return segments, lang or html_lang


# --- the stages --------------------------------------------------------------------------------


def _file_findings(
    root: Path, source: str, files: Sequence[str], excludes: Sequence[str], glossary: Glossary
) -> Iterator[WordFinding]:
    patterns = SOURCE_GLOBS[source]
    skip = [e for e in excludes if source == "templates" or e not in _TEMPLATE_ONLY_EXCLUDES]
    for rel in files:
        if not glob_match(rel, patterns) or glob_match(rel, skip):
            continue
        text = _read_limited(root / rel, MAX_FILE_BYTES, rel)
        segments, lang = file_segments(source, rel, text)
        langs = (lang,) if lang else LANGUAGES
        for segment in segments:
            for hit in find_replaced(
                segment.text,
                segment.kind,
                langs,
                scope=SCOPES[source],
                address=lang == "de",
                glossary=glossary,
            ):
                yield hit_finding(hit, source, f"{rel}:{segment.line}")


def _ui_w1(
    exports: Mapping[str, Sequence[CatalogEntry]], labels: Mapping[str, str], glossary: Glossary
) -> Iterator[WordFinding]:
    for lang in LANGUAGES:
        for item in exports[lang]:
            for hit in find_replaced(
                item.text, item.kind, (lang,), address=lang == "de", glossary=glossary
            ):
                yield hit_finding(hit, "ui", f"{labels[lang]}#{item.key}")


def _expected(place: str, lang: str, mapping: GlossaryMap, glossary: Glossary) -> tuple[str, ...]:
    if place == MANDATORY_MODULE_TITLE:
        return (glossary.fixed.modules[mapping.module][lang],)
    return glossary.by_id[place].lang(lang).forms


def _w2(
    exports: Mapping[str, Mapping[str, CatalogEntry]],
    labels: Mapping[str, str],
    mapping: GlossaryMap,
    map_label: str,
    glossary: Glossary,
) -> Iterator[WordFinding]:
    for place in glossary.fixed.mandatory:
        if place not in mapping.places:
            yield WordFinding(
                "W2",
                "ui",
                f"{map_label}#{place}",
                None,
                "",
                place,
                (),
                f'mandatory place {place} has no key and no "{NOT_PRESENT}"',
            )
            continue
        for key in mapping.places[place] or ():
            for lang in LANGUAGES:
                expected = _expected(place, lang, mapping, glossary)
                item = exports[lang].get(key)
                location = f"{labels[lang]}#{key}"
                if item is None:
                    yield WordFinding(
                        "W2",
                        "ui",
                        location,
                        lang,
                        "",
                        place,
                        expected,
                        f"key {key} of mandatory place {place} is missing in the catalog",
                    )
                elif item.text not in expected:
                    yield WordFinding(
                        "W2",
                        "ui",
                        location,
                        lang,
                        item.text,
                        place,
                        expected,
                        f'"{item.text}" differs from the glossary: use {_quoted(expected)}',
                    )
    for lang in LANGUAGES:
        for item in exports[lang].values():
            if item.kind == "nav" and len(item.text) > NAV_MAX_CHARS:
                yield WordFinding(
                    "W2",
                    "ui",
                    f"{labels[lang]}#{item.key}",
                    lang,
                    item.text,
                    None,
                    (),
                    f"navigation text longer than {NAV_MAX_CHARS} characters",
                    "warning",
                )


@functools.cache
def _restricted_patterns(
    glossary: Glossary, lang: str
) -> tuple[tuple[Entry, re.Pattern[str], re.Pattern[str]], ...]:
    """Per restricted entry: its words, and the terms of every other entry to mask first."""
    out = []
    for entry in glossary.entries:
        if not entry.restricted:
            continue
        words = re.compile(_boundary_alternation(entry.lang(lang).restricted_words), re.IGNORECASE)
        others = [f for e in glossary.entries if e is not entry for f in e.lang(lang).forms]
        out.append((entry, words, re.compile(_boundary_alternation(others))))
    return tuple(out)


def _w3(
    exports: Mapping[str, Mapping[str, CatalogEntry]],
    labels: Mapping[str, str],
    mapping: GlossaryMap,
    map_label: str,
    glossary: Glossary,
) -> Iterator[WordFinding]:
    owners: dict[str, set[str]] = {}
    for place, keys in mapping.places.items():
        for key in keys or ():
            owners.setdefault(key, set()).add(place)
    for key, places in sorted(owners.items()):
        if len(places) > 1:
            yield WordFinding(
                "W3",
                "ui",
                f"{map_label}#{key}",
                None,
                key,
                None,
                (),
                f"key {key} is mapped to more than one entry: {', '.join(sorted(places))}",
            )
    for lang in LANGUAGES:
        for item in exports[lang].values():
            if item.kind not in LABEL_KINDS:
                continue
            for entry, words, others in _restricted_patterns(glossary, lang):
                found = words.search(_mask(others, item.text))
                if found and owners.get(item.key) != {entry.id}:
                    yield WordFinding(
                        "W3",
                        "ui",
                        f"{labels[lang]}#{item.key}",
                        lang,
                        found.group(0),
                        entry.id,
                        (),
                        f'"{found.group(0)}" only in keys mapped to {entry.id}',
                    )


def _w4(
    exports: Mapping[str, Mapping[str, CatalogEntry]], labels: Mapping[str, str]
) -> Iterator[WordFinding]:
    for lang in LANGUAGES:
        other = "en" if lang == "de" else "de"
        for key in sorted(set(exports[other]) - set(exports[lang])):
            yield WordFinding(
                "W4",
                "ui",
                f"{labels[lang]}#{key}",
                lang,
                "",
                None,
                (),
                f"key {key} is missing in the {lang} catalog",
            )
        for item in exports[lang].values():
            if not item.text.strip():
                yield WordFinding(
                    "W4", "ui", f"{labels[lang]}#{item.key}", lang, "", None, (), "empty text"
                )
            elif item.fuzzy:
                yield WordFinding(
                    "W4",
                    "ui",
                    f"{labels[lang]}#{item.key}",
                    lang,
                    item.text,
                    None,
                    (),
                    "text is marked as not reviewed",
                )


def _w5(
    exports: Mapping[str, Mapping[str, CatalogEntry]], labels: Mapping[str, str]
) -> Iterator[WordFinding]:
    for lang in LANGUAGES:
        for item in exports[lang].values():
            location = f"{labels[lang]}#{item.key}"
            if has_hidden_characters(item.text):
                yield WordFinding("W5", "ui", location, lang, "", None, (), "hidden characters")
            if item.kind not in {"message", "text", "button"}:
                continue
            for hit in find_forbidden_patterns(_PLACEHOLDER.sub(" ", item.text), item.kind):
                yield WordFinding(
                    "W5",
                    "ui",
                    location,
                    lang,
                    hit.match,
                    None,
                    (),
                    f'forbidden pattern {hit.pattern}: "{hit.match}"',
                )


def _ui_findings(
    root: Path, export_dir: Path, map_path: Path, glossary: Glossary
) -> Iterator[WordFinding]:
    labels = {lang: (export_dir / f"{lang}.json").as_posix() for lang in LANGUAGES}
    lists = {lang: load_export(root / labels[lang], labels[lang]) for lang in LANGUAGES}
    map_label = map_path.as_posix()
    mapping = load_map(root / map_path, map_label, glossary)
    exports = {lang: {item.key: item for item in lists[lang]} for lang in LANGUAGES}
    yield from _ui_w1(lists, labels, glossary)
    yield from _w2(exports, labels, mapping, map_label, glossary)
    yield from _w3(exports, labels, mapping, map_label, glossary)
    yield from _w4(exports, labels)
    yield from _w5(exports, labels)


def check_module(
    root: Path,
    *,
    sources: Sequence[str] = SOURCES,
    export_dir: Path = EXPORT_DIR,
    map_path: Path = MAP_FILE,
    excludes: Sequence[str] = DEFAULT_EXCLUDES,
    glossary: Glossary | None = None,
) -> list[WordFinding]:
    """Every finding of the selected sources; warnings have ``severity == "warning"``."""
    glossary = glossary or load_glossary()
    unknown = set(sources) - set(SOURCES)
    if unknown:
        raise InputError(f"unknown source(s) {sorted(unknown)}")
    findings: list[WordFinding] = []
    if "ui" in sources:
        findings.extend(_ui_findings(root, export_dir, map_path, glossary))
    file_sources = [source for source in SOURCES if source in sources and source != "ui"]
    if file_sources:
        files = module_files(root)
        for source in file_sources:
            findings.extend(_file_findings(root, source, files, excludes, glossary))
    return findings
